using UnityEngine;

public static class 平台位移解析工具
{
    const float 位移有效阈值Sqr = 0.00000001f;

    public static bool 尝试获取脚下平台位移(Collider2D 脚下碰撞体, out Vector2 平台位移)
    {
        return 尝试获取脚下平台位移(脚下碰撞体, null, out 平台位移);
    }

    public static bool 尝试获取脚下平台位移(Collider2D 脚下碰撞体, 可搭乘Edge地面位移源 edge平台源缓存, out Vector2 平台位移)
    {
        平台位移 = Vector2.zero;
        if (脚下碰撞体 == null) return false;

        Vector2 已取得位移 = Vector2.zero;
        bool 已取得 = false;

        // 1) 优先走“单向线段2D + 可搭乘平台位移源”（飞机坐骑等老平台逻辑）
        //    注意：如果该源只提供了水平位移，后面仍允许用 单向平台移动 补齐Y。
        var 代理标记 = 脚下碰撞体.GetComponent<单向线段代理标记>();
        if (代理标记 != null && 代理标记.段 != null)
        {
            var 通用平台源 = 代理标记.段.GetComponentInParent<可搭乘平台位移源>();
            if (通用平台源 != null && 通用平台源.enabled && 通用平台源.是否可搭乘线段(代理标记.段))
            {
                已取得位移 = 通用平台源.本帧位移增量;
                已取得 = 已取得位移.sqrMagnitude > 位移有效阈值Sqr;
            }
        }

        // 2) EdgeCollider2D + 可搭乘Edge地面位移源。
        //    如果它没有给出有效位移，不要直接return false，要继续回退到 单向平台移动。
        var edge平台源 = edge平台源缓存;
        if (edge平台源 == null || !edge平台源.enabled || !edge平台源.是否可搭乘碰撞器(脚下碰撞体))
            edge平台源 = 脚下碰撞体.GetComponentInParent<可搭乘Edge地面位移源>();

        if (edge平台源 != null && edge平台源.enabled && edge平台源.是否可搭乘碰撞器(脚下碰撞体))
        {
            Vector2 edge位移 = edge平台源.本帧位移增量;
            if (edge位移.sqrMagnitude > 位移有效阈值Sqr)
            {
                if (!已取得)
                {
                    已取得位移 = edge位移;
                    已取得 = true;
                }
                else
                {
                    // 只补齐缺失轴，避免两个来源重复叠加同一方向。
                    if (Mathf.Abs(已取得位移.x) <= 1e-6f) 已取得位移.x = edge位移.x;
                    if (Mathf.Abs(已取得位移.y) <= 1e-6f) 已取得位移.y = edge位移.y;
                }
            }
        }

        // 3) 回退到老的“单向平台移动”。
        //    这一步也用于补齐Y：常见情况是Edge位移源为了兼容旧移动地面只传水平，
        //    但真正的上下平台位移在 单向平台移动.本帧位移增量 里。
        var 移动平台 = 脚下碰撞体.GetComponentInParent<单向平台移动>();
        if (移动平台 != null && 移动平台.enabled)
        {
            Vector2 移动平台位移 = 移动平台.本帧位移增量;
            if (移动平台位移.sqrMagnitude > 位移有效阈值Sqr)
            {
                if (!已取得)
                {
                    已取得位移 = 移动平台位移;
                    已取得 = true;
                }
                else
                {
                    // 只补齐缺失轴，避免同一平台被多个位移源重复带动。
                    if (Mathf.Abs(已取得位移.x) <= 1e-6f) 已取得位移.x = 移动平台位移.x;
                    if (Mathf.Abs(已取得位移.y) <= 1e-6f) 已取得位移.y = 移动平台位移.y;
                }
            }
        }

        if (!已取得) return false;

        平台位移 = 已取得位移;
        return true;
    }
}
