using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[RequireComponent(typeof(Rigidbody2D))]
public class 玩家控制器new : MonoBehaviour, I分岔输入源, I挤压目标, I平台搭乘者, I弹飞目标, I脚下地面碰撞器, I实时速度提供者, I脚底范围提供者, I吸附限, I水平推动目标信息
{
    [Header("=== 核心连接 ===")]
    public 玩家状态控制器new 状态脚本; // 新架构测试版控制器
    public Animator 飞行员背包动画器;
    public GameObject 飞行员背包节点;

    // 从 状态脚本 同步过来的变量
    public int 水平输入;
    public int 垂直输入;
    public bool 跳跃键;

    [Header("【只读】实时速度监控")]
    public float 实时水平速度; // 单位：米/秒

    public 坐骑基类 当前接触的坐骑 { get; private set; }

    // 动画器保留引用，但不再用于逻辑判断，仅用于特殊情况或兼容
    private Animator 动画器;
    private 玩家数据 引用玩家数据;
    private 全局输入管理器 全局输入;

    public int 玩家状态 = 0;

    [Header("【正常人类】移动与跳跃设置")]
    [SerializeField] private float 正常人类移动速度 = 5f;
    [SerializeField] private float 正常人类跳跃高度 = 2f;
    [SerializeField] private float 正常人类重力强度 = 9.8f;
    [SerializeField] private float 正常人类最大下落速度 = 20f;
    [Header("【胖子】移动与跳跃设置")]
    [SerializeField] private float 胖子移动速度 = 5f;
    [SerializeField] private float 胖子跳跃高度 = 2f;
    [SerializeField] private float 胖子重力强度 = 9.8f;
    [SerializeField] private float 胖子最大下落速度 = 20f;
    [Header("【木乃伊】移动与跳跃设置")]
    [SerializeField] private float 木乃伊移动速度 = 5f;
    [SerializeField] private float 木乃伊跳跃高度 = 2f;
    [SerializeField] private float 木乃伊空中移动速度 = 10f; // 【新增】空中建议设快点，比如6
    [SerializeField] private float 木乃伊重力强度 = 9.8f;
    [SerializeField] private float 木乃伊最大下落速度 = 20f;
    [Header("【僵尸】移动与跳跃设置")]
    [SerializeField] private float 僵尸移动速度 = 5f;
    [SerializeField] private float 僵尸跳跃高度 = 2f;
    [SerializeField] private float 僵尸重力强度 = 9.8f;
    [SerializeField] private float 僵尸最大下落速度 = 20f;
    [Header("【飞行员】移动与跳跃设置")]
    [SerializeField] private float 飞行员水平移动速度 = 5f;
    [SerializeField] private float 飞行员垂直移动速度 = 5f;
    [SerializeField] private float 飞行员重力强度 = 0f;

    [Header("【飞行员】屏幕边界")]
    [Tooltip("玩家切换到飞行员形态时，自动写入 与单向墙碰撞.上边界内缩距离。离开飞行员形态时会恢复本组件启动时的原始值。")]
    [Min(0f)] public float 飞行员形态上边界内缩距离 = 0.8f;

    private float 原始上边界内缩距离 = 0f;
    private bool 已缓存原始上边界内缩距离 = false;

    [Header("【飞行员】击飞手感设置")]
    [SerializeField] private float 飞行员击飞阻尼 = 20f; // 刹车力度，越大停得越快
    private float 飞行员僵直计时器 = 0f; // >0 时表示正在被击飞，不可控

    private bool 出生保护中 = true;

    [Header("挤压/重生保护")]
    [SerializeField] private int 出生保护物理帧数 = 3;
    private int 出生保护剩余物理帧 = 0;

    private bool 挤压死亡处理中 = false;
    // ========== 【核心修改】智能参数获取 ==========
    // 使用属性 (Property) 代替变量。
    // 代码里调用“移动速度”时，它会自动判断当前形态，返回对应的值。

    public float 移动速度
    {
        get
        {
            if (状态脚本 == null) return 正常人类移动速度; // 防空保护

            switch (状态脚本.当前形态)
            {
                case 玩家变身形态.胖子:
                    return 胖子移动速度;
                case 玩家变身形态.木乃伊:
                    // ★ 核心魔法在这里 ★
                    // 如果在地面，返回慢速；如果在空中，返回快速
                    return 是否在地面 ? 木乃伊移动速度 : 木乃伊空中移动速度;
                case 玩家变身形态.僵尸:
                    return 僵尸移动速度;
                // 【新增】飞行员水平速度
                case 玩家变身形态.飞行员:
                    return 飞行员水平移动速度;
                default: return 正常人类移动速度; // 默认返回正常人
            }
        }
    }

    public float 跳跃高度
    {
        get
        {
            if (状态脚本 == null) return 正常人类跳跃高度;

            switch (状态脚本.当前形态)
            {
                case 玩家变身形态.胖子: return 胖子跳跃高度;
                case 玩家变身形态.木乃伊: return 木乃伊跳跃高度;
                case 玩家变身形态.僵尸: return 僵尸跳跃高度;
                // 【新增】飞行员通常不需要跳跃高度，给0或默认即可，因为它靠方向键飞
                case 玩家变身形态.飞行员: return 0f;
                default: return 正常人类跳跃高度;
            }
        }
    }

    public float 重力强度
    {
        get
        {
            if (状态脚本 == null) return 正常人类重力强度;

            switch (状态脚本.当前形态)
            {
                case 玩家变身形态.胖子: return 胖子重力强度;
                case 玩家变身形态.木乃伊: return 木乃伊重力强度;
                case 玩家变身形态.僵尸: return 僵尸重力强度;
                // 【新增】飞行员重力 (通常是0)
                case 玩家变身形态.飞行员: return 飞行员重力强度;
                default: return 正常人类重力强度;
            }
        }
    }

    public float 最大下落速度
    {
        get
        {
            if (状态脚本 == null) return 正常人类最大下落速度;

            switch (状态脚本.当前形态)
            {
                case 玩家变身形态.胖子: return 胖子最大下落速度;
                case 玩家变身形态.木乃伊: return 木乃伊最大下落速度;
                case 玩家变身形态.僵尸: return 僵尸最大下落速度;
                default: return 正常人类最大下落速度;
            }
        }
    }

    public int 角色朝向
    {
        get
        {
            float 当前朝向 = Mathf.Sign(transform.localScale.x);
            if (当前朝向 == 0) 当前朝向 = 1f;
            return 当前朝向 > 0 ? 1 : -1;
        }
    }



    [Header("踩头弹跳（弹跳层）")]
    // 【修复】将内部的双引号改为了单引号，避免语法错误
    [Tooltip("踩到'弹跳层'（Tag=弹跳）时给予的向上速度")]
    public float 踩头弹跳速度 = 12f;

    // 【修复】将内部的双引号改为了单引号
    [Tooltip("从脚底往下检测'弹跳层'的距离（米）")]
    public float 踩头检测距离 = 0.2f;

    [Tooltip("弹跳层所在的物理图层（只检测这一层）")]
    public LayerMask 弹跳检测图层;

    [Header("挤压判定辅助")]
    [SerializeField] private float 挤压_压死贴地容忍距离 = 0.12f; // 你可以调
    static RaycastHit2D[] 挤压_地面检测缓存 = new RaycastHit2D[4];

    [Header("【新挤压】纵向检测")]
    [SerializeField] private LayerMask 新挤压检测图层 = ~0;
    [SerializeField] private float 新挤压头顶条带高度 = 0.08f;
    [SerializeField] private float 新挤压头顶射线长度 = 1.2f;
    [SerializeField] private float 新挤压头顶射线间距 = 0.5f;
    [SerializeField] private bool 新挤压绘制调试 = false;
    [Header("【新挤压】横向检测")]
    [SerializeField, Range(0, 10)] private int 新挤压推动权重 = 0;

    private readonly List<挤压来源候选> 新挤压_头顶候选缓存 = new List<挤压来源候选>(16);
    private readonly List<挤压来源候选> 新挤压_水平候选缓存 = new List<挤压来源候选>(32);
    private 挤压标志 新挤压_上帧有效下压来源 = null;
    private bool 新挤压_上帧存在有效下压 = false;

    // 弹跳检测用的射线缓存，避免GC
    static RaycastHit2D[] 踩头射线缓存 = new RaycastHit2D[4];

    [Header("【新】检测与图层")]
    [SerializeField] private Transform 射线起点;
    [SerializeField] private float 射线检测长度 = 1f;
    [SerializeField] private float 地面射线检测长度 = 2f;
    [SerializeField] private LayerMask 地面图层;
    [SerializeField] private Transform 地面检测点;

    [Header("【新】地面规则检测")]
    [SerializeField, Tooltip("玩家/坐骑同类脚下地面检测规则。为空时仍要求 Collider 挂 地面规则，但使用我方脚下默认规则。")]
    private 地面检测规则文件 脚下地面检测规则;

    [SerializeField, Tooltip("玩家头顶天花板检测规则。为空时只要求 地面规则.阻挡单位向上穿过。")]
    private 地面检测规则文件 头顶天花板检测规则;

    [Header("【新】手动指定的组件")]
    [SerializeField] private BoxCollider2D 玩家碰撞器;
    [SerializeField] private 与单向墙碰撞 碰撞处理器;

    [Header("踩踏弹飞正式接入")]
    [SerializeField, Tooltip("玩家子节点'被击框'上的Collider2D。踩敌人头时使用这个碰撞器的底部中心判断脚底位置。")]
    private Collider2D 踩踏用玩家被击框;

    [Header("【新】防抖动与间隙设置")]
    [SerializeField] private float 皮肤宽度 = 0.01f;
    [SerializeField] private float 地面缓冲距离 = 0.05f;


    [Header("=== 吸附限制 ===")]
    [Tooltip("开启后，斜坡吸附助手会限制本帧最多允许向下吸附多少距离，防止长射线在空中提前吸到地面。")]
    [SerializeField] private bool 启用吸附限制 = true;

    [Tooltip("上一帧不在地面时，最多允许向下吸附的距离。建议 0.03 左右；调大可更容易落地，调小可减少空中瞬吸。")]
    [SerializeField, Min(0f)] private float 空中最大下吸附 = 0.03f;

    [Tooltip("上一帧在地面/平台上时，最多允许向下吸附的距离。保持较大可避免下坡/下移平台轻易丢地。")]
    [SerializeField, Min(0f)] private float 地面最大下吸附 = 1.5f;

    bool I吸附限.启用吸附限制 => 启用吸附限制;
    float I吸附限.空中最大下吸附 => 空中最大下吸附;
    float I吸附限.地面最大下吸附 => 地面最大下吸附;

    [Header("=== 玩家夹角阻挡 / 天花板贴附 ===")]
    [SerializeField, Tooltip("开启后，玩家也会使用类似坐骑的夹角阻挡，防止钻入上斜坡+天花板夹角。")]
    private bool 启用玩家夹角阻挡 = true;

    [SerializeField, Tooltip("开启后，玩家会使用反向斜坡吸附：沿天花板下斜坡移动时自动下压贴附。")]
    private bool 启用玩家天花板贴附 = true;

    [SerializeField, Tooltip("玩家夹角/天花板向上检测图层。为空时自动使用 碰撞处理器.天花板检测图层。")]
    private LayerMask 玩家夹角向上检测图层 = 0;

    [SerializeField, Tooltip("玩家夹角向下检测图层。为空时自动使用 地面图层。")]
    private LayerMask 玩家夹角向下检测图层 = 0;

    [SerializeField] private float 玩家夹角向上射线长度 = 2f;
    [SerializeField] private float 玩家夹角向下射线长度 = 2f;
    [SerializeField] private float 玩家夹角最小斜坡角度 = 5f;
    [SerializeField] private float 玩家夹角最大允许上方距离 = 0.8f;

    [SerializeField, Tooltip("可选：玩家右侧夹角/天花板贴附探测点。拖入后优先使用手动点；留空则自动用碰撞器右侧点。")]
    private Transform 右侧夹角探测点;

    [SerializeField, Tooltip("可选：玩家左侧夹角/天花板贴附探测点。拖入后优先使用手动点；留空则自动用碰撞器左侧点。")]
    private Transform 左侧夹角探测点;

    [SerializeField, Range(0f, 1f), Tooltip("未手动拖左右夹角探测点时，自动从玩家碰撞器左右两侧取夹角探测点的高度比例。0=底部，1=顶部。")]
    private float 玩家自动夹角探测点高度比例 = 0.55f;

    [SerializeField, Min(0f), Tooltip("自动左右探测点向碰撞框内缩的距离，避免刚好贴边误判。")]
    private float 玩家自动夹角探测点水平内缩 = 0.02f;

    [SerializeField, Tooltip("根据 射线起点->地面检测点 的距离额外增加头顶检测长度，用于视觉较高的形态。")]
    private float 玩家额外检测天花板长度 = 0f;

    [SerializeField] private float 玩家天花板贴附皮肤 = 0.02f;
    [SerializeField] private float 玩家天花板最大下压距离 = 0.45f;
    [SerializeField] private bool 绘制玩家夹角探测射线 = false;

    [Header("=== 玩家夹角调试(只读) ===")]
    [SerializeField] private float 玩家调试_当前上距 = -1f;
    [SerializeField] private float 玩家调试_当前下距 = -1f;
    [SerializeField] private float 玩家调试_目标上距 = -1f;
    [SerializeField] private float 玩家调试_目标下距 = -1f;



    [Header("=== 玩家移动减速诊断 ===")]
    [SerializeField, Tooltip("打开后记录玩家水平移动被哪个阶段裁剪。只读诊断，不主动改变移动结果。")]
    private bool 启用移动减速诊断 = false;
    [SerializeField, Tooltip("打开后把诊断摘要输出到Console。")]
    private bool 移动减速诊断_输出Console = true;
    [SerializeField, Tooltip("打开后只在水平位移被明显裁剪时输出。关闭后按间隔输出。")]
    private bool 移动减速诊断_仅在水平裁剪时输出 = true;
    [SerializeField, Min(1), Tooltip("Console输出最小间隔帧数，避免刷屏。")]
    private int 移动减速诊断_输出间隔帧 = 6;
    [SerializeField, Min(0f), Tooltip("小于该值的水平裁剪忽略不计。")]
    private float 移动减速诊断_裁剪阈值 = 0.0001f;
    [SerializeField, TextArea(1, 4), Tooltip("运行时只读：最近一次诊断摘要。")]
    private string 移动减速诊断_最后摘要 = "";
    [SerializeField, Tooltip("运行时只读：本帧最大水平裁剪来源。")]
    private string 移动减速诊断_最大裁剪阶段 = "";

    [SerializeField] private float 移动减速诊断_当前移动速度 = 0f;
    [SerializeField] private bool 移动减速诊断_蹲下中 = false;
    [SerializeField] private bool 移动减速诊断_停顿中 = false;
    [SerializeField] private float 移动减速诊断_玩家主动X = 0f;
    [SerializeField] private float 移动减速诊断_平台X = 0f;
    [SerializeField] private float 移动减速诊断_平台Y = 0f;
    [SerializeField] private float 移动减速诊断_最终Y_进入水平前 = 0f;
    [SerializeField] private float 移动减速诊断_自主总X = 0f;
    [SerializeField] private float 移动减速诊断_自主实体后X = 0f;
    [SerializeField] private float 移动减速诊断_合并尝试X = 0f;
    [SerializeField] private float 移动减速诊断_墙后X = 0f;
    [SerializeField] private float 移动减速诊断_二次挤压后X = 0f;
    [SerializeField] private float 移动减速诊断_最终X = 0f;
    [SerializeField] private float 移动减速诊断_最终Y = 0f;
    [SerializeField] private float 移动减速诊断_最大裁剪量 = 0f;
    [SerializeField] private bool 移动减速诊断_上一帧平台允许锁定 = false;
    [SerializeField] private bool 移动减速诊断_取得平台位移 = false;
    [SerializeField] private bool 移动减速诊断_平台Y已预叠加 = false;
    [SerializeField] private bool 移动减速诊断_天花板贴附阻挡水平 = false;
    [SerializeField] private bool 移动减速诊断_玩家夹角阻挡 = false;
    [SerializeField] private bool 移动减速诊断_顶头更高地面阻挡 = false;
    [SerializeField] private bool 移动减速诊断_飞行员上升不足阻挡 = false;
    [SerializeField] private bool 移动减速诊断_斜坡上抬头顶阻挡 = false;
    [SerializeField] private bool 移动减速诊断_斜坡上抬头顶命中 = false;
    [SerializeField] private bool 移动减速诊断_二次贴地取消水平 = false;
    [SerializeField] private bool 移动减速诊断_空中防穿地裁剪 = false;
    [SerializeField] private float 移动减速诊断_顶头采样Y0 = float.NaN;
    [SerializeField] private float 移动减速诊断_顶头采样Y1 = float.NaN;
    [SerializeField] private float 移动减速诊断_斜坡上抬采样Y0 = float.NaN;
    [SerializeField] private float 移动减速诊断_斜坡上抬采样Y1 = float.NaN;
    [SerializeField] private float 移动减速诊断_二次贴地请求Y = 0f;
    [SerializeField] private float 移动减速诊断_二次贴地安全Y = 0f;
    [SerializeField] private Collider2D 移动减速诊断_当前脚下Collider = null;
    [SerializeField] private Collider2D 移动减速诊断_上一帧锁定Collider = null;

    [Header("=== 玩家空中防穿地诊断 ===")]
    [SerializeField, Tooltip("打开后输出 玩家_尝试裁剪空中向下穿地 的详细诊断。用于排查弹出坐骑/翻滚状态穿地。只读诊断，不主动改变移动结果。")]
    private bool 启用空中防穿地诊断 = false;
    [SerializeField, Tooltip("打开后把空中防穿地诊断输出到Console。")]
    private bool 空中防穿地诊断_输出Console = true;
    [SerializeField, Tooltip("打开后只在 状态脚本.弹出坐骑中 时输出。关闭后所有空中防穿地路径都会按间隔输出。")]
    private bool 空中防穿地诊断_仅弹出坐骑中输出 = true;
    [SerializeField, Min(1), Tooltip("Console输出最小间隔帧数，避免刷屏。")]
    private int 空中防穿地诊断_输出间隔帧 = 3;
    [SerializeField, TextArea(1, 5), Tooltip("运行时只读：最近一次空中防穿地诊断摘要。")]
    private string 空中防穿地诊断_最后摘要 = "";
    [SerializeField, Tooltip("打开后记录最近若干帧的空中防穿地诊断。穿透后可以勾选“打印历史一次”输出最近历史。")]
    private bool 空中防穿地诊断_记录历史 = true;
    [SerializeField, Tooltip("运行时勾选一次，会把最近空中防穿地历史输出到Console，并自动取消勾选。")]
    private bool 空中防穿地诊断_打印历史一次 = false;
    [SerializeField, Tooltip("可选：启用后，当玩家Y低于该值时自动打印一次历史。默认关闭。")]
    private bool 空中防穿地诊断_启用低Y自动打印 = false;
    [SerializeField, Tooltip("低Y自动打印阈值。只有启用低Y自动打印后才生效。")]
    private float 空中防穿地诊断_低Y自动打印阈值 = -20f;
    [SerializeField, TextArea(8, 20), Tooltip("运行时只读：最近一次打印的空中防穿地历史。")]
    private string 空中防穿地诊断_最近历史 = "";

    private const int 空中防穿地诊断_历史容量 = 120;
    private string[] 空中防穿地诊断_历史缓存 = new string[空中防穿地诊断_历史容量];
    private int 空中防穿地诊断_历史写入序号 = 0;
    private bool 空中防穿地诊断_低Y已自动打印 = false;

    private int 移动减速诊断_上次输出帧 = -999999;
    private int 空中防穿地诊断_上次输出帧 = -999999;

    private int 玩家夹角阻挡锁定方向 = 0; // 1=向右推进锁定，-1=向左推进锁定

    public float 垂直速度;
    public float 水平速度;
    private bool 踩踏弹飞水平速度生效中 = false;
    private Rigidbody2D 刚体;
    // —— 挤压/推动相关（供 I挤压目标 使用） ——
    float 挤压_额外水平位移 = 0f;
    float 挤压_额外垂直位移 = 0f;

    [Header("公共状态")]
    public bool 是否在地面;
    public bool 跳跃中 { get; private set; }

    [Header("脚下地面调试")]
    [SerializeField, Tooltip("运行时只读：当前脚下命中的地面Collider2D。用于轿车/平台判断玩家是否站在指定EdgeCollider2D上。")]
    private Collider2D 当前脚下地面碰撞器_缓存;

    [Header("落地排序图层偏移")]
    [SerializeField, Tooltip("玩家落到带有 地面排序图层偏移规则 的地面时，用它临时偏移自身和子节点 SortingGroup 的排序图层。离地时不恢复，下一次真正落地后再裁决。")]
    private 落地排序图层偏移器 落地排序图层偏移器;

    [SerializeField, Tooltip("开启后，Start 时如果本节点没有 落地排序图层偏移器 会自动添加，便于先在玩家身上测试。")]
    private bool 自动添加落地排序图层偏移器 = true;

    [Header("移动平台/移动地面惯性")]
    [SerializeField, Tooltip("开启后，玩家从水平移动平台/移动地面上跳起或离地时，会继续继承脚下平台的水平速度。")]
    private bool 离地后继承平台水平速度 = true;

    [SerializeField, Tooltip("继承的平台水平速度上限，防止异常位移或高速复位造成过大惯性。")]
    private float 最大继承平台水平速度 = 30f;

    [SerializeField, Tooltip("离开平台瞬间只继承多少比例的平台水平速度。1=完全继承，0.8=继承80%。")]
    [Range(0f, 1f)]
    private float 平台水平惯性继承倍率 = 0.85f;

    [SerializeField, Tooltip("玩家离地后，平台水平惯性每秒衰减多少速度。数值越大，空中越快失去平台惯性。")]
    private float 平台水平惯性空中衰减速度 = 8f;

    [SerializeField, Tooltip("空中按反方向时，额外加快平台惯性衰减，避免反向跳被移动地面拖死。")]
    private float 反向输入额外衰减速度 = 18f;

    [SerializeField, Tooltip("平台水平惯性低于这个值时直接归零，避免极小速度残留。")]
    private float 平台水平惯性归零阈值 = 0.03f;

    [SerializeField, Tooltip("落到普通地面或没有平台位移源的地面时，清空继承的平台水平速度。")]
    private bool 落地后清空平台水平惯性 = true;

    [SerializeField, Tooltip("运行时只读：当前空中继承的平台水平速度。")]
    private float 当前继承平台水平速度 = 0f;

    [Header("移动平台/纵向搭乘")]
    [SerializeField, Tooltip("开启后，玩家已经站在脚下移动平台/移动地面上时，会直接叠加脚下平台的纵向位移。只对已落地状态生效，不会吸住空中上升跳跃的玩家。")]
    private bool 脚下平台允许纵向带动 = true;

    [SerializeField, Tooltip("平台向上带动玩家时，仍然经过上方阻挡/挤压约束，避免把玩家顶进天花板或实体。")]
    private bool 平台向上带动时检查顶部阻挡 = true;

    [SerializeField, Tooltip("平台单帧纵向位移超过该值时，不作为搭乘位移叠加，防止循环复位/瞬移把玩家带走。设为0或负数表示不过滤。")]
    private float 最大可叠加平台纵向位移 = 1f;

    [Header("移动平台/脚下平台锁定")]
    [SerializeField, Tooltip("开启后，上一帧站在启用脚下平台锁定的可搭乘Edge地面上时，本帧优先验证并保持同一个Edge，避免电梯抖动/水船下沉时被其它地面抢走。")]
    private bool 启用脚下平台锁定 = true;

    [SerializeField, Min(0f), Tooltip("脚下平台锁定验证时额外向下探测的长度，用于覆盖FixedUpdate时序误差。")]
    private float 脚下平台锁定_验证额外射线长度 = 0.25f;

    [SerializeField, Min(0f), Tooltip("脚下平台锁定验证允许的最大Y修正距离，防止误命中同一长Edge后把玩家瞬移到过远高度。")]
    private float 脚下平台锁定_最大验证Y修正距离 = 1.5f;

    private Collider2D 平台搭乘_上一帧脚下碰撞体 = null;
    private bool 平台搭乘_上一帧站在地面 = false;
    private Collider2D 平台搭乘_Edge位移源缓存碰撞体 = null;
    private 可搭乘Edge地面位移源 平台搭乘_Edge位移源缓存 = null;
    private bool 平台搭乘_Edge位移源缓存已查询 = false;
    private readonly RaycastHit2D[] 平台搭乘_脚下验证命中缓存 = new RaycastHit2D[16];
    private const bool 平台搭乘_启用边缘验证兜底 = false;

    // ==================== 系统控制相关 ====================
    [Header("系统控制")]
    [SerializeField, Tooltip("是否处于系统控制状态（只读，仅供查看）")]
    private bool _系统控制中;
    public bool 系统控制中
    {
        get => _系统控制中;
        private set => _系统控制中 = value;
    }

    private int 系统控制方向;           // 系统控制的移动方向 1/-1
    private float 系统控制剩余时间;     // 系统控制剩余时间
    static RaycastHit2D[] 天花板扫掠缓存 = new RaycastHit2D[8];
    static RaycastHit2D[] 地面采样缓存 = new RaycastHit2D[8];
    static RaycastHit2D[] 向下防穿地扫掠缓存 = new RaycastHit2D[16];
    static RaycastHit2D[] 向下防穿地中心射线缓存 = new RaycastHit2D[16];

    [Header("=== 飞行员向下贴地修正 ===")]
    [SerializeField, Tooltip("飞行员按下穿过合法脚下地面后，允许从地面下方最多向上纠正多少距离。只用于飞行员向下贴地，不影响普通形态空中落地。")]
    private float 飞行员向下贴地最大上抬纠正 = 0.35f;

    private bool 上一物理帧脚底Y有效 = false;
    private float 上一物理帧脚底Y = 0f;
    // ======================================================

    void Awake()
    {
        动画器 = GetComponent<Animator>();
        if (状态脚本 == null) 状态脚本 = GetComponent<玩家状态控制器new>();
        全局输入 = 全局输入管理器.实例;
    }

    private void Start()
    {
        出生保护剩余物理帧 = Mathf.Max(1, 出生保护物理帧数);
        出生保护中 = true;
        挤压死亡处理中 = false;
        生成器 = GetComponent<碎块生成器>();
        引用玩家数据 = GetComponent<玩家数据>();
        刚体 = GetComponent<Rigidbody2D>();
        刚体.bodyType = RigidbodyType2D.Kinematic;

        if (踩踏用玩家被击框 == null)
        {
            踩踏用玩家被击框 = 自动查找踩踏用玩家被击框();
        }

        if (玩家碰撞器 == null || 碰撞处理器 == null)
        {
            Debug.LogError("错误：请手动指定碰撞器！", this);
            this.enabled = false;
        }

        缓存原始上边界内缩距离();
        同步地面规则到碰撞处理器();
        确保落地排序图层偏移器();
    }

    private void 确保落地排序图层偏移器()
    {
        if (落地排序图层偏移器 == null)
            落地排序图层偏移器 = GetComponent<落地排序图层偏移器>();

        if (落地排序图层偏移器 == null && 自动添加落地排序图层偏移器)
            落地排序图层偏移器 = gameObject.AddComponent<落地排序图层偏移器>();
    }

    private void 刷新落地排序图层偏移状态()
    {
        if (落地排序图层偏移器 == null)
            return;

        落地排序图层偏移器.根据脚下地面刷新(是否在地面, 当前脚下地面碰撞器_缓存);
    }

    private Collider2D 自动查找踩踏用玩家被击框()
    {
        Collider2D[] 所有碰撞器 = GetComponentsInChildren<Collider2D>(true);

        // 第一优先：节点名字就是“被击框”
        for (int i = 0; i < 所有碰撞器.Length; i++)
        {
            Collider2D c = 所有碰撞器[i];
            if (c == null) continue;

            if (c.gameObject.name == "被击框")
                return c;
        }

        // 第二优先：Tag 是常见被击框标签
        for (int i = 0; i < 所有碰撞器.Length; i++)
        {
            Collider2D c = 所有碰撞器[i];
            if (c == null) continue;

            if (c.tag == "可刀被击框" || c.tag == "不可刀被击框")
                return c;
        }

        return null;
    }

    // 【新增】实现接口方法
    public float 获取垂直输入()
    {
        return 垂直输入;
    }
    public float 获取水平输入()
    {
        return 水平输入;
    }

    private void Update()
    {
        // 1. 从状态脚本同步数据
        if (状态脚本 != null)
        {
            // 【修改】如果处于系统控制中，使用系统控制的输入，禁止用户输入
            if (系统控制中)
            {
                水平输入 = 系统控制方向;
                垂直输入 = 0;
                跳跃键 = false;
            }
            else
            {
                // 水平/垂直继续沿用状态脚本已经整理好的输入
                水平输入 = 状态脚本.水平按键;
                垂直输入 = 状态脚本.垂直按键;

                // ================================
                // 【核心修复】
                // 跳跃键不再读 状态脚本.跳跃键_触发，
                // 而是玩家控制器自己直接去全局输入管理器拿“这一帧”的触发
                // ================================
                跳跃键 = false;

                if (全局输入 == null)
                    全局输入 = 全局输入管理器.实例;

                int 当前玩家P = -1;
                if (引用玩家数据 != null)
                    当前玩家P = 引用玩家数据.玩家P;
                else
                    当前玩家P = 状态脚本.玩家P;

                if (全局输入 != null && 当前玩家P >= 0)
                {
                    var 输入 = 全局输入.获取玩家输入(当前玩家P);
                    跳跃键 = 输入.跳跃键_触发;
                }
            }
        }

        同步飞行员屏幕边界阻挡开关();
        同步地面规则到碰撞处理器();

        if (飞行员僵直计时器 > 0f)
        {
            飞行员僵直计时器 -= Time.deltaTime;

            // ★★★ 核心修复：当计时器归零的瞬间，强制刹车 ★★★
            if (飞行员僵直计时器 <= 0f)
            {
                飞行员僵直计时器 = 0f;

                // 如果是飞行员形态，僵直结束时，彻底清除所有惯性
                if (状态脚本 != null && 状态脚本.当前形态 == 玩家变身形态.飞行员)
                {
                    水平速度 = 0f; // 彻底消除左右滑步
                    踩踏弹飞水平速度生效中 = false;
                    垂直速度 = 0f; // 彻底消除上下滑步（双重保险）
                }
            }
        }

        // 2. 跳跃逻辑检测
        // 【调试打印】先看跳跃键有没有进到物理脚本
        //if (跳跃键)
        //{
        //    Debug.Log(
        //        $"[玩家控制器检测到跳跃键] 名字={gameObject.name} " +
        //        $"系统控制中={系统控制中} 跳跃键={跳跃键} 是否在地面={是否在地面} " +
        //        $"本地跳跃中={跳跃中} 垂直速度={垂直速度} " +
        //        $"状态脚本为空={(状态脚本 == null)} " +
        //        $"状态脚本.被击中={(状态脚本 != null ? 状态脚本.被击中.ToString() : "null")} " +
        //        $"状态脚本.弹出坐骑中={(状态脚本 != null ? 状态脚本.弹出坐骑中.ToString() : "null")} " +
        //        $"状态脚本.当前形态={(状态脚本 != null ? 状态脚本.当前形态.ToString() : "null")} " +
        //        $"状态脚本.跳跃中={(状态脚本 != null ? 状态脚本.跳跃中.ToString() : "null")} " +
        //        $"状态脚本.是否在地面={(状态脚本 != null ? 状态脚本.是否在地面.ToString() : "null")} " +
        //        $"当前下半身状态={(状态脚本 != null && 状态脚本.当前下半身状态 != null ? 状态脚本.当前下半身状态.GetType().Name : "null")}"
        //    );
        //}

        // 【修改】系统控制中禁止跳跃
        if (!系统控制中 && 跳跃键 && 是否在地面)
        {
            // 必须没被击中、没在跳、没在弹出坐骑，才能跳
            if (!状态脚本.被击中 && !跳跃中 && !状态脚本.弹出坐骑中)
            {
                //某些形态的跳跃要让动画事件调用
                if (状态脚本.当前形态 == 玩家变身形态.正常人类 || 状态脚本.当前形态 == 玩家变身形态.胖子)
                {
                    //Debug.Log($"[玩家控制器准备调用开始跳跃] 名字={gameObject.name}");
                    开始跳跃();
                }
                else
                {
                    //Debug.Log($"[跳跃被形态拦住] 当前形态={状态脚本.当前形态}");
                }
            }
            else
            {
                //Debug.Log(
                //    $"[跳跃被门口条件拦住] 名字={gameObject.name} " +
                //    $"状态脚本.被击中={状态脚本.被击中} 本地跳跃中={跳跃中} 状态脚本.弹出坐骑中={状态脚本.弹出坐骑中}"
                //);
            }
        }
        else if (跳跃键)
        {
            //Debug.Log(
            //    $"[跳跃没进外层判断] 名字={gameObject.name} 系统控制中={系统控制中} 跳跃键={跳跃键} 是否在地面={是否在地面}"
            //);
        }

        // 【修改】系统控制中禁止空格跳跃
        if (!系统控制中 && Input.GetKey(KeyCode.Space) && 是否在地面)
        {
            开始跳跃();
        }
        设置不同形态的射线长度();
    }

    void 缓存原始上边界内缩距离()
    {
        if (已缓存原始上边界内缩距离 || 碰撞处理器 == null)
            return;

        原始上边界内缩距离 = 碰撞处理器.上边界内缩距离;
        已缓存原始上边界内缩距离 = true;
    }

    void 同步飞行员屏幕边界阻挡开关()
    {
        if (碰撞处理器 == null || 状态脚本 == null)
            return;

        缓存原始上边界内缩距离();

        bool 是飞行员 = 状态脚本.当前形态 == 玩家变身形态.飞行员;

        // 你的需求：
        // 飞行员时：关闭“忽略” => false
        // 非飞行员时：重新打开“忽略” => true
        //碰撞处理器.忽略上方屏幕阻挡 = !是飞行员;
        碰撞处理器.忽略下方屏幕阻挡 = !是飞行员;

        // 飞行员形态使用专属上边界内缩；离开飞行员时恢复本组件启动时的原始值。
        碰撞处理器.上边界内缩距离 = 是飞行员
            ? Mathf.Max(0f, 飞行员形态上边界内缩距离)
            : 原始上边界内缩距离;
    }

    private void FixedUpdate()
    {
        // 出生保护按“物理帧”结算，不再按 LateUpdate 结算
        出生保护中 = 出生保护剩余物理帧 > 0;
        if (出生保护剩余物理帧 > 0)
        {
            出生保护剩余物理帧--;
        }

        if (挤压死亡处理中)
            return;

        if (引用玩家数据 != null) { 玩家状态 = 引用玩家数据.当前玩家状态; }
        处理移动();
        空中防穿地诊断_检查历史输出请求();
    }

    public Vector2 当前最终位移 { get; private set; }
    public Vector2 当前最终速度 { get; private set; }

    private void 处理移动()
    {
        float dt = Time.fixedDeltaTime;
        if (挤压死亡处理中)
            return;
        const float EPS = 1e-4f;
        float 本帧开始脚底Y = 玩家_获取当前脚底Y();

        移动减速诊断_开始帧();

        挤压标志 本帧新挤压来源 = null;
        bool 本帧新挤压来自顶部阻挡 = false;
        bool 本帧新挤压来自有效下压 = false;

        Vector2 脚下平台位移 = Vector2.zero;
        bool 本帧取得脚下平台位移 = false;
        bool 本帧使用上一帧平台缓存 = false;
        bool 本帧上一帧平台允许锁定 = false;

        if (启用脚下平台锁定 && 平台搭乘_上一帧站在地面 && 平台搭乘_上一帧脚下碰撞体 != null)
        {
            本帧上一帧平台允许锁定 = 平台搭乘_脚下碰撞体允许锁定(平台搭乘_上一帧脚下碰撞体);

            // 只有平台本身允许“脚下平台锁定”时，才允许使用上一帧脚下平台做预带动。
            // 否则关闭 可搭乘Edge地面位移源.启用脚下平台锁定 后，必须回到旧流程：
            // 本帧贴地成功后，再读取当前脚下平台位移。
            if (本帧上一帧平台允许锁定)
            {
                本帧取得脚下平台位移 = 平台搭乘_尝试获取脚下平台位移(平台搭乘_上一帧脚下碰撞体, out 脚下平台位移);
                本帧使用上一帧平台缓存 = true;
            }
        }

        // 【核心修改】如果是飞行员且处于被击飞的僵直状态，施加高强度阻尼（刹车）
        // 这样会产生“崩”一下弹开然后瞬间停住的效果
        bool 飞行员被击中 = (状态脚本 != null && 状态脚本.当前形态 == 玩家变身形态.飞行员 && 飞行员僵直计时器 > 0f);

        bool 下半身技能停留位置中 = (状态脚本 != null && 状态脚本.当前下半身状态 is 玩家下半身技能状态);

        // —— 垂直方向：重力 + 单向墙 + 斜坡吸附（原逻辑保持） ——
        if (水平速度 != 0)
        {
            // 如果是飞行员被击中，使用极大的阻力(20)，否则使用默认(4)
            float 摩擦力 = 飞行员被击中 ? 飞行员击飞阻尼 : 4f;
            水平速度 = Mathf.MoveTowards(水平速度, 0, 摩擦力 * Time.fixedDeltaTime);

            if (踩踏弹飞水平速度生效中 && Mathf.Abs(水平速度) <= EPS)
            {
                水平速度 = 0f;
                踩踏弹飞水平速度生效中 = false;
            }
        }

        if (下半身技能停留位置中)
        {
            水平速度 = 0f;
            踩踏弹飞水平速度生效中 = false;
        }

        // =========================================================
        // 下半身技能停留位置：冻结玩家自己的垂直速度
        // 飞行员：垂直速度完全由按键控制；其他形态：受重力影响
        // =========================================================
        if (下半身技能停留位置中)
        {
            垂直速度 = 0f;
        }
        else if (状态脚本 != null && 状态脚本.当前形态 == 玩家变身形态.飞行员)
        {
            if (飞行员被击中)
            {
                // 【核心】被击僵直期间：
                // 1. 禁止输入控制（不读取 垂直输入）
                // 2. 对垂直速度也施加同样的强阻尼（因为飞行员是全方位击飞）
                垂直速度 = Mathf.MoveTowards(垂直速度, 0, 飞行员击飞阻尼 * Time.fixedDeltaTime);
            }
            else
            {
                // 正常飞行状态：完全由按键控制
                垂直速度 = 垂直输入 * 飞行员垂直移动速度;
            }
        }
        else
        {
            if (!是否在地面)
                垂直速度 -= 重力强度 * dt;
        }

        垂直速度 = Mathf.Max(垂直速度, -最大下落速度);

        // 外部垂直位移现在只保留给“平台接住 / 内部托起”之类用途。
        // 新系统里，敌人/BOSS 的纵向阻挡与下压，全部通过
        // 挤压标志 + 挤压检测助手 + 目标侧解析 来做。
        float 理想y移动量 = 垂直速度 * dt + 挤压_额外垂直位移;

        // 飞行员主动按上时，应主动脱离脚下移动平台/水船地面。
        // 只看垂直输入，不单独看垂直速度，避免平台上浮把玩家误判为主动脱离。
        bool 飞行员主动上升脱离平台 =
            状态脚本 != null
            && 状态脚本.当前形态 == 玩家变身形态.飞行员
            && 垂直输入 > 0
            && 飞行员僵直计时器 <= 0f
            && !系统控制中;

        if (飞行员主动上升脱离平台)
        {
            清除斜坡吸附内部地面记忆();
            是否在地面 = false;
            当前脚下地面碰撞器_缓存 = null;
            平台搭乘_立即清空脚下平台锁定();

            本帧上一帧平台允许锁定 = false;
            本帧取得脚下平台位移 = false;
            本帧使用上一帧平台缓存 = false;
            脚下平台位移 = Vector2.zero;
        }

        // 脚下平台锁定/稳定搭乘：上一帧已经站在启用锁定的Edge地面上时，先继承它本帧Y位移，
        // 再执行贴地裁决。这样电梯抖动/水船下沉时，玩家不会先被判空中再吸到其它地面。
        // 注意：必须同时要求 本帧上一帧平台允许锁定；否则关闭平台锁定开关后仍会提前吃Y位移。
        if (本帧上一帧平台允许锁定 && 本帧取得脚下平台位移 && Mathf.Abs(脚下平台位移.y) > EPS)
            理想y移动量 += 脚下平台位移.y;

        挤压_额外垂直位移 = 0f;

        // 新纵向系统：
        // 1) 顶部阻挡：静止也能挡住上升，但不致死
        // 2) 有效下压：必须本帧确实向下，才能形成锁定
        // 3) 即使玩家本帧没有主动上升，只要头顶来源真的在下压，也会把玩家往下压
        {
            float 原始想y移动量 = 理想y移动量;

            if (新挤压_解析头顶纵向约束(
                原始想y移动量,
                out float 修正后想y移动量,
                out 本帧新挤压来源,
                out 本帧新挤压来自顶部阻挡,
                out 本帧新挤压来自有效下压))
            {
                理想y移动量 = 修正后想y移动量;

                if (理想y移动量 < 原始想y移动量 - EPS)
                {
                    if (垂直速度 > 0f)
                        垂直速度 = 0f;
                }
            }
        }

        // =========================================================
        // 天花板上顶间隙预裁剪：仿照斜坡吸附助手的“提前裁决”思路，
        // 在普通天花板BoxCast之前就把向上位移裁到目标间隙，避免先贴死天花板，
        // 再等水平移动时才被天花板贴附逻辑拉回。
        // =========================================================
        bool 允许玩家天花板贴附 = 启用玩家天花板贴附 && 玩家当前是飞行员形态();

        if (允许玩家天花板贴附 && 玩家碰撞器 != null && 理想y移动量 > -0.0001f)
        {
            LayerMask 天花板间隙检测图层 = 获取玩家天花板贴附检测图层();
            bool 使用间隙前向点 = false;
            Vector2 间隙前向点 = Vector2.zero;

            // 关键修复：
            // 纯上顶间隙裁剪发生在正式计算水平位移之前。旧版这里传 0，
            // 导致按住 右+上 经过“水平天花板 -> 上斜坡天花板”的拐角时，
            // 裁剪仍然死盯当前中心射线打到的 EdgeCollider 顶点，无法用前方斜坡结果过渡。
            // 这里用飞行员本帧输入预估一个水平位移，只用于天花板间隙检测前探，
            // 不直接改变最终水平移动；真正的 X 仍然后面走墙壁/挤压/夹角裁决。
            float 天花板间隙预估x移动量 = 0f;
            if (水平输入 != 0)
            {
                使用间隙前向点 = true;
                间隙前向点 = 获取玩家夹角自动探测点(水平输入);
                天花板间隙预估x移动量 = 水平输入 * 飞行员水平移动速度 * dt;
            }

            if (天花板间隙检测图层.value != 0 &&
                夹角阻挡助手.尝试裁剪天花板上顶间隙_世界点(
                    射线起点,
                    地面检测点,
                    使用间隙前向点,
                    间隙前向点,
                    天花板间隙预估x移动量,
                    理想y移动量,
                    天花板间隙检测图层,
                    获取玩家有效额外检测天花板长度(),
                    玩家天花板贴附皮肤,
                    玩家天花板最大下压距离,
                    transform.root,
                    绘制玩家夹角探测射线,
                    out float 天花板间隙裁剪后Y,
                    out _))
            {
                玩家_评估天花板下压候选(天花板间隙预估x移动量, 理想y移动量, 天花板间隙裁剪后Y, out bool 可以应用间隙Y, out _);

                if (可以应用间隙Y)
                {
                    理想y移动量 = 天花板间隙裁剪后Y;
                    if (垂直速度 > 0f)
                        垂直速度 = 0f;
                }
                else
                {
                    // 下方已经顶到地面检测点时，不做额外下压；纯上顶只停止继续上升。
                    if (理想y移动量 > 0f)
                    {
                        理想y移动量 = 0f;
                        垂直速度 = 0f;
                    }
                }
            }
        }

        bool isStandingOnPlatform;
        float 安全y移动量 = 玩家_计算安全垂直移动(理想y移动量, 皮肤宽度, out isStandingOnPlatform);
        bool 本帧顶头 = (理想y移动量 > 0f) && (安全y移动量 < 理想y移动量 - EPS);

        // 只有上一帧已经在地面时，垂直安全检测得到的“平台接触”才允许作为贴地保持依据。
        // 空中下落时，不能让 isStandingOnPlatform 绕过斜坡吸附助手的“上一帧脚底 -> 本帧脚底”穿越判断；
        // 否则身体中间的横向地面会被误判为脚下地面，导致落地/下落每帧切换。
        bool 贴地裁决使用平台保持 = 是否在地面 && isStandingOnPlatform;
        if (安全y移动量 < 理想y移动量) { 垂直速度 = 0f; }

        float 最终y移动量;
        RaycastHit2D 地面碰撞信息;
        bool 新在地面;

        // =========================================================
        // 步骤1：标准贴地裁决（注意：只有当前垂直速度<=0 才会做中心向下射线）
        // =========================================================
        新在地面 = 斜坡吸附助手.贴地裁决(
            射线起点, 地面检测点, 地面图层,
            射线检测长度, 地面射线检测长度, 地面缓冲距离,
            获取当前垂直速度(), 是否在地面, 贴地裁决使用平台保持,
            玩家碰撞器, 安全y移动量, out 最终y移动量,
            out 地面碰撞信息, 脚下地面检测规则
        );

        // =========================================================
        // 步骤2：飞行员下坡“撤销吸附”（你的原逻辑保留）
        // =========================================================
        if (新在地面 && 状态脚本 != null && 状态脚本.当前形态 == 玩家变身形态.飞行员)
        {
            if (垂直输入 != -1)
            {
                float 判定方向 = 0f;
                if (水平输入 != 0) 判定方向 = (float)水平输入;
                else 判定方向 = 水平速度;

                if (Mathf.Abs(判定方向) > 0.01f)
                {
                    bool 正在下坡 = (判定方向 * 地面碰撞信息.normal.x) > 0;
                    if (正在下坡)
                    {
                        新在地面 = false;
                        最终y移动量 = 安全y移动量;
                        地面碰撞信息 = new RaycastHit2D();
                    }
                }
            }
        }

        if (!新在地面 && 玩家_尝试飞行员向下穿越地面吸附(安全y移动量, out RaycastHit2D 飞行员向下地面命中, out float 飞行员向下贴地Y移动量))
        {
            新在地面 = true;
            最终y移动量 = 飞行员向下贴地Y移动量;
            地面碰撞信息 = 飞行员向下地面命中;

            if (垂直速度 < 0f)
                垂直速度 = 0f;
        }

        是否在地面 = 新在地面;

        // 新系统：
        // 不是“碰到就死”，而是：
        // 1) 本帧来源是“有效下压”
        // 2) 上一物理帧也是同一个来源的“有效下压”
        // 3) 当前已被压到地面 / 落脚面
        // 4) 来源配置允许“压到落脚面致死”
        if (本帧新挤压来自有效下压 &&
            本帧新挤压来源 != null &&
            新挤压_上帧存在有效下压 &&
            新挤压_上帧有效下压来源 == 本帧新挤压来源 &&
            本帧新挤压来源.压到落脚面致死 &&
            挤压_当前是否在地面())
        {
            挤压_被挤压死亡(Vector2.down, 本帧新挤压来源.获取兼容旧挤压体来源());
            return;
        }

        // ====== 上升时：最终y位移不能超过“安全y位移” ======
        if (理想y移动量 > 0f)
        {
            if (最终y移动量 > 安全y移动量)
                最终y移动量 = 安全y移动量;

            // ★ 修复点：只有在玩家主动产生向上的速度（如跳跃、飞行员上升）时，才强制设为浮空。
            // 如果是被平台被动托起（垂直速度为0，但叠加了挤压位移），则保持底层射线的真实吸附判定。
            if (垂直速度 > 0.001f)
            {
                是否在地面 = false;
            }
        }

        // 脚下平台锁定：上一帧站在启用锁定的Edge上时，本帧优先验证同一个Edge。
        // 验证成功后，即使普通贴地先命中场景地面，也继续保持电梯/水船这类移动平台。
        if (本帧上一帧平台允许锁定
            && 本帧使用上一帧平台缓存
            && 平台搭乘_上一帧脚下碰撞体 != null
            && (!是否在地面 || 地面碰撞信息.collider != 平台搭乘_上一帧脚下碰撞体))
        {
            RaycastHit2D 锁定平台验证命中;
            float 锁定平台验证y移动量;
            bool 锁定平台验证通过 = 平台搭乘_验证指定平台仍在脚下(
                平台搭乘_上一帧脚下碰撞体,
                射线起点 != null ? 射线起点 : transform,
                地面检测点 != null ? 地面检测点 : transform,
                0f,
                安全y移动量,
                out 锁定平台验证命中,
                out 锁定平台验证y移动量
            );

            if (锁定平台验证通过)
            {
                是否在地面 = true;
                地面碰撞信息 = 锁定平台验证命中;
                最终y移动量 = 锁定平台验证y移动量;

                if (垂直速度 < 0f)
                    垂直速度 = 0f;
            }
        }

        // === 独立"弹跳层"检测（原逻辑保留）===
        if (!是否在地面 && 垂直速度 <= 0f)
        {
            Vector2 origin;

            if (地面检测点 != null) origin = 地面检测点.position;
            else if (玩家碰撞器 != null)
            {
                var b = 玩家碰撞器.bounds;
                origin = new Vector2(b.center.x, b.min.y);
            }
            else origin = transform.position;

            ContactFilter2D 过滤 = new ContactFilter2D();
            过滤.useLayerMask = true;
            过滤.layerMask = 弹跳检测图层;
            过滤.useTriggers = true;

            int hitCount = Physics2D.Raycast(origin, Vector2.down, 过滤, 踩头射线缓存, 踩头检测距离);

            for (int i = 0; i < hitCount; i++)
            {
                var hit = 踩头射线缓存[i];
                if (hit.collider == null) continue;

                if (hit.collider.CompareTag("弹跳"))
                {
                    清除斜坡吸附内部地面记忆();
                    垂直速度 = 踩头弹跳速度;
                    最终y移动量 = 0f;
                    是否在地面 = false;
                    跳跃中 = true;
                    if (状态脚本 != null) 状态脚本.跳跃中 = true;
                    break;
                }
            }
        }

        更新当前脚下地面碰撞器缓存(地面碰撞信息);

        // —— 移动平台附加位移 ——
        // 统一走 平台位移解析工具：
        // 1. 单向线段2D + 可搭乘平台位移源（飞机坐骑等旧平台）
        // 2. EdgeCollider2D + 可搭乘Edge地面位移源（自定义循环移动地面）
        // 3. 老的 单向平台移动
        Vector2 平台附加位移 = 脚下平台位移;
        bool 本帧取得平台位移 = 本帧取得脚下平台位移;
        bool 本帧平台Y已预叠加 = 本帧上一帧平台允许锁定 && 本帧取得脚下平台位移 && 本帧使用上一帧平台缓存;
        if (!本帧取得平台位移 && 是否在地面 && 地面碰撞信息.collider != null)
        {
            本帧取得平台位移 = 平台搭乘_尝试获取脚下平台位移(地面碰撞信息.collider, out 平台附加位移);
        }

        移动减速诊断_上一帧平台允许锁定 = 本帧上一帧平台允许锁定;
        移动减速诊断_取得平台位移 = 本帧取得平台位移;
        移动减速诊断_平台Y已预叠加 = 本帧平台Y已预叠加;
        移动减速诊断_平台X = 平台附加位移.x;
        移动减速诊断_平台Y = 平台附加位移.y;
        移动减速诊断_上一帧锁定Collider = 平台搭乘_上一帧脚下碰撞体;

        if (是否在地面 && 地面碰撞信息.collider != null)
        {
            // 注意：这里不再清掉Y。
            // 纵向位移只会在“本帧确认已经站在脚下地面上”时叠加，
            // 空中上升/从平台下方跳过的情况仍然不会被普通搭乘逻辑吸住。

            if (离地后继承平台水平速度)
            {
                if (本帧取得平台位移 && Time.fixedDeltaTime > 0f)
                {
                    float 平台水平速度 = 平台附加位移.x / Time.fixedDeltaTime;
                    float 上限 = Mathf.Max(0f, 最大继承平台水平速度);
                    float 继承速度 = 平台水平速度 * Mathf.Clamp01(平台水平惯性继承倍率);
                    当前继承平台水平速度 = 上限 > 0f
                        ? Mathf.Clamp(继承速度, -上限, 上限)
                        : 继承速度;
                }
                else if (落地后清空平台水平惯性)
                {
                    当前继承平台水平速度 = 0f;
                }
            }
        }

        // —— 落地/空中状态收敛（原逻辑保留） ——
        if (是否在地面)
        {
            跳跃中 = false;
            if (状态脚本 != null) 状态脚本.跳跃中 = false;
            if (垂直速度 < 0f) 垂直速度 = 0f;
        }
        else
        {
            if (垂直速度 <= 0f)
            {
                跳跃中 = false;
                if (状态脚本 != null) 状态脚本.跳跃中 = false;
            }
        }

        // —— 脚下平台纵向带动 ——
        // 只处理“已经站稳在脚下平台/移动地面上”的情况；
        // 玩家跳起后 是否在地面=false，不会继续吃平台Y，也不会从平台下方被吸附。
        if (脚下平台允许纵向带动 && 是否在地面 && 本帧取得平台位移 && !本帧平台Y已预叠加)
        {
            float 平台纵向带动量 = 平台附加位移.y;

            float 纵向上限 = Mathf.Max(0f, 最大可叠加平台纵向位移);
            if (纵向上限 > 0f && Mathf.Abs(平台纵向带动量) > 纵向上限)
            {
                // 循环复位/瞬移保护：这帧只保留水平搭乘，不叠加异常Y位移。
                平台纵向带动量 = 0f;
            }

            if (Mathf.Abs(平台纵向带动量) > 1e-6f)
            {
                if (平台向上带动时检查顶部阻挡 && 平台纵向带动量 > 0f)
                {
                    bool dummy;
                    float 安全平台纵向带动量 = 玩家_计算安全垂直移动(平台纵向带动量, 皮肤宽度, out dummy);
                    安全平台纵向带动量 = 挤压_约束垂直移动_仅在有效下压时阻挡(安全平台纵向带动量);

                    if (安全平台纵向带动量 < 平台纵向带动量 - EPS)
                        垂直速度 = 0f;

                    平台纵向带动量 = 安全平台纵向带动量;
                }

                最终y移动量 += 平台纵向带动量;
            }
        }

        移动减速诊断_最终Y_进入水平前 = 最终y移动量;

        // =========================================================
        // —— 水平方向：输入 + 惯性 + 平台 + 挤压推动 ——
        // =========================================================
        float 玩家主动位移 = 0f;
        bool 停顿中 = 状态脚本.停顿中;

        if (!停顿中 || 系统控制中)
        {
            float 当前移动速度 = 移动速度;
            if (!系统控制中 && 状态脚本.蹲下中) 当前移动速度 /= 3f;
            移动减速诊断_当前移动速度 = 当前移动速度;
            玩家主动位移 = 水平输入 * 当前移动速度 * dt;
        }

        移动减速诊断_停顿中 = 停顿中;
        移动减速诊断_蹲下中 = 状态脚本 != null && 状态脚本.蹲下中;
        移动减速诊断_玩家主动X = 玩家主动位移;

        // 踩踏弹飞的横向速度只作为初始弹开惯性。
        // 玩家一旦产生实际主动水平位移，就交还横向控制权，避免松开方向键后继续沿旧弹飞方向滑动。
        if (踩踏弹飞水平速度生效中 && Mathf.Abs(玩家主动位移) > EPS)
        {
            水平速度 = 0f;
            踩踏弹飞水平速度生效中 = false;
        }

        bool 正在被击飞 =
    !是否在地面 ||
    Mathf.Abs(垂直速度) > 0.001f ||
    (状态脚本 != null && (状态脚本.玩家被击 || 状态脚本.被击中));

        if ((状态脚本.落地动作中 || 状态脚本.蹲下中) && !正在被击飞)
        {
            if (!系统控制中)
            {
                水平速度 = 0f;
                踩踏弹飞水平速度生效中 = false;
            }
        }

        float 外部水平位移 = 水平速度 * dt;
        float 平台空中惯性位移 = 0f;
        if (离地后继承平台水平速度 && !是否在地面 && Mathf.Abs(当前继承平台水平速度) > 0.0001f)
        {
            float 衰减速度 = Mathf.Max(0f, 平台水平惯性空中衰减速度);

            if (水平输入 != 0 && Mathf.Sign(水平输入) != Mathf.Sign(当前继承平台水平速度))
                衰减速度 += Mathf.Max(0f, 反向输入额外衰减速度);

            当前继承平台水平速度 = Mathf.MoveTowards(
                当前继承平台水平速度,
                0f,
                衰减速度 * dt
            );

            if (Mathf.Abs(当前继承平台水平速度) <= Mathf.Max(0f, 平台水平惯性归零阈值))
                当前继承平台水平速度 = 0f;

            平台空中惯性位移 = 当前继承平台水平速度 * dt;
        }

        // 1) 先只计算“玩家自己”的水平位移
        float 自主总x移动量 = 玩家主动位移 + 外部水平位移 + 平台附加位移.x + 平台空中惯性位移 + 挤压_额外水平位移;
        挤压_额外水平位移 = 0f;

        if (状态脚本.被击中 && 状态脚本.已死亡)
        {
            自主总x移动量 = 外部水平位移 + 平台附加位移.x + 平台空中惯性位移;
        }
        移动减速诊断_自主总X = 自主总x移动量;

        // 2) 先对“玩家自己”的水平位移做主动阻挡
        float 自主x移动量_实体后 = 新挤压_约束水平主动移动(自主总x移动量);
        移动减速诊断_自主实体后X = 自主x移动量_实体后;
        移动减速诊断_记录水平阶段("新挤压主动阻挡", 自主总x移动量, 自主x移动量_实体后);

        // 3) 再单独计算“敌人推我”的位移
        挤压标志 本帧水平推动来源 = null;
        float 本帧水平推动位移 = 0f;

        if (新挤压_尝试获取被动推动(out 本帧水平推动来源, out 本帧水平推动位移))
        {
            // 水平挤死关闭时，屏幕边界优先于被动推动：
            // 只裁剪“当前玩家目标”的推动结果，不修改挤压来源公共状态。
            // 因此同一个来源仍可继续独立推动坐骑、其他玩家或其它目标。
            if (本帧水平推动来源 != null &&
                !本帧水平推动来源.水平挤死 &&
                碰撞处理器 != null)
            {
                本帧水平推动位移 = 碰撞处理器.裁剪被动水平推动到屏幕边界(
                    本帧水平推动位移,
                    最终y移动量
                );
            }
        }

        // 4) 最后再把“被动推动”叠加到已经被主动阻挡裁过的自主位移上
        float 合并后尝试x移动量 = 自主x移动量_实体后 + 本帧水平推动位移;
        移动减速诊断_合并尝试X = 合并后尝试x移动量;

        // 5) 再统一走世界碰撞（墙 / 边界 / 单向墙）
        // 平台拖动已经叠加进“合并后尝试x移动量”，但平台限定墙的方向判定
        // 必须使用玩家自身的主动/外部水平意图，不能让平台位移把它抵消成0。
        float 平台限定水平判定意图Dx = 玩家主动位移 + 外部水平位移;
        float 安全x移动量_墙后 = 碰撞处理器.计算安全水平移动(
            合并后尝试x移动量,
            皮肤宽度,
            最终y移动量,
            平台限定水平判定意图Dx);
        移动减速诊断_墙后X = 安全x移动量_墙后;
        移动减速诊断_记录水平阶段("与单向墙碰撞/屏幕边界", 合并后尝试x移动量, 安全x移动量_墙后);

        // —— 挤压辅助：记录本帧左右是否被墙挡（供挤死逻辑用） ——
        挤压_右侧被墙挡 = false;
        挤压_左侧被墙挡 = false;

        if (合并后尝试x移动量 > 0f && 安全x移动量_墙后 < 合并后尝试x移动量 - EPS)
            挤压_右侧被墙挡 = true;
        else if (合并后尝试x移动量 < 0f && 安全x移动量_墙后 > 合并后尝试x移动量 + EPS)
            挤压_左侧被墙挡 = true;

        // 6) 再做一次主动阻挡，但这次忽略“正在推我的那个来源”
        //    否则它会把自己的推力又挡回去，出现“我原地不动，对方穿过我”。
        //    注意：其它挤压来源仍然要参与阻挡。若被动推动被其它挤压来源挡住，
        //    后面的水平挤死判断也要把它当成“被夹住”。
        float 挤压二次约束前x移动量 = 安全x移动量_墙后;

        // 当 与单向墙碰撞 确认本帧多出来的位移是屏幕边界向屏内的补推时，
        // 仅让这部分位移越过“水平挤死=false”的挤压阻挡。
        // 普通主动移动仍会被水平阻挡；水平挤死=true 的来源仍继续阻挡并可触发挤死。
        int 屏幕边界补推方向 = 碰撞处理器 != null
            ? 碰撞处理器.获取本帧屏幕边界向内补推方向(
                合并后尝试x移动量,
                安全x移动量_墙后,
                最终y移动量)
            : 0;

        float 安全x移动量 = 新挤压_约束水平主动移动(
            安全x移动量_墙后,
            本帧水平推动来源,
            屏幕边界补推方向 != 0);
        移动减速诊断_二次挤压后X = 安全x移动量;
        移动减速诊断_记录水平阶段("新挤压二次阻挡", 安全x移动量_墙后, 安全x移动量);

        int 本帧水平推动方向 = (int)Mathf.Sign(本帧水平推动位移);
        bool 本帧被其它挤压来源挡住 = false;
        if (本帧水平推动方向 != 0)
        {
            if (本帧水平推动方向 > 0)
                本帧被其它挤压来源挡住 = 安全x移动量 < 挤压二次约束前x移动量 - EPS;
            else
                本帧被其它挤压来源挡住 = 安全x移动量 > 挤压二次约束前x移动量 + EPS;
        }

        // =========================================================
        // 玩家天花板贴附下压（反向斜坡吸附）
        // 飞行员形态独立处理新地面规则天花板；普通站地形态不使用该贴附下压，避免和夹角阻挡抢控制权。
        // =========================================================
        bool 本帧天花板贴附成功 = false;
        // 记录天花板贴附前的Y；下方空间不足时会停止水平推进，但不会再交给夹角阻挡误判普通贴顶移动。
        float 天花板贴附前最终y移动量 = 最终y移动量;

        if (允许玩家天花板贴附 && 玩家碰撞器 != null && (Mathf.Abs(安全x移动量) > 0.0001f || 理想y移动量 > 0.0001f || 最终y移动量 > 0.0001f))
        {
            LayerMask 天花板贴附检测图层 = 获取玩家天花板贴附检测图层();
            bool 使用前向点 = Mathf.Abs(安全x移动量) > 0.0001f;
            Vector2 前向贴附点 = 使用前向点 ? 获取玩家夹角自动探测点(安全x移动量) : Vector2.zero;

            if (天花板贴附检测图层.value != 0 &&
                夹角阻挡助手.尝试计算天花板贴附下压_世界点(
                    射线起点,
                    地面检测点,
                    使用前向点,
                    前向贴附点,
                    安全x移动量,
                    最终y移动量,
                    天花板贴附检测图层,
                    获取玩家有效额外检测天花板长度(),
                    玩家天花板贴附皮肤,
                    玩家天花板最大下压距离,
                    transform.root,
                    绘制玩家夹角探测射线,
                    out float 天花板贴附后Y,
                    out _))
            {
                玩家_评估天花板下压候选(安全x移动量, 最终y移动量, 天花板贴附后Y, out bool 可以应用贴附Y, out bool 应阻挡本帧水平);

                if (可以应用贴附Y)
                {
                    最终y移动量 = 天花板贴附后Y;
                    本帧天花板贴附成功 = true;
                    是否在地面 = false;
                    玩家夹角阻挡锁定方向 = 0;

                    if (垂直速度 > 0f)
                        垂直速度 = 0f;
                }
                else if (应阻挡本帧水平)
                {
                    // 上方天花板要求下压，同时下方地面已经顶到“地面检测点”，
                    // 并且本帧水平移动会让上下通道继续变窄：停止朝夹缝推进。
                    // 如果是往通道变宽方向退出，则不清零X，只是不应用本帧贴附下压。
                    移动减速诊断_天花板贴附阻挡水平 = true;
                    移动减速诊断_记录水平阶段("天花板贴附阻挡水平", 安全x移动量, 0f);
                    安全x移动量 = 0f;
                    水平速度 = 0f;
                    踩踏弹飞水平速度生效中 = false;
                }
            }
        }

        // =========================================================
        // 玩家夹角阻挡
        // 飞行员不再使用夹角阻挡兜底天花板贴附，避免普通贴顶移动被通道收窄判断误伤；
        // 普通站地形态仍然使用夹角阻挡，防止钻入收窄夹角。
        // =========================================================
        if (启用玩家夹角阻挡 && 玩家碰撞器 != null && !玩家当前是飞行员形态())
        {
            int 当前尝试方向 = 0;
            if (合并后尝试x移动量 > 0.0001f) 当前尝试方向 = 1;
            else if (合并后尝试x移动量 < -0.0001f) 当前尝试方向 = -1;

            if (当前尝试方向 != 0 && 玩家夹角阻挡锁定方向 != 0 && 当前尝试方向 != 玩家夹角阻挡锁定方向)
            {
                玩家夹角阻挡锁定方向 = 0;
            }

            LayerMask 夹角上层 = 获取玩家夹角向上检测图层();
            LayerMask 夹角下层 = 获取玩家夹角向下检测图层();

            bool 允许进行夹角阻挡判定 =
                夹角上层.value != 0 &&
                夹角下层.value != 0;

            if (允许进行夹角阻挡判定)
            {
                Vector2 当前前向探测点 = 获取玩家夹角自动探测点(
                    Mathf.Abs(合并后尝试x移动量) > 0.0001f ? 合并后尝试x移动量 : 玩家夹角阻挡锁定方向
                );

                bool 应阻挡 = false;

                if (当前尝试方向 != 0)
                {
                    应阻挡 = 夹角阻挡助手.应该阻挡朝前移动_世界点(
                        当前前向探测点,
                        new Vector2(合并后尝试x移动量, 最终y移动量),
                        夹角上层,
                        夹角下层,
                        玩家夹角向上射线长度,
                        玩家夹角向下射线长度,
                        玩家夹角最小斜坡角度,
                        玩家夹角最大允许上方距离,
                        transform.root,
                        绘制玩家夹角探测射线,
                        out 玩家调试_当前上距,
                        out 玩家调试_当前下距,
                        out 玩家调试_目标上距,
                        out 玩家调试_目标下距
                    );
                }

                if (!应阻挡 && 当前尝试方向 != 0 && 玩家夹角阻挡锁定方向 == 当前尝试方向)
                {
                    应阻挡 = 夹角阻挡助手.前向探测点仍处于上斜坡夹角内_世界点(
                        当前前向探测点,
                        合并后尝试x移动量,
                        夹角上层,
                        夹角下层,
                        玩家夹角向上射线长度,
                        玩家夹角向下射线长度,
                        玩家夹角最小斜坡角度,
                        玩家夹角最大允许上方距离,
                        transform.root,
                        绘制玩家夹角探测射线,
                        out 玩家调试_当前上距,
                        out 玩家调试_当前下距
                    );
                }

                if (应阻挡)
                {
                    if (当前尝试方向 != 0)
                        玩家夹角阻挡锁定方向 = 当前尝试方向;

                    移动减速诊断_玩家夹角阻挡 = true;
                    移动减速诊断_记录水平阶段("玩家夹角阻挡", 安全x移动量, 0f);
                    安全x移动量 = 0f;

                    if (本帧天花板贴附成功)
                    {
                        // 夹角阻挡优先级高于天花板贴附：
                        // 当飞行员沿天花板下斜坡移动到下方地面夹角时，不能继续保留贴附下压，
                        // 否则会被天花板导向压进/穿过下方地面。
                        最终y移动量 = 天花板贴附前最终y移动量;
                        本帧天花板贴附成功 = false;
                    }
                    else
                    {
                        最终y移动量 = Mathf.Min(最终y移动量, 安全y移动量);
                    }

                    if (垂直速度 > 0f)
                        垂直速度 = 0f;
                }
                else if (当前尝试方向 == 0 && 玩家夹角阻挡锁定方向 != 0)
                {
                    Vector2 锁定方向探测点 = 获取玩家夹角自动探测点(玩家夹角阻挡锁定方向);
                    bool 仍在夹角里 = 夹角阻挡助手.前向探测点仍处于上斜坡夹角内_世界点(
                        锁定方向探测点,
                        玩家夹角阻挡锁定方向,
                        夹角上层,
                        夹角下层,
                        玩家夹角向上射线长度,
                        玩家夹角向下射线长度,
                        玩家夹角最小斜坡角度,
                        玩家夹角最大允许上方距离,
                        transform.root,
                        绘制玩家夹角探测射线,
                        out _,
                        out _
                    );

                    if (!仍在夹角里)
                        玩家夹角阻挡锁定方向 = 0;
                }
            }
            else
            {
                玩家调试_当前上距 = -1f;
                玩家调试_当前下距 = -1f;
                玩家调试_目标上距 = -1f;
                玩家调试_目标下距 = -1f;
                // 检测图层无效时只重置调试距离，不改变移动结果。
            }
        }
        else
        {
            玩家夹角阻挡锁定方向 = 0;
        }

        // ★ 修复：顶头(跳跃被天花板挡住)时，禁止“朝更高地面方向”的水平推进
        // 否则会出现：按住右+连按跳跃，把盒子水平挤进上升斜坡内部
        if (!本帧天花板贴附成功 && 本帧顶头 && 玩家碰撞器 != null && Mathf.Abs(安全x移动量) > 1e-5f)
        {
            Bounds b = 玩家碰撞器.bounds;

            float startY = b.max.y + 0.6f;
            float distY = b.size.y + 3.0f;

            float x0 = b.center.x;
            float x1 = x0 + 安全x移动量;

            float y0 = 采样地面Y(x0, startY, distY, false);
            float y1 = 采样地面Y(x1, startY, distY, true);
            移动减速诊断_顶头采样Y0 = y0;
            移动减速诊断_顶头采样Y1 = y1;

            // 目标地面更高 => 本帧是在“上坡/往夹角里挤”，禁止dx。
            // 但玩家已经站在同一条脚下地面/锁定平台上时，这条地面本身不能反过来
            // 被当作“顶头更高地面阻挡”；否则水船/电梯上浮并沿同一条Edge移动时会把水平位移清零。
            if (!float.IsNaN(y0) && !float.IsNaN(y1) && y1 > y0 + 0.001f)
            {
                移动减速诊断_顶头更高地面阻挡 = true;
                移动减速诊断_记录水平阶段("顶头更高地面阻挡", 安全x移动量, 0f);
                安全x移动量 = 0f;
            }
            // 否则（y1 <= y0）：下坡/后退，允许走，保证能脱离夹角
        }

        // =========================================================
        // ★ 飞行员上升：斜坡“仅上抬” + 天花板不足则取消dx，避免坡+低矮顶卡入
        // 其他情况：照旧做“上方实体阻挡”
        // =========================================================
        bool 飞行员上升中 = (状态脚本 != null
            && 状态脚本.当前形态 == 玩家变身形态.飞行员
            && 垂直速度 > 0.01f);

        if (飞行员上升中 && !本帧天花板贴附成功)
        {
            float dyBase = 最终y移动量;  // 未补抬之前的dy
            float dxFinal = 安全x移动量;

            // 1) 为了不切进斜坡/地面，计算至少需要的上抬
            float dyNeed = 斜坡吸附助手.飞行员_防穿地面_仅上抬(
                玩家碰撞器, 地面图层, dxFinal, dyBase, 地面缓冲距离, 0.08f, 0.6f, 0.02f, 脚下地面检测规则, 地面检测点
            );

            // 2) dyNeed 再走一次“向上安全裁剪”（含天花板BoxCast兜底）
            bool dummy;
            float dyCeil = 玩家_计算安全垂直移动(dyNeed, 皮肤宽度, out dummy);
            if (dyCeil < dyNeed - EPS) 垂直速度 = 0f;

            // 3) 再受“上方实体阻挡”
            float dyCapped = 挤压_约束垂直移动_仅在有效下压时阻挡(dyCeil);
            if (dyCapped < dyCeil - EPS) 垂直速度 = 0f;

            // 4) 如果抬不到 dyNeed，旧逻辑会无条件清零X。
            //    这在“右+上顶到天花板拐角”时过于保守：下方没有地面也会被卡住。
            //    新逻辑：只有确实在朝更高地面/收窄夹缝里挤时才清零X；
            //    如果只是上方天花板拐角裁掉Y，则保留X，只裁掉Y。
            if (dyCapped < dyNeed - EPS)
            {
                bool 需要清零水平推进 = 玩家_飞行员上升不足时需要清零水平(dxFinal, dyBase, dyCapped);

                if (需要清零水平推进)
                {
                    移动减速诊断_飞行员上升不足阻挡 = true;
                    移动减速诊断_记录水平阶段("飞行员上升不足阻挡", 安全x移动量, 0f);
                    安全x移动量 = 0f;

                    // dy 回到原始dyBase，但仍然要受天花板/实体限制
                    float dy0 = 玩家_计算安全垂直移动(dyBase, 皮肤宽度, out dummy);
                    float dy0Cap = 挤压_约束垂直移动_仅在有效下压时阻挡(dy0);
                    if (dy0Cap < dy0 - EPS) 垂直速度 = 0f;

                    最终y移动量 = dy0Cap;
                }
                else
                {
                    最终y移动量 = dyCapped;
                }
            }
            else
            {
                最终y移动量 = dyCapped;
            }
        }
        else
        {
            // —— 非“飞行员上升”情况：只有在“有效下压”时，才把上方挤压体当作硬顶 ——
            // 普通跳跃上升时，不应被上方普通敌人直接挡住。
            float 原始最终y = 最终y移动量;
            最终y移动量 = 挤压_约束垂直移动_仅在有效下压时阻挡(最终y移动量);
            if (原始最终y > 0f && 最终y移动量 < 原始最终y - EPS)
            {
                垂直速度 = 0f;
            }
        }

        // ★ 斜坡吸附的“上抬”(dy>0) 也必须被天花板阻挡：即使 dx==0 也要挡
        // 这正是“松开按键后那一帧偷偷上抬”的根源
        if (是否在地面
            && 玩家碰撞器 != null
            && 碰撞处理器 != null
            && 碰撞处理器.天花板检测图层.value != 0
            && 理想y移动量 <= 1e-4f          // 不是跳跃/飞行员主动上升
            && 最终y移动量 > 1e-4f)          // 本帧确实发生“向上贴坡抬升”
        {
            // 注意：这里故意允许 dx 为 0。因为“点按”时真正抬升常发生在松开那帧（dx=0）
            Vector2 move = new Vector2(安全x移动量, 最终y移动量);
            float dist = move.magnitude;

            // 如果 dx==0，dist 仍然是 dy；一样可以 Cast 检测头顶
            if (dist > 1e-6f)
            {
                ContactFilter2D filter = new ContactFilter2D();
                filter.useLayerMask = true;
                filter.layerMask = 碰撞处理器.天花板检测图层;
                filter.useTriggers = true;

                int hitCount = 玩家碰撞器.Cast(move / dist, filter, 天花板扫掠缓存,
                    dist + Mathf.Max(0.002f, 碰撞处理器.天花板检测皮肤));

                if (存在有效头顶地面命中(天花板扫掠缓存, hitCount, true))
                {
                    移动减速诊断_斜坡上抬头顶命中 = true;
                    // 1) 永远禁止这帧的“斜坡上抬”，彻底断掉“松开那帧偷偷上抬导致蹭穿”
                    最终y移动量 = 0f;
                    垂直速度 = 0f;

                    // 2) 只在“本帧dx是在上坡方向(目标地面更高)”时，才禁止dx
                    //    下坡/后退必须允许dx，否则会卡在夹角出不来
                    float dx = 安全x移动量;

                    if (Mathf.Abs(dx) > 1e-5f && 玩家碰撞器 != null)
                    {
                        Bounds b = 玩家碰撞器.bounds;

                        // 从角色头顶上方一点往下采样地面高度（足够高即可）
                        float startY = b.max.y + 0.6f;
                        float distY = b.size.y + 3.0f;

                        float x0 = b.center.x;
                        float x1 = x0 + dx;

                        float y0 = this.采样地面Y(x0, startY, distY, false);
                        float y1 = this.采样地面Y(x1, startY, distY, true);
                        移动减速诊断_斜坡上抬采样Y0 = y0;
                        移动减速诊断_斜坡上抬采样Y1 = y1;

                        // 如果目标点的地面更高，说明本帧是在“上坡/往夹角里挤”
                        // 这时必须禁止dx，否则会重新制造“挤入斜坡/顶”的问题
                        if (!float.IsNaN(y0) && !float.IsNaN(y1) && y1 > y0 + 0.001f)
                        {
                            移动减速诊断_斜坡上抬头顶阻挡 = true;
                            移动减速诊断_记录水平阶段("斜坡上抬头顶阻挡", 安全x移动量, 0f);
                            安全x移动量 = 0f;
                        }
                        // 否则（y1 <= y0）：下坡/后退，保留dx，让玩家能退出来
                    }
                }

                // 本地小工具：向下射线采样某个x位置的地面高度（命中点y）
                // 注意：用你的“地面图层”，并包含Triggers以兼容工程习惯
                float 采样地面Y(float x, float startY, float dist)
                {
                    ContactFilter2D f = new ContactFilter2D();
                    f.useLayerMask = true;
                    f.layerMask = 地面图层;
                    f.useTriggers = true;

                    Vector2 origin = new Vector2(x, startY);
                    int n = Physics2D.Raycast(origin, Vector2.down, f, 地面采样缓存, dist);
                    if (n <= 0) return float.NaN;

                    // 取最近命中
                    float best = float.PositiveInfinity;
                    float bestY = float.NaN;
                    for (int i = 0; i < n; i++)
                    {
                        var h = 地面采样缓存[i];
                        if (h.collider == null) continue;
                        if (!地面规则缓存.命中可作为脚下地面(h, 脚下地面检测规则)) continue;
                        if (h.distance < best)
                        {
                            best = h.distance;
                            bestY = h.point.y;
                        }
                    }
                    return bestY;
                }
            }
        }

        // 站地后二次贴地：
        // 上一帧锁定在移动Edge地面上、本帧又有水平位移时，第一次贴地裁决使用的是旧X位置。
        // 水船/电梯上浮并走上斜坡时，必须在最终X位置再让斜坡吸附助手做一次“只上抬”的防穿修正。
        if (本帧上一帧平台允许锁定
            && 是否在地面
            && 平台搭乘_上一帧脚下碰撞体 != null
            && 玩家碰撞器 != null
            && !玩家当前是飞行员形态()
            && Mathf.Abs(安全x移动量) > EPS)
        {
            if (斜坡吸附助手.站地后二次贴地仅上抬(
                玩家碰撞器,
                地面图层,
                安全x移动量,
                最终y移动量,
                地面缓冲距离,
                out float 二次贴地Y,
                out RaycastHit2D 二次贴地命中,
                平台搭乘_上一帧脚下碰撞体,
                0.08f,
                脚下平台锁定_验证额外射线长度,
                脚下平台锁定_最大验证Y修正距离,
                0.02f,
                脚下地面检测规则,
                地面检测点: 地面检测点))
            {
                if (二次贴地Y > 最终y移动量 + EPS)
                {
                    bool 二次贴地顶头;
                    float 安全二次贴地Y = 玩家_计算二次贴地安全上抬_排除当前支撑地面(二次贴地Y, 皮肤宽度, out 二次贴地顶头);
                    安全二次贴地Y = 挤压_约束垂直移动_仅在有效下压时阻挡(安全二次贴地Y);

                    移动减速诊断_二次贴地请求Y = 二次贴地Y;
                    移动减速诊断_二次贴地安全Y = 安全二次贴地Y;
                    if (安全二次贴地Y >= 二次贴地Y - EPS)
                    {
                        最终y移动量 = 二次贴地Y;
                        地面碰撞信息 = 二次贴地命中;
                        是否在地面 = true;
                        当前脚下地面碰撞器_缓存 = 二次贴地命中.collider;

                        if (垂直速度 < 0f)
                            垂直速度 = 0f;
                    }
                    else
                    {
                        // 上方空间不足时，不把玩家横向推进上浮斜坡内部。
                        移动减速诊断_二次贴地取消水平 = true;
                        移动减速诊断_记录水平阶段("二次贴地上方空间不足", 安全x移动量, 0f);
                        安全x移动量 = 0f;
                    }
                }
            }
        }

        新挤压_上帧存在有效下压 = 本帧新挤压来自有效下压 && 本帧新挤压来源 != null;
        新挤压_上帧有效下压来源 = 新挤压_上帧存在有效下压 ? 本帧新挤压来源 : null;

        // 被动推动如果已经被“世界几何”或“其它挤压来源”挡住，
        // 并且推动来源允许水平挤死，才执行挤死。
        // 不能挤死就允许和来源重叠，但绝不把玩家推进墙/边界/斜坡内部。
        if (本帧水平推动来源 != null)
        {
            int 推动方向 = (int)Mathf.Sign(本帧水平推动位移);
            bool 推动方向有效 = 推动方向 != 0;

            bool 被世界挡住 =
                推动方向有效 &&
                挤压_本帧某方向被墙挡(推动方向);

            bool 被夹住 = 被世界挡住 || 本帧被其它挤压来源挡住;

            if (被夹住 &&
                本帧水平推动来源.水平挤死 &&
                Mathf.Abs(本帧水平推动来源.本帧中心水平速度) >= 本帧水平推动来源.水平挤死最小速度)
            {
                挤压_被挤压死亡(new Vector2(推动方向, 0f), 本帧水平推动来源.获取兼容旧挤压体来源());
                return;
            }
        }

        // —— 空中向下斜向移动防穿地兜底 ——
        // 分轴移动中，Y 裁剪发生在 X 裁剪之前；空中被击飞左下/右下移动时，
        // 旧 X 的垂直检测可能错过新 X 位置下方的地面。这里改用最终 X 位置的脚底中心做穿越确认，
        // 脚底优先使用地面检测点；只收紧 Y，不再用物理碰撞器边角命中裁剪 X。
        float 防穿地前X = 安全x移动量;
        if (玩家_尝试裁剪空中向下穿地(ref 安全x移动量, ref 最终y移动量, out RaycastHit2D 防穿地地面命中))
        {
            移动减速诊断_空中防穿地裁剪 = true;
            移动减速诊断_记录水平阶段("空中向下防穿地兜底", 防穿地前X, 安全x移动量);
            是否在地面 = true;
            地面碰撞信息 = 防穿地地面命中;
            更新当前脚下地面碰撞器缓存(地面碰撞信息);

            垂直速度 = 0f;
            跳跃中 = false;
            if (状态脚本 != null)
                状态脚本.跳跃中 = false;
        }

        // 停下帧锁定保护：只在本帧没有实际水平位移时救回上一帧锁定平台。
        // 移动中不做多点/边角式保留，避免重新出现复杂斜边上的边缘兜底挂边。
        if (Mathf.Abs(安全x移动量) <= EPS)
            平台搭乘_最终保护上一帧锁定平台(ref 地面碰撞信息, ref 最终y移动量);

        平台搭乘_记录本帧结束脚下平台();

        移动减速诊断_当前脚下Collider = 当前脚下地面碰撞器_缓存;
        移动减速诊断_最终X = 安全x移动量;
        移动减速诊断_最终Y = 最终y移动量;
        移动减速诊断_记录水平阶段("最终未记录裁剪", 移动减速诊断_二次挤压后X, 安全x移动量);
        移动减速诊断_输出本帧();

        // —— 应用最终移动 ——
        Vector2 本帧最终位移 = new Vector2(安全x移动量, 最终y移动量);

        当前最终位移 = 本帧最终位移;

        上一物理帧脚底Y = 本帧开始脚底Y;
        上一物理帧脚底Y有效 = true;

        if (Time.fixedDeltaTime > 0f)
            当前最终速度 = 本帧最终位移 / Time.fixedDeltaTime;
        else
            当前最终速度 = Vector2.zero;

        // 最终脚下地面已经完成裁决后再刷新排序图层偏移。
        // 离地时不恢复，下一次真正落地时再按新地面规则裁决。
        刷新落地排序图层偏移状态();

        刚体.MovePosition(刚体.position + 本帧最终位移);
    }



    private void 移动减速诊断_开始帧()
    {
        if (!启用移动减速诊断)
            return;

        移动减速诊断_最大裁剪阶段 = "";
        移动减速诊断_最后摘要 = "";
        移动减速诊断_当前移动速度 = 0f;
        移动减速诊断_蹲下中 = 状态脚本 != null && 状态脚本.蹲下中;
        移动减速诊断_停顿中 = 状态脚本 != null && 状态脚本.停顿中;
        移动减速诊断_玩家主动X = 0f;
        移动减速诊断_平台X = 0f;
        移动减速诊断_平台Y = 0f;
        移动减速诊断_最终Y_进入水平前 = 0f;
        移动减速诊断_自主总X = 0f;
        移动减速诊断_自主实体后X = 0f;
        移动减速诊断_合并尝试X = 0f;
        移动减速诊断_墙后X = 0f;
        移动减速诊断_二次挤压后X = 0f;
        移动减速诊断_最终X = 0f;
        移动减速诊断_最终Y = 0f;
        移动减速诊断_最大裁剪量 = 0f;
        移动减速诊断_上一帧平台允许锁定 = false;
        移动减速诊断_取得平台位移 = false;
        移动减速诊断_平台Y已预叠加 = false;
        移动减速诊断_天花板贴附阻挡水平 = false;
        移动减速诊断_玩家夹角阻挡 = false;
        移动减速诊断_顶头更高地面阻挡 = false;
        移动减速诊断_飞行员上升不足阻挡 = false;
        移动减速诊断_斜坡上抬头顶阻挡 = false;
        移动减速诊断_斜坡上抬头顶命中 = false;
        移动减速诊断_二次贴地取消水平 = false;
        移动减速诊断_空中防穿地裁剪 = false;
        移动减速诊断_顶头采样Y0 = float.NaN;
        移动减速诊断_顶头采样Y1 = float.NaN;
        移动减速诊断_斜坡上抬采样Y0 = float.NaN;
        移动减速诊断_斜坡上抬采样Y1 = float.NaN;
        移动减速诊断_二次贴地请求Y = 0f;
        移动减速诊断_二次贴地安全Y = 0f;
        移动减速诊断_当前脚下Collider = 当前脚下地面碰撞器_缓存;
        移动减速诊断_上一帧锁定Collider = 平台搭乘_上一帧脚下碰撞体;
    }

    private void 移动减速诊断_记录水平阶段(string 阶段, float 裁剪前X, float 裁剪后X)
    {
        if (!启用移动减速诊断)
            return;

        float 裁剪量 = Mathf.Abs(裁剪前X) - Mathf.Abs(裁剪后X);
        if (裁剪量 > 移动减速诊断_最大裁剪量 + Mathf.Max(0f, 移动减速诊断_裁剪阈值))
        {
            移动减速诊断_最大裁剪量 = 裁剪量;
            移动减速诊断_最大裁剪阶段 = 阶段 + " " + 裁剪前X.ToString("F5") + " -> " + 裁剪后X.ToString("F5");
        }
    }

    private void 移动减速诊断_输出本帧()
    {
        if (!启用移动减速诊断)
            return;

        bool 有明显裁剪 = 移动减速诊断_最大裁剪量 > Mathf.Max(0f, 移动减速诊断_裁剪阈值);
        if (移动减速诊断_仅在水平裁剪时输出 && !有明显裁剪)
            return;

        int 间隔 = Mathf.Max(1, 移动减速诊断_输出间隔帧);
        if (移动减速诊断_输出Console && Time.frameCount - 移动减速诊断_上次输出帧 < 间隔)
            return;

        移动减速诊断_最后摘要 =
            "frame=" + Time.frameCount +
            " input=" + 水平输入 +
            " grounded=" + 是否在地面 +
            " pos=" + transform.position.ToString("F3") +
            " speed=" + 移动减速诊断_当前移动速度.ToString("F3") +
            " crouch=" + 移动减速诊断_蹲下中 +
            " stop=" + 移动减速诊断_停顿中 +
            " activeX=" + 移动减速诊断_玩家主动X.ToString("F5") +
            " platform=(" + 移动减速诊断_平台X.ToString("F5") + "," + 移动减速诊断_平台Y.ToString("F5") + ")" +
            " yBeforeH=" + 移动减速诊断_最终Y_进入水平前.ToString("F5") +
            " x[total=" + 移动减速诊断_自主总X.ToString("F5") +
            ",entity=" + 移动减速诊断_自主实体后X.ToString("F5") +
            ",merged=" + 移动减速诊断_合并尝试X.ToString("F5") +
            ",wall=" + 移动减速诊断_墙后X.ToString("F5") +
            ",squeeze2=" + 移动减速诊断_二次挤压后X.ToString("F5") +
            ",final=" + 移动减速诊断_最终X.ToString("F5") + "]" +
            " finalY=" + 移动减速诊断_最终Y.ToString("F5") +
            " maxCut=" + 移动减速诊断_最大裁剪量.ToString("F5") +
            " stage=" + (string.IsNullOrEmpty(移动减速诊断_最大裁剪阶段) ? "无" : 移动减速诊断_最大裁剪阶段) +
            " lock=" + 移动减速诊断_上一帧平台允许锁定 +
            " gotPlatform=" + 移动减速诊断_取得平台位移 +
            " preY=" + 移动减速诊断_平台Y已预叠加 +
            " flags[ceilAttach=" + 移动减速诊断_天花板贴附阻挡水平 +
            ",angle=" + 移动减速诊断_玩家夹角阻挡 +
            ",headHigh=" + 移动减速诊断_顶头更高地面阻挡 +
            ",pilot=" + 移动减速诊断_飞行员上升不足阻挡 +
            ",slopeHit=" + 移动减速诊断_斜坡上抬头顶命中 +
            ",slopeTop=" + 移动减速诊断_斜坡上抬头顶阻挡 +
            ",secondStick=" + 移动减速诊断_二次贴地取消水平 +
            ",antiFall=" + 移动减速诊断_空中防穿地裁剪 + "]" +
            " sample[head=" + 移动减速诊断_顶头采样Y0.ToString("F3") + "->" + 移动减速诊断_顶头采样Y1.ToString("F3") +
            ",slope=" + 移动减速诊断_斜坡上抬采样Y0.ToString("F3") + "->" + 移动减速诊断_斜坡上抬采样Y1.ToString("F3") +
            ",secondY=" + 移动减速诊断_二次贴地请求Y.ToString("F5") + "/" + 移动减速诊断_二次贴地安全Y.ToString("F5") + "]" +
            " ground=" + 移动减速诊断_碰撞体名(移动减速诊断_当前脚下Collider) +
            " lastLock=" + 移动减速诊断_碰撞体名(移动减速诊断_上一帧锁定Collider);

        if (移动减速诊断_输出Console)
        {
            移动减速诊断_上次输出帧 = Time.frameCount;
            Debug.Log("[玩家移动减速诊断2] " + 移动减速诊断_最后摘要, this);
        }
    }

    private string 移动减速诊断_碰撞体名(Collider2D col)
    {
        if (col == null)
            return "null";

        string 父名 = col.transform != null && col.transform.parent != null ? col.transform.parent.name + "/" : "";
        return 父名 + col.name;
    }

    private bool 玩家_是否应从更高地面采样中排除(Collider2D 碰撞器)
    {
        if (!是否在地面 || 碰撞器 == null)
            return false;

        if (当前脚下地面碰撞器_缓存 != null && 碰撞器 == 当前脚下地面碰撞器_缓存)
            return true;

        if (平台搭乘_上一帧脚下碰撞体 != null && 碰撞器 == 平台搭乘_上一帧脚下碰撞体)
            return true;

        return false;
    }

    private bool 空中防穿地诊断_当前是弹出坐骑相关状态()
    {
        if (状态脚本 == null)
            return false;

        if (状态脚本.弹出坐骑中)
            return true;

        if (状态脚本.当前下半身状态 != null)
        {
            string 状态名 = 状态脚本.当前下半身状态.GetType().Name;
            if (!string.IsNullOrEmpty(状态名) && 状态名.Contains("弹出坐骑"))
                return true;
        }

        return false;
    }

    private bool 空中防穿地诊断_当前允许输出(bool 强制输出 = false)
    {
        if (!启用空中防穿地诊断 || !空中防穿地诊断_输出Console)
            return false;

        if (空中防穿地诊断_仅弹出坐骑中输出 && !强制输出)
        {
            if (!空中防穿地诊断_当前是弹出坐骑相关状态())
                return false;
        }

        return Time.frameCount - 空中防穿地诊断_上次输出帧 >= 空中防穿地诊断_输出间隔帧;
    }

    private void 空中防穿地诊断_记录一帧(string 摘要)
    {
        if (!启用空中防穿地诊断 || !空中防穿地诊断_记录历史)
            return;

        if (空中防穿地诊断_历史缓存 == null || 空中防穿地诊断_历史缓存.Length != 空中防穿地诊断_历史容量)
            空中防穿地诊断_历史缓存 = new string[空中防穿地诊断_历史容量];

        int index = 空中防穿地诊断_历史写入序号 % 空中防穿地诊断_历史容量;
        空中防穿地诊断_历史缓存[index] = "#" + 空中防穿地诊断_历史写入序号 + " " + 摘要;
        空中防穿地诊断_历史写入序号++;
    }

    private void 空中防穿地诊断_输出历史(string 原因)
    {
        if (!启用空中防穿地诊断)
            return;

        if (空中防穿地诊断_历史缓存 == null || 空中防穿地诊断_历史缓存.Length == 0)
            return;

        System.Text.StringBuilder sb = new System.Text.StringBuilder(8192);
        sb.Append("reason=").Append(原因)
          .Append(" frame=").Append(Time.frameCount)
          .Append(" currentPos=(").Append(transform.position.x.ToString("F3")).Append(",").Append(transform.position.y.ToString("F3")).Append(")")
          .Append(" lower=").Append(状态脚本 != null && 状态脚本.当前下半身状态 != null ? 状态脚本.当前下半身状态.GetType().Name : "null")
          .Append(" ejectRelated=").Append(空中防穿地诊断_当前是弹出坐骑相关状态())
          .AppendLine();

        int count = Mathf.Min(空中防穿地诊断_历史写入序号, 空中防穿地诊断_历史容量);
        int start = 空中防穿地诊断_历史写入序号 - count;
        for (int i = 0; i < count; i++)
        {
            int seq = start + i;
            int idx = seq % 空中防穿地诊断_历史容量;
            string line = 空中防穿地诊断_历史缓存[idx];
            if (!string.IsNullOrEmpty(line))
                sb.AppendLine(line);
        }

        空中防穿地诊断_最近历史 = sb.ToString();

        if (空中防穿地诊断_输出Console)
            Debug.Log("[玩家空中防穿地历史] " + 空中防穿地诊断_最近历史, this);
    }

    private void 空中防穿地诊断_检查历史输出请求()
    {
        if (!启用空中防穿地诊断)
            return;

        if (空中防穿地诊断_打印历史一次)
        {
            空中防穿地诊断_打印历史一次 = false;
            空中防穿地诊断_输出历史("manualToggle");
        }

        if (空中防穿地诊断_启用低Y自动打印 && !空中防穿地诊断_低Y已自动打印 && transform.position.y <= 空中防穿地诊断_低Y自动打印阈值)
        {
            空中防穿地诊断_低Y已自动打印 = true;
            空中防穿地诊断_输出历史("autoLowY");
        }
    }

    private void 空中防穿地诊断_输出(string 摘要, bool 强制输出 = false)
    {
        空中防穿地诊断_最后摘要 = 摘要;
        空中防穿地诊断_记录一帧(摘要);

        if (!空中防穿地诊断_当前允许输出(强制输出))
            return;

        空中防穿地诊断_上次输出帧 = Time.frameCount;
        Debug.Log("[玩家空中防穿地诊断] " + 摘要, this);
    }

    private bool 玩家_获取Edge首尾端点距离(RaycastHit2D hit, out float 最近距离, out float 首端距离, out float 尾端距离)
    {
        最近距离 = float.PositiveInfinity;
        首端距离 = float.PositiveInfinity;
        尾端距离 = float.PositiveInfinity;

        EdgeCollider2D edge = hit.collider as EdgeCollider2D;
        if (edge == null || edge.points == null || edge.points.Length < 2)
            return false;

        Vector2 hitLocal = edge.transform.InverseTransformPoint(hit.point);
        Vector2 first = edge.points[0];
        Vector2 last = edge.points[edge.points.Length - 1];

        首端距离 = Vector2.Distance(hitLocal, first);
        尾端距离 = Vector2.Distance(hitLocal, last);
        最近距离 = Mathf.Min(首端距离, 尾端距离);
        return true;
    }

    private string 玩家_防穿地命中摘要(RaycastHit2D hit)
    {
        if (hit.collider == null)
            return "null";

        float minDist;
        float firstDist;
        float lastDist;
        string edgeInfo = "edgeDist=none";
        if (玩家_获取Edge首尾端点距离(hit, out minDist, out firstDist, out lastDist))
        {
            edgeInfo = "edgeDist[min=" + minDist.ToString("F4") +
                       ",first=" + firstDist.ToString("F4") +
                       ",last=" + lastDist.ToString("F4") +
                       ",filtered=" + 斜坡吸附助手.边缘兜底命中过近首尾端点(hit).ToString() + "]";
        }

        return 移动减速诊断_碰撞体名(hit.collider) +
               " point=(" + hit.point.x.ToString("F3") + "," + hit.point.y.ToString("F3") + ")" +
               " normal=(" + hit.normal.x.ToString("F3") + "," + hit.normal.y.ToString("F3") + ")" +
               " dist=" + hit.distance.ToString("F4") +
               " " + edgeInfo;
    }

    private string 玩家_空中防穿地状态摘要(float x移动量, float y移动量, float 当前脚底Y, float 预测脚底Y)
    {
        string lowerState = "null";
        if (状态脚本 != null && 状态脚本.当前下半身状态 != null)
            lowerState = 状态脚本.当前下半身状态.GetType().Name;

        string colliderInfo = "collider=null";
        if (玩家碰撞器 != null)
        {
            Bounds b = 玩家碰撞器.bounds;
            colliderInfo = "collider[enabled=" + 玩家碰撞器.enabled +
                ",active=" + 玩家碰撞器.gameObject.activeInHierarchy +
                ",min=(" + b.min.x.ToString("F3") + "," + b.min.y.ToString("F3") + ")" +
                ",max=(" + b.max.x.ToString("F3") + "," + b.max.y.ToString("F3") + ")" +
                ",size=(" + b.size.x.ToString("F3") + "," + b.size.y.ToString("F3") + ")]";
        }

        string groundMaskInfo = "groundMask=" + 地面图层.value;
        string groundPointInfo = "groundPoint=" + (地面检测点 != null ? "(" + 地面检测点.position.x.ToString("F3") + "," + 地面检测点.position.y.ToString("F3") + ")" : "null");

        return "frame=" + Time.frameCount +
               " pos=(" + transform.position.x.ToString("F3") + "," + transform.position.y.ToString("F3") + ")" +
               " grounded=" + 是否在地面 +
               " jump=" + 跳跃中 +
               " eject=" + (状态脚本 != null && 状态脚本.弹出坐骑中).ToString() +
               " ejectRelated=" + 空中防穿地诊断_当前是弹出坐骑相关状态().ToString() +
               " hit=" + (状态脚本 != null && 状态脚本.被击中).ToString() +
               " dead=" + (状态脚本 != null && 状态脚本.已死亡).ToString() +
               " form=" + (状态脚本 != null ? 状态脚本.当前形态.ToString() : "null") +
               " lower=" + lowerState +
               " vSpeed=" + 垂直速度.ToString("F4") +
               " move=(" + x移动量.ToString("F5") + "," + y移动量.ToString("F5") + ")" +
               " footY=" + 当前脚底Y.ToString("F4") +
               " predFootY=" + 预测脚底Y.ToString("F4") +
               " " + groundPointInfo +
               " " + colliderInfo +
               " " + groundMaskInfo;
    }

    private float 玩家_获取当前脚底Y()
    {
        if (地面检测点 != null)
            return 地面检测点.position.y;

        if (玩家碰撞器 != null && 玩家碰撞器.enabled && 玩家碰撞器.gameObject.activeInHierarchy)
            return 玩家碰撞器.bounds.min.y;

        return transform.position.y;
    }

    private bool 玩家_尝试飞行员向下穿越地面吸附(float y移动量, out RaycastHit2D 地面命中, out float 修正y移动量)
    {
        地面命中 = default;
        修正y移动量 = y移动量;

        if (!玩家当前是飞行员形态())
            return false;

        if (垂直输入 >= 0)
            return false;

        if (y移动量 > 1e-4f)
            return false;

        if (射线起点 == null || 地面图层.value == 0)
            return false;

        float 当前脚底Y = 玩家_获取当前脚底Y();
        float 预测脚底Y = 当前脚底Y + y移动量;
        float 穿越起点脚底Y = 上一物理帧脚底Y有效 ? Mathf.Max(上一物理帧脚底Y, 当前脚底Y) : 当前脚底Y;

        float 射线起点相对脚底上抬 = Mathf.Max(0f, 射线起点.position.y - 当前脚底Y);
        float 检测距离 = Mathf.Max(射线检测长度, 地面射线检测长度);
        检测距离 += 射线起点相对脚底上抬;
        检测距离 += Mathf.Abs(y移动量);
        检测距离 += Mathf.Max(0.05f, 飞行员向下贴地最大上抬纠正 + 地面缓冲距离);
        检测距离 = Mathf.Max(0.05f, 检测距离);

        ContactFilter2D 过滤 = new ContactFilter2D();
        过滤.useLayerMask = true;
        过滤.layerMask = 地面图层;
        过滤.useTriggers = true;

        Vector2 起点 = new Vector2(射线起点.position.x, 射线起点.position.y);
        int 命中数 = Physics2D.Raycast(起点, Vector2.down, 过滤, 地面采样缓存, 检测距离);
        if (命中数 <= 0)
            return false;

        float 穿越容差 = Mathf.Max(0.05f, 地面缓冲距离 + 0.02f);
        float 最大上抬纠正 = Mathf.Max(0f, 飞行员向下贴地最大上抬纠正);

        bool 找到候选 = false;
        float 最佳距离 = float.PositiveInfinity;
        RaycastHit2D 最佳命中 = default;
        float 最佳y移动量 = y移动量;

        for (int i = 0; i < 命中数 && i < 地面采样缓存.Length; i++)
        {
            RaycastHit2D hit = 地面采样缓存[i];
            if (hit.collider == null)
                continue;

            if (hit.collider.transform.root == transform.root)
                continue;

            if (!地面规则缓存.命中可作为脚下地面(hit, 脚下地面检测规则))
                continue;

            if (hit.normal.y <= 0.05f)
                continue;

            float 目标脚底Y = hit.point.y + 地面缓冲距离;
            bool 起点在地面上方或接近表面 = 穿越起点脚底Y >= 目标脚底Y - 穿越容差;
            bool 终点到达或穿过地面 = 预测脚底Y <= 目标脚底Y + 穿越容差;

            if (!起点在地面上方或接近表面 || !终点到达或穿过地面)
                continue;

            float 目标y移动量 = 目标脚底Y - 当前脚底Y;
            if (目标y移动量 > 最大上抬纠正)
                continue;

            if (hit.distance < 最佳距离)
            {
                找到候选 = true;
                最佳距离 = hit.distance;
                最佳命中 = hit;
                最佳y移动量 = 目标y移动量;
            }
        }

        if (!找到候选)
            return false;

        地面命中 = 最佳命中;
        修正y移动量 = 最佳y移动量;
        return true;
    }

private bool 玩家_尝试裁剪空中向下穿地(ref float x移动量, ref float y移动量, out RaycastHit2D 地面命中)
    {
        地面命中 = default;

        float 当前脚底Y_诊断;
        if (地面检测点 != null) 当前脚底Y_诊断 = 地面检测点.position.y;
        else if (玩家碰撞器 != null) 当前脚底Y_诊断 = 玩家碰撞器.bounds.min.y;
        else 当前脚底Y_诊断 = transform.position.y;
        float 预测脚底Y_诊断 = 当前脚底Y_诊断 + y移动量;

        // 只处理空中向下移动。站地状态仍交给原来的贴地/斜坡系统，避免改变走坡手感。
        if (是否在地面)
        {
            空中防穿地诊断_输出("skip=alreadyGrounded " + 玩家_空中防穿地状态摘要(x移动量, y移动量, 当前脚底Y_诊断, 预测脚底Y_诊断));
            return false;
        }
        if (y移动量 >= -1e-5f)
        {
            空中防穿地诊断_输出("skip=notDownward " + 玩家_空中防穿地状态摘要(x移动量, y移动量, 当前脚底Y_诊断, 预测脚底Y_诊断));
            return false;
        }
        if (玩家碰撞器 == null)
        {
            空中防穿地诊断_输出("skip=noPlayerCollider " + 玩家_空中防穿地状态摘要(x移动量, y移动量, 当前脚底Y_诊断, 预测脚底Y_诊断));
            return false;
        }
        if (地面图层.value == 0)
        {
            空中防穿地诊断_输出("skip=noGroundLayer " + 玩家_空中防穿地状态摘要(x移动量, y移动量, 当前脚底Y_诊断, 预测脚底Y_诊断));
            return false;
        }

        float 当前脚底Y;
        float 当前脚底X;
        if (地面检测点 != null)
        {
            当前脚底X = 地面检测点.position.x;
            当前脚底Y = 地面检测点.position.y;
        }
        else
        {
            当前脚底X = 玩家碰撞器.bounds.center.x;
            当前脚底Y = 玩家碰撞器.bounds.min.y;
        }

        float 预测脚底Y = 当前脚底Y + y移动量;
        float 穿越容差 = Mathf.Max(0.05f, 地面缓冲距离 + 0.02f);
        float 检测X = 当前脚底X + x移动量;
        float 上探容差 = Mathf.Max(地面缓冲距离 + 皮肤宽度 + 0.03f, 0.08f);
        Vector2 中心射线起点 = new Vector2(检测X, 当前脚底Y + 上探容差);
        float 检测长度 = 上探容差 + Mathf.Abs(y移动量) + 地面缓冲距离 + 穿越容差;

        ContactFilter2D 过滤 = new ContactFilter2D();
        过滤.useLayerMask = true;
        过滤.layerMask = 地面图层;
        过滤.useTriggers = true;

        int 数量 = Physics2D.Raycast(中心射线起点, Vector2.down, 过滤, 向下防穿地中心射线缓存, 检测长度);

        float 最近 = float.PositiveInfinity;
        RaycastHit2D 最近命中 = default;
        float 最近命中目标脚底Y = 0f;

        int 拒绝_自身 = 0;
        int 拒绝_规则 = 0;
        int 拒绝_法线 = 0;
        int 拒绝_端点 = 0;
        int 拒绝_穿越 = 0;
        int 候选数 = 0;
        string 第一有效扫掠 = "null";
        string 第一端点拒绝 = "null";
        string 第一穿越拒绝 = "null";
        string 第一规则拒绝 = "null";

        for (int i = 0; i < 数量 && i < 向下防穿地中心射线缓存.Length; i++)
        {
            RaycastHit2D hit = 向下防穿地中心射线缓存[i];
            if (hit.collider == null)
                continue;

            if (第一有效扫掠 == "null")
                第一有效扫掠 = 玩家_防穿地命中摘要(hit);

            if (hit.collider.transform.root == transform.root)
            {
                拒绝_自身++;
                continue;
            }

            if (!地面规则缓存.命中可作为脚下地面(hit, 脚下地面检测规则))
            {
                拒绝_规则++;
                if (第一规则拒绝 == "null")
                    第一规则拒绝 = 玩家_防穿地命中摘要(hit);
                continue;
            }

            // 只接住可站立的上表面/斜坡；侧面或下表面不作为落地。
            if (hit.normal.y <= 0.05f)
            {
                拒绝_法线++;
                continue;
            }

            if (斜坡吸附助手.边缘兜底命中过近首尾端点(hit))
            {
                拒绝_端点++;
                if (第一端点拒绝 == "null")
                    第一端点拒绝 = 玩家_防穿地命中摘要(hit);
                continue;
            }

            float 目标脚底Y = hit.point.y + 地面缓冲距离;

            // 空中防穿地兜底必须遵守“上一帧脚底 -> 本帧预测脚底”的穿越判断。
            // 检测点使用本帧最终X位置，避免斜向移动时旧X位置误判；修正时只收紧y，不裁剪x。
            float 穿越起点脚底Y = 上一物理帧脚底Y有效 ? Mathf.Max(上一物理帧脚底Y, 当前脚底Y) : 当前脚底Y;
            bool 起点在地面上方或接近表面 = 穿越起点脚底Y >= 目标脚底Y - 穿越容差;
            bool 终点到达或穿过地面 = 预测脚底Y <= 目标脚底Y + 穿越容差;
            if (!起点在地面上方或接近表面 || !终点到达或穿过地面)
            {
                拒绝_穿越++;
                if (第一穿越拒绝 == "null")
                    第一穿越拒绝 = 玩家_防穿地命中摘要(hit) +
                        " targetFootY=" + 目标脚底Y.ToString("F4") +
                        " cross[startOk=" + 起点在地面上方或接近表面 +
                        ",endOk=" + 终点到达或穿过地面 + "]";
                continue;
            }

            候选数++;
            if (hit.distance < 最近)
            {
                最近 = hit.distance;
                最近命中 = hit;
                最近命中目标脚底Y = 目标脚底Y;
            }
        }

        if (最近命中.collider == null)
        {
            空中防穿地诊断_输出("result=noLanding centerRay=" + 数量 +
                " candidate=" + 候选数 +
                " reject[self=" + 拒绝_自身 +
                ",rule=" + 拒绝_规则 +
                ",normal=" + 拒绝_法线 +
                ",endpoint=" + 拒绝_端点 +
                ",cross=" + 拒绝_穿越 + "] " +
                玩家_空中防穿地状态摘要(x移动量, y移动量, 当前脚底Y, 预测脚底Y) +
                " firstHit={" + 第一有效扫掠 + "}" +
                " endpointHit={" + 第一端点拒绝 + "}" +
                " crossHit={" + 第一穿越拒绝 + "}" +
                " ruleHit={" + 第一规则拒绝 + "}");
            return false;
        }

        float 贴地Y移动量 = 最近命中目标脚底Y - 当前脚底Y;

        空中防穿地诊断_输出("result=landing centerRay=" + 数量 +
            " candidate=" + 候选数 +
            " reject[self=" + 拒绝_自身 +
            ",rule=" + 拒绝_规则 +
            ",normal=" + 拒绝_法线 +
            ",endpoint=" + 拒绝_端点 +
            ",cross=" + 拒绝_穿越 + "] " +
            玩家_空中防穿地状态摘要(x移动量, y移动量, 当前脚底Y, 预测脚底Y) +
            " chosen={" + 玩家_防穿地命中摘要(最近命中) + "}" +
            " targetFootY=" + 最近命中目标脚底Y.ToString("F4") +
            " fixedMove=(" + x移动量.ToString("F5") + "," + 贴地Y移动量.ToString("F5") + ")");

        y移动量 = 贴地Y移动量;
        地面命中 = 最近命中;
        return true;
    }

    private float 采样地面Y(float x, float startY, float dist, bool 排除当前脚下或锁定平台 = false)
    {
        ContactFilter2D f = new ContactFilter2D();
        f.useLayerMask = true;
        f.layerMask = 地面图层;
        f.useTriggers = true;

        Vector2 origin = new Vector2(x, startY);
        int n = Physics2D.Raycast(origin, Vector2.down, f, 地面采样缓存, dist);
        if (n <= 0) return float.NaN;

        float best = float.PositiveInfinity;
        float bestY = float.NaN;
        for (int i = 0; i < n; i++)
        {
            var h = 地面采样缓存[i];
            if (h.collider == null) continue;
            if (排除当前脚下或锁定平台 && 玩家_是否应从更高地面采样中排除(h.collider)) continue;
            if (!地面规则缓存.命中可作为脚下地面(h, 脚下地面检测规则)) continue;
            if (h.distance < best)
            {
                best = h.distance;
                bestY = h.point.y;
            }
        }
        return bestY;
    }


    private bool 玩家当前是飞行员形态()
    {
        return 状态脚本 != null && 状态脚本.当前形态 == 玩家变身形态.飞行员;
    }

    private LayerMask 获取玩家夹角向上检测图层()
    {
        if (玩家夹角向上检测图层.value != 0)
            return 玩家夹角向上检测图层;

        LayerMask 图层 = 0;

        // 夹角阻挡需要能看到新地面规则天花板。
        // 不再强依赖 与单向墙碰撞.天花板检测图层 是否勾了“地面”，避免飞行员贴附和硬BoxCast抢控制权。
        if (碰撞处理器 != null)
            图层 |= 碰撞处理器.天花板检测图层;

        图层 |= 地面图层;
        return 图层;
    }

    private LayerMask 获取玩家天花板贴附检测图层()
    {
        LayerMask 图层 = 0;

        if (玩家夹角向上检测图层.value != 0)
            图层 |= 玩家夹角向上检测图层;

        // 天花板贴附本身严格筛选：地面类型=天花板 且 阻挡单位向上穿过=true。
        // 因此这里主动加入“地面图层”，让贴附不再依赖 与单向墙碰撞.天花板检测图层。
        图层 |= 地面图层;

        // 也保留旧天花板/墙壁图层，方便调试射线和旧场景，但严格筛选会过滤掉非地面规则天花板。
        if (碰撞处理器 != null)
            图层 |= 碰撞处理器.天花板检测图层;

        return 图层;
    }

    private float 玩家_计算安全垂直移动(float 理想y移动量, float 皮肤宽度参数, out bool isStandingOnPlatform)
    {
        if (碰撞处理器 == null)
        {
            isStandingOnPlatform = false;
            return 理想y移动量;
        }

        if (!玩家当前是飞行员形态() || 地面图层.value == 0)
            return 碰撞处理器.计算安全垂直移动(理想y移动量, 皮肤宽度参数, out isStandingOnPlatform);

        LayerMask 原始天花板检测图层 = 碰撞处理器.天花板检测图层;
        碰撞处理器.天花板检测图层 = 原始天花板检测图层 & ~地面图层;

        try
        {
            return 碰撞处理器.计算安全垂直移动(理想y移动量, 皮肤宽度参数, out isStandingOnPlatform);
        }
        finally
        {
            碰撞处理器.天花板检测图层 = 原始天花板检测图层;
        }
    }

    private float 玩家_计算二次贴地安全上抬_排除当前支撑地面(float 理想y移动量, float 皮肤宽度参数, out bool 顶头)
    {
        顶头 = false;

        if (理想y移动量 <= 0f)
            return 理想y移动量;

        if (玩家碰撞器 == null)
            return 玩家_计算安全垂直移动(理想y移动量, 皮肤宽度参数, out 顶头);

        LayerMask 上方检测图层 = 获取玩家夹角向上检测图层();
        if (上方检测图层.value == 0)
            return 理想y移动量;

        ContactFilter2D 过滤 = new ContactFilter2D();
        过滤.useLayerMask = true;
        过滤.layerMask = 上方检测图层;
        过滤.useTriggers = true;

        float 扫掠皮肤 = Mathf.Max(皮肤宽度参数, 0.002f);
        int 命中数量 = 玩家碰撞器.Cast(Vector2.up, 过滤, 天花板扫掠缓存, 理想y移动量 + 扫掠皮肤);

        float 最近阻挡距离 = float.PositiveInfinity;
        for (int i = 0; i < 命中数量 && i < 天花板扫掠缓存.Length; i++)
        {
            RaycastHit2D hit = 天花板扫掠缓存[i];
            if (!玩家_二次贴地上抬命中应阻挡(hit))
                continue;

            if (hit.distance < 最近阻挡距离)
                最近阻挡距离 = hit.distance;
        }

        if (float.IsPositiveInfinity(最近阻挡距离))
            return 理想y移动量;

        顶头 = true;
        return Mathf.Max(0f, 最近阻挡距离 - 扫掠皮肤);
    }

    private bool 玩家_二次贴地上抬命中应阻挡(RaycastHit2D hit)
    {
        if (hit.collider == null)
            return false;

        if (hit.collider.transform.root == transform.root)
            return false;

        // 二次贴地是在“上一帧锁定平台/当前脚下地面”的最终X位置重新贴回同一支撑面。
        // 当前支撑地面不能同时被当作头顶阻挡，否则水船/电梯上浮或同一Edge上坡时会把水平位移清零。
        if (玩家_是否应从更高地面采样中排除(hit.collider))
            return false;

        bool 有地面规则 = 地面规则缓存.尝试获取(hit.collider, out 地面规则 规则);
        if (有地面规则 && 地面规则缓存.碰撞器阻挡单位向上穿过(hit.collider, 头顶天花板检测规则))
            return true;

        if (hit.collider.GetComponent<单向线段代理标记>() != null)
            return true;

        // 有地面规则但不阻挡上穿的普通脚下地面，不作为头顶阻挡。
        if (有地面规则)
            return false;

        // 没有地面规则的旧墙体/天花板Collider，仍按旧碰撞层处理为阻挡。
        return true;
    }

    private LayerMask 获取玩家夹角向下检测图层()
    {
        if (玩家夹角向下检测图层.value != 0)
            return 玩家夹角向下检测图层;

        return 地面图层;
    }

    private Vector2 获取玩家夹角自动探测点(float dx方向)
    {
        float 方向 = Mathf.Sign(dx方向);
        if (Mathf.Abs(dx方向) <= 0.0001f)
            方向 = 角色朝向 >= 0 ? 1f : -1f;

        // 优先使用手动左右夹角探测点。
        // 与飞机坐骑保持一致：每帧按世界X坐标判断真正的左/右，避免翻转或父节点缩放导致左右反。
        if (右侧夹角探测点 != null || 左侧夹角探测点 != null)
        {
            Transform 目标点 = null;

            if (右侧夹角探测点 != null && 左侧夹角探测点 != null)
            {
                Transform 世界右点 = 右侧夹角探测点.position.x >= 左侧夹角探测点.position.x
                    ? 右侧夹角探测点
                    : 左侧夹角探测点;

                Transform 世界左点 = 右侧夹角探测点.position.x < 左侧夹角探测点.position.x
                    ? 右侧夹角探测点
                    : 左侧夹角探测点;

                目标点 = 方向 >= 0f ? 世界右点 : 世界左点;
            }
            else
            {
                目标点 = 右侧夹角探测点 != null ? 右侧夹角探测点 : 左侧夹角探测点;
            }

            if (目标点 != null)
                return 目标点.position;
        }

        if (玩家碰撞器 == null)
            return transform.position;

        Bounds b = 玩家碰撞器.bounds;

        float 最大内缩 = Mathf.Max(0f, b.size.x * 0.49f);
        float 内缩 = Mathf.Clamp(玩家自动夹角探测点水平内缩, 0f, 最大内缩);

        float x = 方向 >= 0f ? b.max.x - 内缩 : b.min.x + 内缩;
        float y = Mathf.Lerp(b.min.y, b.max.y, Mathf.Clamp01(玩家自动夹角探测点高度比例));

        return new Vector2(x, y);
    }


    private bool 玩家_飞行员上升不足时需要清零水平(float 本帧x移动量, float 当前y移动量, float 候选y移动量)
    {
        if (Mathf.Abs(本帧x移动量) <= 0.0001f)
            return false;

        // 情况1：前方脚下地面更高，且上方天花板/实体导致上抬不足。
        // 这是旧保护真正要防的“斜坡 + 低顶棚”挤入场景，需要清零X。
        if (玩家碰撞器 != null)
        {
            Bounds b = 玩家碰撞器.bounds;
            float startY = b.max.y + 0.6f;
            float distY = b.size.y + 3.0f;
            float x0 = b.center.x;
            float x1 = x0 + 本帧x移动量;

            float y0 = 采样地面Y(x0, startY, distY);
            float y1 = 采样地面Y(x1, startY, distY);

            if (!float.IsNaN(y0) && !float.IsNaN(y1) && y1 > y0 + 0.001f)
                return true;
        }

        // 情况2：天花板贴附/上顶裁剪后，下方地面已经顶到“地面检测点”，
        // 并且本帧方向会让上下通道继续变窄。这时继续保留X会把飞行员挤进夹缝。
        if (射线起点 == null || 地面检测点 == null)
            return false;

        LayerMask 下方检测图层 = 获取玩家夹角向下检测图层();
        if (下方检测图层.value == 0)
            return false;

        float 射线到地面检测点Y = 地面检测点.position.y - 射线起点.position.y;
        float 向下基础距离 = Mathf.Abs(射线到地面检测点Y);
        if (向下基础距离 <= 0.0001f)
            return false;

        float 容差 = Mathf.Max(0.002f, 地面缓冲距离);
        Vector2 候选射线点 = (Vector2)射线起点.position + new Vector2(本帧x移动量, 候选y移动量);

        bool 下方地面已顶住 = 玩家_目标地面检测点被地面顶住(
            候选射线点,
            向下基础距离,
            射线到地面检测点Y,
            下方检测图层,
            容差,
            out _
        );

        if (!下方地面已顶住)
            return false;

        return 玩家_本帧水平移动让通道变窄(本帧x移动量, 当前y移动量, 下方检测图层);
    }

    private float 获取玩家有效额外检测天花板长度()
    {
        float 额外长度 = Mathf.Max(0f, 玩家额外检测天花板长度);

        if (射线起点 == null || 地面检测点 == null || 玩家碰撞器 == null)
            return 额外长度;

        float 基础头顶距离 = Mathf.Abs(射线起点.position.y - 地面检测点.position.y);
        float 碰撞器顶部距离 = 玩家碰撞器.bounds.max.y - 射线起点.position.y;

        float 补到碰撞器顶部的额外长度 = Mathf.Max(0f, 碰撞器顶部距离 - 基础头顶距离);

        // 玩家原来的“射线起点”和“地面检测点”距离可能很短，导致头顶检测点偏低。
        // 这里不是在 额外长度 和 顶部补偿 二选一，而是：
        // 先至少补到碰撞器顶部，再叠加面板里的“额外检测天花板长度”。
        return 补到碰撞器顶部的额外长度 + 额外长度;
    }

    private void 玩家_评估天花板下压候选(float 本帧x移动量, float 当前y移动量, float 候选y移动量, out bool 可以应用候选Y, out bool 应阻挡水平)
    {
        可以应用候选Y = true;
        应阻挡水平 = false;

        float 下压距离 = 当前y移动量 - 候选y移动量;
        if (下压距离 <= 0.0001f)
            return;

        if (射线起点 == null || 地面检测点 == null)
            return;

        LayerMask 下方检测图层 = 获取玩家夹角向下检测图层();
        if (下方检测图层.value == 0)
            return;

        float 射线到地面检测点Y = 地面检测点.position.y - 射线起点.position.y;
        float 向下基础距离 = Mathf.Abs(射线到地面检测点Y);
        if (向下基础距离 <= 0.0001f)
            return;

        float 容差 = Mathf.Max(0.002f, 地面缓冲距离);

        // 用和天花板贴附同一套“射线起点 / 地面检测点”坐标系判断下方空间。
        // 目标位置的地面检测点已经被地面顶到时，不允许继续应用下压。
        Vector2 目标射线点_候选Y = (Vector2)射线起点.position + new Vector2(本帧x移动量, 候选y移动量);
        if (!玩家_目标地面检测点被地面顶住(目标射线点_候选Y, 向下基础距离, 射线到地面检测点Y, 下方检测图层, 容差, out _))
            return;

        可以应用候选Y = false;

        if (Mathf.Abs(本帧x移动量) <= 0.0001f)
            return;

        // 下方已经没有下压空间时，只有“继续朝上下通道变窄方向推进”才清零X。
        // 如果移动方向让通道变宽，说明是在退出夹角，允许X通过，只是不应用这帧下压。
        if (玩家_本帧水平移动让通道变窄(本帧x移动量, 当前y移动量, 下方检测图层))
            应阻挡水平 = true;
    }

    private bool 玩家_目标地面检测点被地面顶住(
        Vector2 射线点,
        float 向下基础距离,
        float 射线到地面检测点Y,
        LayerMask 下方检测图层,
        float 容差,
        out RaycastHit2D 使用命中)
    {
        使用命中 = default;

        float 检测距离 = 向下基础距离 + 容差 + Mathf.Max(0.002f, 皮肤宽度);
        if (!玩家_尝试获取有效下方地面命中(射线点, 检测距离, 下方检测图层, out RaycastHit2D hit))
            return false;

        float 地面检测点Y = 射线点.y + 射线到地面检测点Y;
        if (hit.point.y >= 地面检测点Y - 容差)
        {
            使用命中 = hit;
            return true;
        }

        return false;
    }

    private bool 玩家_本帧水平移动让通道变窄(float 本帧x移动量, float 当前y移动量, LayerMask 下方检测图层)
    {
        LayerMask 上方检测图层 = 获取玩家夹角向上检测图层();
        if (上方检测图层.value == 0 || 下方检测图层.value == 0)
            return true;

        Vector2 当前点 = (Vector2)射线起点.position + new Vector2(0f, 当前y移动量);
        Vector2 目标点 = (Vector2)射线起点.position + new Vector2(本帧x移动量, 当前y移动量);

        if (!玩家_尝试获取通道高度(当前点, 上方检测图层, 下方检测图层, out float 当前通道高度))
            return true;

        if (!玩家_尝试获取通道高度(目标点, 上方检测图层, 下方检测图层, out float 目标通道高度))
            return true;

        const float 收窄阈值 = 0.01f;
        return 目标通道高度 < 当前通道高度 - 收窄阈值;
    }

    private bool 玩家_尝试获取通道高度(Vector2 起点, LayerMask 上方检测图层, LayerMask 下方检测图层, out float 通道高度)
    {
        通道高度 = 0f;

        float 向上长度 = Mathf.Max(玩家夹角向上射线长度, 获取玩家有效额外检测天花板长度() + 0.5f);
        float 向下长度 = Mathf.Max(玩家夹角向下射线长度, Mathf.Abs(射线起点.position.y - 地面检测点.position.y) + 0.5f);

        if (!玩家_尝试获取有效上方天花板命中(起点, 向上长度, 上方检测图层, out RaycastHit2D 上命中))
            return false;

        if (!玩家_尝试获取有效下方地面命中(起点, 向下长度, 下方检测图层, out RaycastHit2D 下命中))
            return false;

        通道高度 = 上命中.point.y - 下命中.point.y;
        return 通道高度 > 0f;
    }

    private bool 玩家_尝试获取有效上方天花板命中(Vector2 起点, float 长度, LayerMask 图层, out RaycastHit2D 使用命中)
    {
        使用命中 = default;
        if (长度 <= 0f || 图层.value == 0)
            return false;

        ContactFilter2D 过滤 = new ContactFilter2D();
        过滤.useLayerMask = true;
        过滤.layerMask = 图层;
        过滤.useTriggers = true;

        int 数量 = Physics2D.Raycast(起点, Vector2.up, 过滤, 天花板扫掠缓存, 长度);
        float 最近 = float.PositiveInfinity;

        for (int i = 0; i < 数量 && i < 天花板扫掠缓存.Length; i++)
        {
            RaycastHit2D hit = 天花板扫掠缓存[i];
            if (hit.collider == null)
                continue;

            if (hit.collider.transform.root == transform.root)
                continue;

            if (!夹角阻挡助手.命中是可保持间隙天花板(hit))
                continue;

            if (hit.distance < 最近)
            {
                最近 = hit.distance;
                使用命中 = hit;
            }
        }

        return 使用命中.collider != null;
    }

    private bool 玩家_尝试获取有效下方地面命中(Vector2 起点, float 长度, LayerMask 图层, out RaycastHit2D 使用命中)
    {
        使用命中 = default;
        if (长度 <= 0f || 图层.value == 0)
            return false;

        ContactFilter2D 过滤 = new ContactFilter2D();
        过滤.useLayerMask = true;
        过滤.layerMask = 图层;
        过滤.useTriggers = true;

        int 数量 = Physics2D.Raycast(起点, Vector2.down, 过滤, 地面采样缓存, 长度);
        float 最近 = float.PositiveInfinity;

        for (int i = 0; i < 数量 && i < 地面采样缓存.Length; i++)
        {
            RaycastHit2D hit = 地面采样缓存[i];
            if (hit.collider == null)
                continue;

            if (hit.collider.transform.root == transform.root)
                continue;

            bool 是有效脚下地面;
            if (地面规则缓存.尝试获取(hit.collider, out 地面规则 规则))
                是有效脚下地面 = 规则.可作为脚下地面;
            else
                是有效脚下地面 = hit.normal.y > 0.05f;

            if (!是有效脚下地面)
                continue;

            if (hit.distance < 最近)
            {
                最近 = hit.distance;
                使用命中 = hit;
            }
        }

        return 使用命中.collider != null;
    }


    private void 平台搭乘_清理Edge位移源缓存()
    {
        平台搭乘_Edge位移源缓存碰撞体 = null;
        平台搭乘_Edge位移源缓存 = null;
        平台搭乘_Edge位移源缓存已查询 = false;
    }

    private 可搭乘Edge地面位移源 平台搭乘_获取Edge位移源(Collider2D 脚下碰撞体)
    {
        if (脚下碰撞体 == null)
            return null;

        if (平台搭乘_Edge位移源缓存碰撞体 != 脚下碰撞体 || !平台搭乘_Edge位移源缓存已查询)
        {
            平台搭乘_Edge位移源缓存碰撞体 = 脚下碰撞体;
            平台搭乘_Edge位移源缓存 = 脚下碰撞体.GetComponentInParent<可搭乘Edge地面位移源>();
            平台搭乘_Edge位移源缓存已查询 = true;
        }

        if (平台搭乘_Edge位移源缓存 != null
            && 平台搭乘_Edge位移源缓存.enabled
            && 平台搭乘_Edge位移源缓存.是否可搭乘碰撞器(脚下碰撞体))
            return 平台搭乘_Edge位移源缓存;

        return null;
    }

    private bool 平台搭乘_脚下碰撞体允许锁定(Collider2D 脚下碰撞体)
    {
        if (!启用脚下平台锁定)
            return false;

        var edge位移源 = 平台搭乘_获取Edge位移源(脚下碰撞体);
        return edge位移源 != null && edge位移源.启用脚下平台锁定;
    }

    private bool 平台搭乘_尝试获取脚下平台位移(Collider2D 脚下碰撞体, out Vector2 平台位移)
    {
        var edge位移源 = 平台搭乘_获取Edge位移源(脚下碰撞体);
        return 平台位移解析工具.尝试获取脚下平台位移(脚下碰撞体, edge位移源, out 平台位移);
    }

    private bool 平台搭乘_验证指定平台仍在脚下(
        Collider2D 目标平台,
        Transform 实际射线起点,
        Transform 实际地面检测点,
        float 预测x偏移,
        float 预测y偏移,
        out RaycastHit2D 平台命中,
        out float 验证后y移动量)
    {
        平台命中 = default;
        验证后y移动量 = 预测y偏移;

        if (!启用脚下平台锁定 || 目标平台 == null)
            return false;

        if (!目标平台.enabled || !目标平台.gameObject.activeInHierarchy)
            return false;

        if (实际射线起点 == null)
            实际射线起点 = transform;

        float 脚底基准Y = 实际地面检测点 != null
            ? 实际地面检测点.position.y
            : (玩家碰撞器 != null ? 玩家碰撞器.bounds.min.y : transform.position.y);

        float 射线起点相对脚底上抬 = 实际射线起点.position.y - 脚底基准Y;
        float 预测射线起点Y = 脚底基准Y + 预测y偏移 + 射线起点相对脚底上抬;

        float 验证射线长度 = Mathf.Max(射线检测长度, 地面射线检测长度);
        验证射线长度 += Mathf.Abs(预测y偏移) + Mathf.Max(0f, 脚下平台锁定_验证额外射线长度);
        验证射线长度 = Mathf.Max(0.05f, 验证射线长度);

        int 检测图层 = 地面图层.value;
        if (检测图层 == 0)
            return false;

        bool 有命中 = false;
        RaycastHit2D 最佳命中 = default;

        Vector2 中心起点 = new Vector2(实际射线起点.position.x + 预测x偏移, 预测射线起点Y);
        bool 中心有命中 = false;
        RaycastHit2D 中心命中 = default;
        平台搭乘_尝试验证平台射线(中心起点, 验证射线长度, 检测图层, 目标平台, ref 中心有命中, ref 中心命中, false);

        if (中心有命中)
        {
            有命中 = true;
            最佳命中 = 中心命中;
        }
        else if (平台搭乘_启用边缘验证兜底 && 玩家碰撞器 != null && 玩家碰撞器.enabled && 玩家碰撞器.gameObject.activeInHierarchy)
        {
            // 当前锁定平台内部也使用“中心优先、边缘兜底备用”。
            // 中心还站在同一平台上时，不让左右边缘更高的命中抢走贴地高度；
            // 中心已经悬出平台时，左右边缘仍可保持平台边缘兜底。
            Bounds b = 玩家碰撞器.bounds;
            float inset = Mathf.Min(0.05f, b.size.x * 0.1f);
            Vector2 左起点 = new Vector2(b.min.x + inset + 预测x偏移, 预测射线起点Y);
            Vector2 右起点 = new Vector2(b.max.x - inset + 预测x偏移, 预测射线起点Y);

            平台搭乘_尝试验证平台射线(左起点, 验证射线长度, 检测图层, 目标平台, ref 有命中, ref 最佳命中, true);
            平台搭乘_尝试验证平台射线(右起点, 验证射线长度, 检测图层, 目标平台, ref 有命中, ref 最佳命中, true);
        }

        bool 使用脚底基准验证 = false;


        if (!有命中)
        {
            // 保护基准兜底：
            // 普通贴地可能已经把 当前y移动量 拉到较低的场景普通地面。
            // 如果继续用这个错误Y作为锁定验证基准，上一帧锁定的高处废墟Edge会验证失败。
            // 这里回到“当前脚底原始高度”再验证同一个Collider，只影响上一帧已锁定平台，不提高其它废墟地面优先级。
            float 脚底基准射线起点Y = 脚底基准Y + 射线起点相对脚底上抬;
            bool 脚底基准有命中 = false;
            RaycastHit2D 脚底基准最佳命中 = default;
            Vector2 脚底基准中心起点 = new Vector2(实际射线起点.position.x + 预测x偏移, 脚底基准射线起点Y);

            平台搭乘_尝试验证平台射线(脚底基准中心起点, 验证射线长度, 检测图层, 目标平台, ref 脚底基准有命中, ref 脚底基准最佳命中, false);


            if (脚底基准有命中)
            {
                有命中 = true;
                最佳命中 = 脚底基准最佳命中;
                使用脚底基准验证 = true;
            }
        }

        if (!有命中)
            return false;

        float 候选y移动量 = (最佳命中.point.y + 地面缓冲距离) - 脚底基准Y;
        float 最大修正 = Mathf.Max(0f, 脚下平台锁定_最大验证Y修正距离);
        float 验证参考y移动量 = 使用脚底基准验证 ? 0f : 预测y偏移;
        if (最大修正 > 0f && Mathf.Abs(候选y移动量 - 验证参考y移动量) > 最大修正)
            return false;

        平台命中 = 最佳命中;
        验证后y移动量 = 候选y移动量;
        return true;
    }

    private void 平台搭乘_尝试验证平台射线(
        Vector2 起点,
        float 距离,
        int 检测图层,
        Collider2D 目标平台,
        ref bool 有命中,
        ref RaycastHit2D 最佳命中,
        bool 应用边缘兜底端点过滤)
    {
        int 命中数 = Physics2D.RaycastNonAlloc(
            起点,
            Vector2.down,
            平台搭乘_脚下验证命中缓存,
            距离,
            检测图层
        );

        for (int i = 0; i < 命中数; i++)
        {
            RaycastHit2D hit = 平台搭乘_脚下验证命中缓存[i];
            if (hit.collider == null || hit.collider != 目标平台)
                continue;

            if (hit.normal.y <= 0.02f)
                continue;

            if (应用边缘兜底端点过滤 && 斜坡吸附助手.边缘兜底命中过近首尾端点(hit))
                continue;

            if (!有命中 || hit.point.y > 最佳命中.point.y)
            {
                有命中 = true;
                最佳命中 = hit;
            }
        }
    }

    private void 平台搭乘_最终保护上一帧锁定平台(ref RaycastHit2D 当前地面命中, ref float 当前y移动量)
    {
        if (!是否在地面)
            return;

        if (!平台搭乘_上一帧站在地面 || 平台搭乘_上一帧脚下碰撞体 == null)
            return;

        if (当前地面命中.collider == null || 当前地面命中.collider == 平台搭乘_上一帧脚下碰撞体)
            return;

        if (!平台搭乘_脚下碰撞体允许锁定(平台搭乘_上一帧脚下碰撞体))
            return;

        if (!平台搭乘_验证指定平台仍在脚下(
            平台搭乘_上一帧脚下碰撞体,
            射线起点 != null ? 射线起点 : transform,
            地面检测点 != null ? 地面检测点 : transform,
            0f,
            当前y移动量,
            out RaycastHit2D 锁定平台命中,
            out float 锁定平台y移动量))
            return;

        当前地面命中 = 锁定平台命中;
        当前y移动量 = 锁定平台y移动量;
        是否在地面 = true;
        当前脚下地面碰撞器_缓存 = 锁定平台命中.collider;

        if (玩家碰撞器 != null)
            斜坡吸附助手.同步地面吸附记忆(玩家碰撞器, 锁定平台命中);
    }

    private void 平台搭乘_记录本帧结束脚下平台()
    {
        Collider2D 本帧结束脚下 = (是否在地面 && 当前脚下地面碰撞器_缓存 != null)
            ? 当前脚下地面碰撞器_缓存
            : null;

        平台搭乘_上一帧脚下碰撞体 = 本帧结束脚下;
        平台搭乘_上一帧站在地面 = 本帧结束脚下 != null;
    }

    private void 平台搭乘_立即清空脚下平台锁定()
    {
        平台搭乘_上一帧脚下碰撞体 = null;
        平台搭乘_上一帧站在地面 = false;
        平台搭乘_清理Edge位移源缓存();
    }

    private void 清除斜坡吸附内部地面记忆()
    {
        if (玩家碰撞器 == null) return;
        斜坡吸附助手.清除地面吸附记忆(玩家碰撞器);
    }


    public void 开始跳跃()
    {
        //Debug.Log(
        //    $"[进入开始跳跃] 名字={gameObject.name} " +
        //    $"是否在地面={是否在地面} 跳跃高度={跳跃高度} 重力强度={重力强度} " +
        //    $"垂直速度(进入前)={垂直速度} " +
        //    $"状态脚本.弹出坐骑中={(状态脚本 != null ? 状态脚本.弹出坐骑中.ToString() : "null")} " +
        //    $"状态脚本.被击中={(状态脚本 != null ? 状态脚本.被击中.ToString() : "null")} " +
        //    $"状态脚本.当前形态={(状态脚本 != null ? 状态脚本.当前形态.ToString() : "null")}"
        //);

        // 【新增】安全锁：防止空中变身或二段跳BUG
        // 如果当前不在地面，直接忽略这次跳跃请求
        if (!是否在地面)
        {
            Debug.Log($"[开始跳跃内部又被是否在地面拦住] 名字={gameObject.name}");
            return;
        }
        垂直速度 = Mathf.Sqrt(2f * 跳跃高度 * 重力强度);
        跳跃中 = true;

        // ★关键：立刻离地，别等帧末
        清除斜坡吸附内部地面记忆();
        是否在地面 = false;
        当前脚下地面碰撞器_缓存 = null;
        平台搭乘_立即清空脚下平台锁定();
        // 如果物理强行触发跳跃，强制重置一些状态
        if (状态脚本 != null)
        {
            状态脚本.跳跃中 = true;
            状态脚本.停顿中 = false;
            状态脚本.弹出坐骑中 = false;
            状态脚本.上半身隐藏 = false;
            // 注意：这里只是改变量，状态机的状态切换会在下一帧根据这些变量自动发生
        }

        //StartCoroutine(帧末设置地面状态());
    }

    private IEnumerator 帧末设置地面状态()
    {
        yield return new WaitForEndOfFrame();
        是否在地面 = false;
    }

    public void 执行击飞(Vector2 击飞力, bool 禁用输入 = true)
    {
        垂直速度 = 击飞力.y;
        水平速度 = 击飞力.x;
        踩踏弹飞水平速度生效中 = false;

        // 只有明确向上击飞时才强制离地。
        // 向下/水平击飞不主动清除当前地面状态，避免站地单位被向下击飞时进入空中下吸附限制。
        if (击飞力.y > 0.01f)
        {
            清除斜坡吸附内部地面记忆();
            是否在地面 = false;
            当前脚下地面碰撞器_缓存 = null;
            平台搭乘_立即清空脚下平台锁定();
        }

        // 【新增】如果是飞行员形态，激活僵直计时器
        if (状态脚本 != null && 状态脚本.当前形态 == 玩家变身形态.飞行员)
        {
            // 0.2秒的硬直足够产生“弹开”的效果，时间过后立刻恢复控制
            // 你可以调整这个 0.2f 获得不同的手感
            飞行员僵直计时器 = 0.1f;
        }
    }

    public void 接收弹飞(Vector2 弹飞速度, Component 来源, bool 只增大垂直速度, bool 覆盖水平速度)
    {
        // 垂直速度：默认只增大，不把已经上升很快的玩家拉慢
        if (只增大垂直速度)
            垂直速度 = Mathf.Max(垂直速度, 弹飞速度.y);
        else
            垂直速度 = 弹飞速度.y;

        // 水平速度：默认不改，除非范围弹飞器明确要求覆盖
        if (覆盖水平速度)
        {
            水平速度 = 弹飞速度.x;
            踩踏弹飞水平速度生效中 = 来源 is 踩踏弹飞器;
        }

        // 强制离地，避免下一帧继续被当地面站立状态处理
        清除斜坡吸附内部地面记忆();
        是否在地面 = false;
        当前脚下地面碰撞器_缓存 = null;
        平台搭乘_立即清空脚下平台锁定();
        跳跃中 = true;

        if (状态脚本 != null)
        {
            状态脚本.跳跃中 = true;
            状态脚本.停顿中 = false;
            状态脚本.弹出坐骑中 = false;
            状态脚本.上半身隐藏 = false;
        }

        // 飞行员形态沿用你原本“击飞僵直”的思路，避免刚被顶飞立刻被输入抵消
        if (状态脚本 != null && 状态脚本.当前形态 == 玩家变身形态.飞行员)
        {
            飞行员僵直计时器 = 0.1f;
        }
    }

    bool I脚下地面碰撞器.是否在地面 => 是否在地面;

    public Collider2D 当前脚下地面碰撞器 => 当前脚下地面碰撞器_缓存;

    public bool 是否站在指定地面(Collider2D 地面碰撞器)
    {
        if (地面碰撞器 == null) return false;
        if (!是否在地面) return false;
        if (当前脚下地面碰撞器_缓存 == null) return false;

        return 当前脚下地面碰撞器_缓存 == 地面碰撞器;
    }

    private void 更新当前脚下地面碰撞器缓存(RaycastHit2D 地面碰撞信息)
    {
        if (是否在地面 && 地面碰撞信息.collider != null)
        {
            当前脚下地面碰撞器_缓存 = 地面碰撞信息.collider;
        }
        else
        {
            当前脚下地面碰撞器_缓存 = null;
        }
    }

    // ==========================================
    // I实时速度提供者 / I脚底范围提供者
    // ==========================================

    public Vector2 当前实时速度
    {
        get
        {
            // X 方向：优先用本帧最终位移换算出来的真实水平速度，
            // 这样包含主动输入、惯性、平台拖动、墙体裁剪后的结果。
            float vx = 当前最终速度.x;

            // 如果还没经过第一帧 FixedUpdate，当前最终速度可能还是0。
            // 这里给一个兜底估算，避免刚生成/刚启用时踩踏检测拿不到横向速度。
            if (Mathf.Abs(vx) < 0.0001f && 状态脚本 != null && !状态脚本.停顿中)
            {
                float 当前移动速度 = 移动速度;
                if (!系统控制中 && 状态脚本.蹲下中)
                    当前移动速度 /= 3f;

                vx = 水平输入 * 当前移动速度 + 水平速度;
            }

            // Y 方向：用内部垂直速度最准确。
            // 踩踏弹飞器需要判断“是否正在下落”，这个值比最终位移更适合。
            return new Vector2(vx, 垂直速度);
        }
    }

    public bool 尝试获取脚底检测Bounds(out Bounds 脚底Bounds)
    {
        if (踩踏用玩家被击框 != null &&
            踩踏用玩家被击框.enabled &&
            踩踏用玩家被击框.gameObject.activeInHierarchy)
        {
            脚底Bounds = 踩踏用玩家被击框.bounds;
            return true;
        }

        脚底Bounds = default;
        return false;
    }

    public float 获取当前垂直速度() => 垂直速度;

    public void 执行弹出(float 弹出速度)
    {
        刚体.bodyType = RigidbodyType2D.Kinematic;
        垂直速度 = 弹出速度;
        清除斜坡吸附内部地面记忆();
        是否在地面 = false;
        当前脚下地面碰撞器_缓存 = null;
        平台搭乘_立即清空脚下平台锁定();
        跳跃中 = true;
        //状态脚本.弹出坐骑中 = true;
    }

    /// <summary>
    /// 弹跳回调 - 踩到敌人时调用
    /// </summary>
    void 执行弹跳(float 弹跳速度)
    {
        // 直接设置垂直速度
        垂直速度 = 弹跳速度;
        清除斜坡吸附内部地面记忆();
        是否在地面 = false;
        当前脚下地面碰撞器_缓存 = null;
        平台搭乘_立即清空脚下平台锁定();
        跳跃中 = true;

        if (状态脚本 != null)
        {
            状态脚本.跳跃中 = true;
        }
    }

    private 碎块生成器 生成器;

    private 简易推动系统 _推动系统;


    // ========== I挤压目标 接口实现 ==========

    /// <summary>返回用于挤压计算的主碰撞框</summary>
    public BoxCollider2D 挤压_获取主碰撞框()
    {
        return 玩家碰撞器;
    }

    /// <summary>摄像机触碰触发器主动检测时使用的玩家主物理碰撞器。</summary>
    public BoxCollider2D 获取摄像机触发主碰撞器()
    {
        return 玩家碰撞器;
    }

    /// <summary>当前是否在地面（直接返回"是否在地面"字段）</summary>
    public bool 挤压_当前是否在地面()
    {
        if (是否在地面) return true;
        if (玩家碰撞器 == null) return false;

        // 用你自己的"地面图层"，并且包含 Trigger（你工程里很多检测都用 trigger）
        ContactFilter2D filter = new ContactFilter2D();
        filter.useLayerMask = true;
        filter.layerMask = 地面图层;
        filter.useTriggers = true;

        Bounds b = 玩家碰撞器.bounds;
        float inset = Mathf.Min(0.05f, b.size.x * 0.2f);

        Vector2 pL = new Vector2(b.min.x + inset, b.min.y + 0.02f);
        Vector2 pR = new Vector2(b.max.x - inset, b.min.y + 0.02f);

        int n1 = Physics2D.Raycast(pL, Vector2.down, filter, 挤压_地面检测缓存, 挤压_压死贴地容忍距离);
        if (存在有效脚下地面命中(挤压_地面检测缓存, n1)) return true;

        int n2 = Physics2D.Raycast(pR, Vector2.down, filter, 挤压_地面检测缓存, 挤压_压死贴地容忍距离);
        return 存在有效脚下地面命中(挤压_地面检测缓存, n2);
    }


    /// <summary>
    /// 接收一小段"额外水平推动位移"（由 挤压体 调用）
    /// 在下一帧的 处理移动() 里，会把它加到 原始总x移动量 里，然后清零
    /// </summary>
    public void 挤压_被水平推动(float 推动量)
    {
        //挤压_额外水平位移 += 推动量;
    }

    /// <summary>
    /// 被挤压死亡（由 挤压体 调用）
    /// 这里可以直接复用你原来的"被挤压死亡"逻辑
    /// </summary>
    public void 挤压_被挤压死亡(Vector2 挤压方向, Component 来源)
    {
        // 出生保护期间，完全免疫挤压死亡
        if (出生保护中)
        {
            return;
        }

        // 已经进入挤压死亡流程时，禁止重复进入
        if (挤压死亡处理中)
        {
            return;
        }

        挤压死亡处理中 = true;

        // 立刻关闭主碰撞器，避免 Destroy 真正执行前又被重复检测到
        if (玩家碰撞器 != null)
        {
            玩家碰撞器.enabled = false;
        }

        // 触发死亡逻辑
        if (状态脚本 != null)
        {
            // 先把生命值置 0，确保死亡快照是“死亡模板”
            if (引用玩家数据 != null)
            {
                // 先把生命值置 0，确保死亡音效/死亡特效逻辑能正确命中
                引用玩家数据.生命值 = 0f;

                // ✅ 现在再播放死亡音效
                引用玩家数据.被击播放音效();

                事件中心UI_new.更新能量条(引用玩家数据.玩家P, 0f, 引用玩家数据.最大生命值, false);

                // ★★★ 关键修复：真正销毁玩家节点前，立刻提交死亡复活快照 ★★★
                引用玩家数据.提交死亡复活快照();
            }

            // 生成碎块
            if (生成器 != null)
            {
                Vector2 死亡位置 = transform.position;

                var 掉落组件 = GetComponent<物品掉落容器>();
                if (掉落组件 != null)
                {
                    掉落组件.死亡时自动掉落 = true;
                }

                生成器.生成碎块(死亡位置);
                Debug.LogWarning($"玩家被 {(来源 ? 来源.name : "屏幕/未知")} 挤死！...");
            }

            Destroy(gameObject);
        }
    }

    /// <summary>
    /// 按挤压体当作"实心身体"来约束玩家自己的水平位移
    /// </summary>
    float 挤压_约束水平移动_被实体阻挡(float 原始dx)
    {
        // 旧横向实体阻挡停用。
        // 这一步先让玩家彻底脱离旧 挤压体 逻辑。
        // 新横向系统（主动阻挡 / 被动推动 / 权重 / 挤死）下一步单独接。
        return 原始dx;
    }
    // —— 挤压辅助：记录本帧左右两侧是否被墙/边界挡住 ——
    bool 挤压_右侧被墙挡 = false;
    bool 挤压_左侧被墙挡 = false;

    public bool 挤压_本帧某方向被墙挡(int 方向)
    {
        int dir = 方向 >= 0 ? 1 : -1;
        if (dir > 0) return 挤压_右侧被墙挡;
        else return 挤压_左侧被墙挡;
    }

    bool 新挤压_解析头顶纵向约束(
    float 原始想y移动量,
    out float 修正后想y移动量,
    out 挤压标志 阻挡来源,
    out bool 来自顶部阻挡,
    out bool 来自有效下压)
    {
        修正后想y移动量 = 原始想y移动量;
        阻挡来源 = null;
        来自顶部阻挡 = false;
        来自有效下压 = false;

        if (玩家碰撞器 == null) return false;

        挤压检测助手.收集头顶候选(
            玩家碰撞器,
            transform.root,
            新挤压检测图层,
            新挤压头顶条带高度,
            新挤压头顶射线长度,
            新挤压头顶射线间距,
            新挤压绘制调试,
            新挤压_头顶候选缓存
        );

        if (新挤压_头顶候选缓存.Count == 0)
            return false;

        Bounds 我 = 玩家碰撞器.bounds;

        bool 命中 = false;
        float 最终建议y = 原始想y移动量;

        for (int i = 0; i < 新挤压_头顶候选缓存.Count; i++)
        {
            挤压来源候选 来源 = 新挤压_头顶候选缓存[i];
            挤压标志 标志 = 来源.标志;
            if (标志 == null) continue;
            if (!标志.enabled || !标志.gameObject.activeInHierarchy) continue;

            Bounds 他 = 来源.参考Bounds;
            if (他.size.sqrMagnitude <= 0.000001f) continue;

            bool 是顶部阻挡 =
                原始想y移动量 > 0f &&
                挤压检测助手.是否满足顶部阻挡(
                    标志, 我, 他, 玩家碰撞器 != null ? 玩家碰撞器.gameObject : gameObject, 原始想y移动量);

            bool 是有效下压 =
                挤压检测助手.是否满足有效下压(
                    标志, 我, 他, 玩家碰撞器 != null ? 玩家碰撞器.gameObject : gameObject, Mathf.Max(0f, 原始想y移动量));

            if (!是顶部阻挡 && !是有效下压)
                continue;

            float 候选y = 原始想y移动量;

            if (是顶部阻挡)
            {
                候选y = Mathf.Min(
                    候选y,
                    挤压检测助手.计算向上贴底允许位移(
                        我, 他, Mathf.Max(0f, 原始想y移动量), 标志.纵向接触容差)
                );
            }

            if (是有效下压)
            {
                候选y = Mathf.Min(
                    候选y,
                    挤压检测助手.计算被下压时建议竖直位移(
                        我, 他, 原始想y移动量, 标志.纵向接触容差)
                );
            }

            if (!命中 || 候选y < 最终建议y)
            {
                命中 = true;
                最终建议y = 候选y;
                阻挡来源 = 标志;
                来自顶部阻挡 = 是顶部阻挡 && !是有效下压;
                来自有效下压 = 是有效下压;
            }
        }

        if (!命中)
            return false;

        修正后想y移动量 = 最终建议y;
        return true;
    }

    float 新挤压_约束水平主动移动(float 原始dx)
    {
        return 新挤压_约束水平主动移动(原始dx, null, false);
    }

    float 新挤压_约束水平主动移动(float 原始dx, 挤压标志 忽略来源)
    {
        return 新挤压_约束水平主动移动(原始dx, 忽略来源, false);
    }

    float 新挤压_约束水平主动移动(
        float 原始dx,
        挤压标志 忽略来源,
        bool 屏幕边界补推时忽略不可挤死来源)
    {
        if (玩家碰撞器 == null) return 原始dx;
        if (Mathf.Abs(原始dx) <= 0.0001f) return 原始dx;

        Bounds 我 = 玩家碰撞器.bounds;
        GameObject 目标节点 = 玩家碰撞器 != null ? 玩家碰撞器.gameObject : gameObject;
        float 当前dx = 原始dx;

        挤压检测助手.收集所有有效来源(transform.root, 新挤压_水平候选缓存);

        for (int i = 0; i < 新挤压_水平候选缓存.Count; i++)
        {
            挤压来源候选 来源 = 新挤压_水平候选缓存[i];
            挤压标志 标志 = 来源.标志;
            if (标志 == null) continue;
            if (忽略来源 != null && 标志 == 忽略来源) continue;

            // 屏幕边界正在向屏内补推玩家时，边界优先级高于“不可挤死”的挤压阻挡。
            // 这里只跳过当前玩家目标的阻挡计算，不修改 挤压标志 的公共状态，
            // 因此不会影响坐骑、其他玩家或其他单位各自独立的挤压判定。
            if (屏幕边界补推时忽略不可挤死来源 && !标志.水平挤死) continue;

            Bounds 他 = 来源.参考Bounds;
            if (他.size.sqrMagnitude <= 0.000001f) continue;

            当前dx = 挤压检测助手.计算水平主动阻挡后位移(
                标志, 我, 他, 目标节点, 当前dx);
        }

        return 当前dx;
    }

    bool 新挤压_尝试获取被动推动(out 挤压标志 推动来源, out float 推动位移)
    {
        推动来源 = null;
        推动位移 = 0f;

        if (玩家碰撞器 == null) return false;

        Bounds 我 = 玩家碰撞器.bounds;
        float 最强推动绝对值 = 0f;

        挤压检测助手.收集所有有效来源(transform.root, 新挤压_水平候选缓存);

        for (int i = 0; i < 新挤压_水平候选缓存.Count; i++)
        {
            挤压来源候选 来源 = 新挤压_水平候选缓存[i];
            挤压标志 标志 = 来源.标志;
            if (标志 == null) continue;

            Bounds 他 = 来源.参考Bounds;
            if (他.size.sqrMagnitude <= 0.000001f) continue;

            if (!挤压检测助手.尝试计算被动推动位移(
    标志, 我, 他, 玩家碰撞器 != null ? 玩家碰撞器.gameObject : gameObject, 新挤压推动权重, out float 候选推动位移))
                continue;

            float 强度 = Mathf.Abs(候选推动位移);
            if (推动来源 == null || 强度 > 最强推动绝对值)
            {
                推动来源 = 标志;
                推动位移 = 候选推动位移;
                最强推动绝对值 = 强度;
            }
        }

        return 推动来源 != null;
    }

    bool 挤压_获取当前有效下压(out Component 下压来源, out float 建议下压位移)
    {
        // 旧“从 挤压体 获取有效下压”的逻辑停用。
        // 现在玩家的纵向新系统全部走：
        // 挤压标志 + 挤压检测助手 + 新挤压_解析头顶纵向约束
        下压来源 = null;
        建议下压位移 = 0f;
        return false;
    }

    /// <summary>
    /// 按挤压体当作"实心身体"来约束玩家自己的垂直位移（只阻挡向上）
    /// 规则：
    /// - 只在"还没重叠、要撞到头顶"的时候阻挡；
    /// - 如果已经重叠（间距<=0），不在这里处理，以免卡死，允许向上离开重叠。
    /// </summary>
    /// <summary>
    /// 按挤压体当作"实心身体"来约束玩家自己的垂直位移（只阻挡向上）
    /// 规则：
    /// - 快要撞到头顶时：限制移动量，最多走到贴住
    /// - 已经重叠时：允许向上移动，尝试脱离重叠
    /// </summary>
    float 挤压_约束垂直移动_被实体阻挡(float 原始dy)
    {
        // 旧纵向实体阻挡停用。
        // 现在统一由新纵向系统处理头顶阻挡 / 有效下压。
        return 原始dy;
    }

    float 挤压_约束垂直移动_仅在有效下压时阻挡(float 原始dy)
    {
        // 旧包装方法停用。
        return 原始dy;
    }

    public void 挤压_被垂直推动(float 推动量)
    {
        挤压_额外垂直位移 += 推动量;
    }

    void 设置不同形态的射线长度()
    {
        // 保留空函数以兼容现有调用，但不再覆盖 Inspector 中配置的射线检测长度。
    }

    public void 应用飞行员背包最终状态(bool 应显示背包, bool 前进喷火)
    {
        if (飞行员背包节点 != null && 飞行员背包节点.activeSelf != 应显示背包)
        {
            飞行员背包节点.SetActive(应显示背包);
        }

        if (飞行员背包动画器 == null)
            return;

        // 【关键修复】没有 AnimatorController 时，不要再 SetBool，否则会疯狂报错
        if (!飞行员背包动画器.isActiveAndEnabled)
            return;

        if (飞行员背包动画器.runtimeAnimatorController == null)
            return;

        if (!飞行员背包动画器.gameObject.activeInHierarchy)
            return;

        飞行员背包动画器.SetBool("背包喷火前进", 应显示背包 && 前进喷火);
    }

    // ================= I平台搭乘者 接口实现 =================
    public float 当前垂直速度 => 垂直速度; // ★ 新增：暴露玩家的垂直速度
    public void 被平台接住(float 缺口)
    {
        挤压_被垂直推动(缺口);
        垂直速度 = 0f;
        是否在地面 = true;
    }

    public void 接收平台拖动(Vector2 拖动量)
    {
        // 玩家自己有一套“脚下地面位移源”搭乘逻辑（平台附加位移.x / y）。
        // 平台顶部的盒推挤直接忽略，防止双重位移！
    }

    public bool 当前是否在地面 => 是否在地面;

    private void 同步地面规则到碰撞处理器()
    {
        if (碰撞处理器 == null) return;
        碰撞处理器.天花板地面检测规则 = 头顶天花板检测规则;
    }

    private bool 存在有效脚下地面命中(RaycastHit2D[] 命中缓存, int 数量)
    {
        if (命中缓存 == null || 数量 <= 0) return false;
        for (int i = 0; i < 数量 && i < 命中缓存.Length; i++)
        {
            RaycastHit2D hit = 命中缓存[i];
            if (hit.collider == null) continue;
            if (地面规则缓存.命中可作为脚下地面(hit, 脚下地面检测规则))
                return true;
        }
        return false;
    }

    private bool 存在有效头顶地面命中(RaycastHit2D[] 命中缓存, int 数量, bool 排除当前脚下或锁定平台 = false)
    {
        if (命中缓存 == null || 数量 <= 0) return false;
        for (int i = 0; i < 数量 && i < 命中缓存.Length; i++)
        {
            RaycastHit2D hit = 命中缓存[i];
            if (hit.collider == null) continue;
            if (hit.collider.transform.root == transform.root) continue;
            if (排除当前脚下或锁定平台 && 玩家_是否应从更高地面采样中排除(hit.collider)) continue;
            if (地面规则缓存.碰撞器阻挡单位向上穿过(hit.collider, 头顶天花板检测规则))
                return true;

            // 屏幕边界/墙壁代理仍交给 与单向墙碰撞 自己处理；这里专门过滤新规则地面。
            if (hit.collider.GetComponent<单向线段代理标记>() != null)
                return true;
        }
        return false;
    }

    private void OnEnable()
    {
        跳跃中 = false;
        水平速度 = 0f;
        踩踏弹飞水平速度生效中 = false;
        垂直速度 = 0f;

        新挤压_上帧存在有效下压 = false;
        新挤压_上帧有效下压来源 = null;
        当前继承平台水平速度 = 0f;
    }








    // I水平推动目标信息：只读暴露，不改变玩家原有移动流程。
    BoxCollider2D I水平推动目标信息.水平推动_获取主碰撞框() => 玩家碰撞器;
    GameObject I水平推动目标信息.水平推动_获取过滤目标节点() => 玩家碰撞器 != null ? 玩家碰撞器.gameObject : gameObject;
    int I水平推动目标信息.水平推动_获取被推动权重() => 新挤压推动权重;
    bool I水平推动目标信息.水平推动_允许被来源推动(挤压标志 来源) => 来源 != null;
    int I水平推动目标信息.水平推动_获取主动移动方向()
    {
        if (状态脚本 != null && 状态脚本.被击中 && 状态脚本.已死亡)
            return 0;

        bool 停顿中 = 状态脚本 != null && 状态脚本.停顿中;
        if (停顿中 && !系统控制中)
            return 0;

        return 水平输入 > 0 ? 1 : (水平输入 < 0 ? -1 : 0);
    }

}
