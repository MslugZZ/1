using UnityEngine;
using System.Reflection;

public enum 人类子模式
{
    默认,
    持枪
}

public abstract class 玩家状态基类new
{
    protected 玩家状态控制器new 玩家;
    protected 玩家下半身节点 下半身节点脚本;

    public virtual bool 是停顿状态 => false;
    public virtual bool 是攻击状态 => false;
    public virtual bool 锁定朝向 => false;
    public virtual bool 是蹲下状态 => false;
    public virtual bool 需要隐藏上半身 => false;

    public virtual bool 是前进状态 => false;
    public virtual bool 是落地动作状态 => false;
    public virtual bool 落地跳过落地动作 => false;
    public virtual string 动作同步标签 => "";
    public virtual bool 阻止状态切换 => false;
    public virtual bool 切换时更新状态集合引用 => true;
    public virtual bool 使用低碰撞器 => false;

    public void 初始化(玩家状态控制器new 玩家控制器)
    {
        玩家 = 玩家控制器;
        下半身节点脚本 = 玩家控制器.下半身节点脚本;
    }

    public virtual void 进入() { }
    public virtual void 逻辑更新() { }
    public virtual void 退出() { }
    public virtual 玩家状态基类new 检查过渡条件() { return null; }

    protected 玩家状态基类new 检查进入坐骑()
    {
        return 玩家.检查进入坐骑();
    }

    public I上半身状态集合 所属上半身状态集合 { get; private set; }
    public I下半身状态集合 所属下半身状态集合 { get; private set; }

    public void 绑定所属上半身状态集合(I上半身状态集合 集合)
    {
        所属上半身状态集合 = 集合;
    }

    public void 绑定所属下半身状态集合(I下半身状态集合 集合)
    {
        所属下半身状态集合 = 集合;
    }


}

public abstract class 状态集合自动初始化
{
    public void 初始化所有状态(玩家状态控制器new 玩家)
    {
        var fields = GetType().GetFields(BindingFlags.Public | BindingFlags.Instance);

        foreach (var field in fields)
        {
            if (!typeof(玩家状态基类new).IsAssignableFrom(field.FieldType))
                continue;

            var 状态 = field.GetValue(this) as 玩家状态基类new;
            if (状态 == null)
                continue;

            状态.初始化(玩家);

            if (this is I上半身状态集合 上半身集合)
                状态.绑定所属上半身状态集合(上半身集合);

            if (this is I下半身状态集合 下半身集合)
                状态.绑定所属下半身状态集合(下半身集合);
        }
    }
}
