using System.Collections.Generic;
using UnityEngine;
using 正常人类;

public interface I上半身状态集合
{
    玩家状态基类new 取基础状态(玩家状态控制器new 玩家);
    玩家状态基类new 取透明状态(玩家状态控制器new 玩家);
    玩家状态基类new 取透明恢复状态(玩家状态控制器new 玩家);
    玩家状态基类new 取坐骑受击弹出恢复状态(玩家状态控制器new 玩家);
}

public interface I下半身状态集合
{
    玩家状态基类new 取基础状态(玩家状态控制器new 玩家);
    玩家状态基类new 取坐骑受击弹出恢复状态(玩家状态控制器new 玩家);
    玩家状态基类new 取进入坐骑状态(玩家状态控制器new 玩家);
    玩家状态基类new 取弹出坐骑状态(玩家状态控制器new 玩家);
}

public interface I技能下半身被击出口
{
    玩家状态基类new 取技能中被击状态(玩家状态控制器new 玩家);
}

public enum 玩家变身形态
{
    正常人类,
    胖子,
    木乃伊,
    僵尸,
    飞行员
}

public enum 状态方案键
{
    正常人类默认,
    正常人类持枪,

    胖子,
    木乃伊,
    僵尸,
    飞行员默认,
    飞行员持枪
}
public enum 持枪武器大类
{
    无,
    机枪,
    激光枪,
    G
}

[System.Serializable]
public class 角色形态动画器配置new
{
    public 状态方案键 状态方案;
    public string 配置名 = "马克_正常人类默认";
    public int 角色ID = 0;
    public 玩家变身形态 形态 = 玩家变身形态.正常人类;
    public 人类子模式 子模式 = 人类子模式.默认;
    public RuntimeAnimatorController 上半身动画器文件;
    public RuntimeAnimatorController 下半身动画器文件;
}

[System.Serializable]
public class 角色ID显示名配置new
{
    public int 角色ID = 0;
    public string 角色名 = "";
}

public class 玩家状态控制器new : MonoBehaviour
{
    [Header("=== 核心连接 ===")]
    public 玩家控制器new 物理脚本;
    public 玩家数据 数据脚本;
    public 通用生成预制体 通用生成预制体脚本;
    public 角色喷血控制 喷血脚本;
    public 动画事件接收器 上半身动画事件接收器;
    public 动画事件接收器 下半身动画事件接收器;
    public Animator 上半身动画器;
    public Animator 下半身动画器;
    public SpriteRenderer 上半身精灵渲染器;
    public SpriteRenderer 下半身精灵渲染器;
    public Transform 上半身节点对象;
    public 玩家下半身节点 下半身节点脚本;
    private float 上一帧施加的偏移量X = 0f;
    private float 上一帧施加的偏移量Y = 0f;
    [SerializeField] private 全局输入管理器 全局输入;
    public GameObject 近身节点;
    public GameObject 玩家被击框;

    [Header("=== 当前角色与形态 ===")]
    public int 当前角色ID = 0;
    public 玩家变身形态 当前形态 = 玩家变身形态.正常人类;
    public 人类子模式 当前人类子模式 = 人类子模式.默认;

    [Header("=== 形态切换保护 ===")]
    public float 形态切换无敌时间 = 3f;

    [Header("=== 角色/形态 Animator 配置（列表项可折叠） ===")]
    public List<角色形态动画器配置new> 动画器配置列表 = new List<角色形态动画器配置new>();
    [SerializeField] private List<角色ID显示名配置new> 角色显示名列表 = new List<角色ID显示名配置new>();

    [Header("=== 运行黑板 ===")]
    public int 水平按键;
    public int 垂直按键;
    public bool 跳跃键_触发;
    public bool 开枪键_触发;
    public bool 扔雷键_触发;
    public bool 自爆键_触发;
    public bool 特殊攻击键_触发;
    public bool 特殊攻击键2_触发;
    public bool 切换武器键_触发;
    public bool 反向中;
    public bool 是否在地面;
    public bool 跳跃中;
    public bool 蹲下中;
    public bool 停顿中;
    public bool 攻击中;
    public bool 锁定朝向中;
    public bool 上半身隐藏;
    public bool 持枪状态;
    public bool 近身标志;
    public bool 已死亡;
    public int 状态ID;
    public int 当前子弹ID;
    public float 生命值;
    public float 前进计时;
    public int 出刀标志;
    public float 开枪间隔;
    public float 扔雷间隔;
    public float 出刀间隔;
    public float 开枪初始间隔 = 0.15f;
    public float 扔雷初始间隔 = 0.2f;
    public float 出刀初始间隔 = 0.35f;
    public float 当前垂直速度;
    public int 玩家P;
    public bool 被击中;
    public bool 弹出坐骑中;
    public bool 落地动作中;
    public bool 本次转身已翻转;

    [Header("=== 形态专属攻击间隔 ===")]
    public float 木乃伊站立扔雷间隔 = 0.4f;
    public float 木乃伊蹲下扔雷间隔 = 0.3f;

    public bool 玩家被击;
    public int 被击属性;

    [Header("【僵尸专属特效】")]
    public GameObject 僵尸复活闪电预制体;
    public float 闪电等待时长 = 1.0f;
    public GameObject 僵尸溅射预制体;
    public GameObject 被刀喷血;

    [Header("【木乃伊变身特效】")]
    public GameObject 木乃伊变身烟雾预制体;
    public Vector3 木乃伊变身烟雾偏移 = Vector3.zero;

    [Header("=== 状态集合 ===")]
    public 默认上半身状态集合 默认上半身状态 = new 默认上半身状态集合();
    public 默认下半身状态集合 默认下半身状态 = new 默认下半身状态集合();
    public 持枪上半身状态集合 持枪上半身状态 = new 持枪上半身状态集合();
    public 持枪下半身状态集合 持枪下半身状态 = new 持枪下半身状态集合();

    //以下还没制作,等制作时再取消注释;

    public 胖子上半身状态集合 胖子上半身状态 = new 胖子上半身状态集合();
    public 胖子下半身状态集合 胖子下半身状态 = new 胖子下半身状态集合();

    public 木乃伊上半身状态集合 木乃伊上半身状态 = new 木乃伊上半身状态集合();
    public 木乃伊下半身状态集合 木乃伊下半身状态 = new 木乃伊下半身状态集合();

    public 僵尸上半身状态集合 僵尸上半身状态 = new 僵尸上半身状态集合();
    public 僵尸下半身状态集合 僵尸下半身状态 = new 僵尸下半身状态集合();

    public 飞行员上半身状态集合 飞行员上半身状态 = new 飞行员上半身状态集合();
    public 飞行员下半身状态集合 飞行员下半身状态 = new 飞行员下半身状态集合();

    public 玩家技能状态集合 玩家技能状态 = new 玩家技能状态集合();

    [Header("=== 当前状态 ===")]
    public 玩家状态基类new 当前上半身状态;
    public 玩家状态基类new 当前下半身状态;

    public I上半身状态集合 当前上半身状态集合;
    public I下半身状态集合 当前下半身状态集合;
    public I上半身状态集合 期望上半身状态集合;
    public I下半身状态集合 期望下半身状态集合;

    [Header("=== 当前技能 ===")]
    public 玩家技能槽位 当前激活技能槽位 = 玩家技能槽位.无;
    public 玩家技能映射 当前激活技能映射;
    public bool 技能系统启用 = true;

    [Header("=== 调试 ===")]
    public bool 输出上半身状态切换日志 = true;
    public bool 输出下半身状态切换日志 = true;

    public bool 上半身动画播完 => 上半身动画事件接收器 != null && 上半身动画事件接收器.动画已结束;
    public bool 下半身动画播完 => 下半身动画事件接收器 != null && 下半身动画事件接收器.动画已结束;

    private int 上一帧角色ID = -999;
    private 玩家变身形态 上一帧形态;
    private 人类子模式 上一帧人类子模式;
    private bool 玩家被击待下一帧清理 = false;
    private int 玩家被击记录帧 = -1;

    [Header("=== 动画事件中转引用 ===")]
    public 生成子弹new 生成子弹脚本引用;
    public 玩家近身检测 玩家近身检测引用;
    public 闪烁后销毁 闪烁后销毁引用;
    public 身体颠簸控制器 身体颠簸控制器引用;

    [Header("=== 坐骑 ===")]
    public 玩家进入坐骑检测new 坐骑检测脚本;
    public 坐骑入口new 绑定的目标坐骑;

    private 玩家变身形态 上一次已应用形态;
    private 人类子模式 上一次已应用人类子模式;
    private bool 待刷新状态方案 = true;
    private bool 待强制刷新动画器 = true;

    [Header("=== 结算胜利动作 ===")]
    private bool 待切换结算胜利动作 = false;
    private bool 已切换过结算胜利动作 = false;

    public bool 当前角色支持目标形态(玩家变身形态 目标形态)
    {
        switch (目标形态)
        {
            case 玩家变身形态.正常人类:
                return true;

            // 飞行员不归“受击/食物变身限制”管
            // 飞行关卡强制形态仍然允许
            case 玩家变身形态.飞行员:
                return true;

            case 玩家变身形态.木乃伊:
                // 角色ID = 4 / 5 / 6 都没有木乃伊
                return 当前角色ID != 4 && 当前角色ID != 5 && 当前角色ID != 6;

            case 玩家变身形态.胖子:
                // 角色ID = 4 / 5 / 6 都没有胖子
                return 当前角色ID != 4 && 当前角色ID != 5 && 当前角色ID != 6;

            case 玩家变身形态.僵尸:
                // 角色ID = 4 / 6 没有僵尸
                // 角色ID = 5 有僵尸
                return 当前角色ID != 4 && 当前角色ID != 6;

            default:
                return true;
        }
    }

    void Awake()
    {
        if (全局输入 == null) 全局输入 = 全局输入管理器.实例;
        if (物理脚本 == null) 物理脚本 = GetComponent<玩家控制器new>();
        if (数据脚本 == null) 数据脚本 = GetComponent<玩家数据>();
        if (通用生成预制体脚本 == null) 通用生成预制体脚本 = GetComponent<通用生成预制体>();
        if (喷血脚本 == null) 喷血脚本 = GetComponent<角色喷血控制>();
        if (上半身动画器 != null && 上半身动画事件接收器 == null)
            上半身动画事件接收器 = 上半身动画器.GetComponent<动画事件接收器>();
        if (下半身动画器 != null && 下半身动画事件接收器 == null)
            下半身动画事件接收器 = 下半身动画器.GetComponent<动画事件接收器>();
        if (坐骑检测脚本 == null)
            坐骑检测脚本 = GetComponentInChildren<玩家进入坐骑检测new>(true);
        if (上半身动画器 != null && 上半身精灵渲染器 == null)
            上半身精灵渲染器 = 上半身动画器.GetComponent<SpriteRenderer>();
        if (下半身动画器 != null && 下半身精灵渲染器 == null)
            下半身精灵渲染器 = 下半身动画器.GetComponent<SpriteRenderer>();

        自动初始化所有状态集合();
    }

    void OnEnable()
    {
        待刷新状态方案 = true;
        待强制刷新动画器 = true;

        // ==========================================
        // 【新增】运行时重新激活玩家时，强制清理“坐骑流程残留状态”
        // 否则会出现：能移动、能开枪，但跳跃键被弹出坐骑中等标志拦住
        // ==========================================
        弹出坐骑中 = false;
        被击中 = false;
        玩家被击 = false;
        被击属性 = 0;
        本次转身已翻转 = false;

        当前激活技能槽位 = 玩家技能槽位.无;
        当前激活技能映射 = null;

        待切换结算胜利动作 = false;
        已切换过结算胜利动作 = false;

        // 清空当前状态引用，让 Start / 后续同步时重新回到基础状态
        当前上半身状态 = null;
        当前下半身状态 = null;
        当前上半身状态集合 = null;
        当前下半身状态集合 = null;

        if (坐骑检测脚本 == null)
            坐骑检测脚本 = GetComponentInChildren<玩家进入坐骑检测new>(true);

        if (坐骑检测脚本 != null)
            坐骑检测脚本.允许扫描 = true;

        if (绑定的目标坐骑 != null)
        {
            绑定的目标坐骑.准备弹出 = false;
            绑定的目标坐骑 = null;
        }
    }

    void Start()
    {
        同步状态变量();
        更新输入变量();
        刷新当前模式与目标集合();
        当前上半身状态集合 = 期望上半身状态集合;
        当前下半身状态集合 = 期望下半身状态集合;

        应用当前动画器配置(true);
        刷新上下半身渲染顺序();
        上一次已应用形态 = 当前形态;
        上一次已应用人类子模式 = 当前人类子模式;
        待刷新状态方案 = false;
        待强制刷新动画器 = false;

        切换下半身(取当前方案下半身基础状态(), "Start初始化");
        切换上半身(取当前方案上半身基础状态(), "Start初始化");
        同步派生状态();
    }

    void Update()
    {
        if (Time.timeScale == 0f)
            return;
        恢复上半身节点位置();
        冷却计时();
        同步状态变量();
        更新输入变量();
        刷新当前模式与目标集合();
        处理待同步的状态方案();

        if (检测坐骑弹出中断())
        {
            同步派生状态();
            return;
        }

        if (玩家被击)
        {
            if (!玩家被击待下一帧清理)
            {
                玩家被击待下一帧清理 = true;
                玩家被击记录帧 = Time.frameCount;
            }
        }

        if (尝试切换技能状态_技能用())
        {
            同步派生状态();
            return;
        }

        if (当前下半身状态 != null)
        {
            当前下半身状态.逻辑更新();
            var 新下半身 = 当前下半身状态.检查过渡条件();
            if (新下半身 != null)
                切换下半身(新下半身, "下半身状态返回过渡");
        }

        同步派生状态();
        处理上半身透明切换();

        if (当前上半身状态 != null)
        {
            当前上半身状态.逻辑更新();
            var 新上半身 = 当前上半身状态.检查过渡条件();
            if (新上半身 != null)
                切换上半身(新上半身, "上半身状态返回过渡");
        }

        if (当前下半身状态 != null && 当前下半身状态.是前进状态)
            前进计时 += Time.deltaTime;
        else
            前进计时 = 0f;

        同步派生状态();
        按键测试();
    }

    void LateUpdate()
    {
        跳跃键_触发 = false;
        if (玩家被击待下一帧清理 && Time.frameCount > 玩家被击记录帧)
        {
            玩家被击 = false;
            被击属性 = 0;
            玩家被击待下一帧清理 = false;
            玩家被击记录帧 = -1;
        }
        调整上半身节点位置();
        同步飞行员背包最终状态_帧末();
    }

    void 同步飞行员背包最终状态_帧末()
    {
        if (物理脚本 == null)
            return;

        bool 是飞行员形态 = 当前形态 == 玩家变身形态.飞行员;
        bool 处于飞行员弹出坐骑状态 = 当前下半身状态 is 飞行员弹出坐骑通用状态;
        bool 处于飞行员进入坐骑状态 = 当前下半身状态 is 飞行员进入白银坦克通用状态;

        // 【新增】技能期间强制隐藏背包
        bool 处于玩家技能状态 =
            当前上半身状态 is 玩家上半身技能状态 ||
            当前下半身状态 is 玩家下半身技能状态;

        bool 应显示背包 = 是飞行员形态
                         && !处于飞行员弹出坐骑状态
                         && !处于飞行员进入坐骑状态
                         && !处于玩家技能状态;

        bool 前进喷火 = !反向中 && 水平按键 != 0 && 应显示背包;

        物理脚本.应用飞行员背包最终状态(应显示背包, 前进喷火);
    }

    void 冷却计时()
    {
        开枪间隔 = Mathf.Max(0f, 开枪间隔 - Time.deltaTime);
        扔雷间隔 = Mathf.Max(0f, 扔雷间隔 - Time.deltaTime);
        出刀间隔 = Mathf.Max(0f, 出刀间隔 - Time.deltaTime);
    }

    void 按键测试()
    {
        if (Input.GetKeyDown(KeyCode.Q))
        {
            当前形态 = 玩家变身形态.正常人类;
        }
        else if (Input.GetKeyDown(KeyCode.E))
        {
            当前形态 = 玩家变身形态.胖子;
        }
        else if (Input.GetKeyDown(KeyCode.Y))
        {
            当前形态 = 玩家变身形态.木乃伊;
        }
        else if (Input.GetKeyDown(KeyCode.T))
        {
            当前形态 = 玩家变身形态.僵尸;
        }
        else if (Input.GetKeyDown(KeyCode.G))
        {
            当前形态 = 玩家变身形态.飞行员;
        }

        if (Input.GetKeyDown(KeyCode.Alpha8))
        {
            当前角色ID++;
            if (当前角色ID>= 7)
                当前角色ID = 0;
        }
    }


    void 同步状态变量()
    {
        if (物理脚本 != null)
        {
            是否在地面 = 物理脚本.是否在地面;
            跳跃中 = 物理脚本.跳跃中;
            当前垂直速度 = 物理脚本.垂直速度;
        }

        if (数据脚本 != null)
        {
            状态ID = 数据脚本.当前玩家状态;
            当前子弹ID = 数据脚本.当前子弹类型;
            生命值 = 数据脚本.生命值;
            玩家P = 数据脚本.玩家P;
        }

        持枪状态 = 当前子弹ID > 0;
    }

    void 更新输入变量()
    {
        if (全局输入 == null) 全局输入 = 全局输入管理器.实例;
        if (全局输入 == null)
        {
            水平按键 = 0;
            垂直按键 = 0;
            开枪键_触发 = false;
            扔雷键_触发 = false;
            跳跃键_触发 = false;
            自爆键_触发 = false;
            特殊攻击键_触发 = false;
            特殊攻击键2_触发 = false;
            切换武器键_触发 = false;
            反向中 = false;
            return;
        }

        var 输入 = 全局输入.获取玩家输入(玩家P);
        水平按键 = 输入.水平按键;
        垂直按键 = 输入.垂直按键;
        开枪键_触发 = 输入.开枪键_触发;
        扔雷键_触发 = 输入.扔雷键_触发;
        跳跃键_触发 = 输入.跳跃键_触发;

        //if (跳跃键_触发)
        //{
        //    Debug.Log(
        //        $"[状态脚本收到跳跃输入] 玩家P={玩家P} 名字={gameObject.name} " +
        //        $"水平按键={水平按键} 垂直按键={垂直按键} " +
        //        $"是否在地面={是否在地面} 跳跃中={跳跃中} " +
        //        $"被击中={被击中} 弹出坐骑中={弹出坐骑中} " +
        //        $"当前形态={当前形态} 当前下半身状态={(当前下半身状态 == null ? "null" : 当前下半身状态.GetType().Name)}"
        //    );
        //}

        自爆键_触发 = 输入.自爆键_触发;
        特殊攻击键_触发 = 输入.技能1_触发;
        特殊攻击键2_触发 = 输入.技能2_触发;
        切换武器键_触发 = 输入.切换武器键_触发;
        反向中 = 水平按键 != 0 && 物理脚本 != null && 水平按键 != 物理脚本.角色朝向;
    }

    public 玩家技能槽位 取当前触发技能槽位_技能用()
    {
        if (特殊攻击键_触发)
            return 玩家技能槽位.技能1;

        if (特殊攻击键2_触发)
            return 玩家技能槽位.技能2;

        // 以后要做 “下 + 技能1 = 技能3”，只改这里
        return 玩家技能槽位.无;
    }

    public bool 允许进入当前技能_技能用(玩家技能映射 技能映射, bool 忽略上半身隐藏限制 = false)
    {
        if (技能映射 == null)
            return false;

        // 总开关
        if (!技能系统启用)
            return false;

        // 生命值没了，不进技能
        if (生命值 <= 0f)
            return false;

        // 被击帧，不进技能
        if (玩家被击)
            return false;

        // 当前状态自己声明了“阻止状态切换”，不进技能
        if (当前状态阻止方案切换())
            return false;

        // 如果当前下半身要求隐藏上半身，就不要进入上半身技能
        // 但某些“下半身联动上半身技能”的特殊状态，可以选择忽略这条限制
        if (技能映射.作用部位 == 玩家技能作用部位.上半身)
        {
            if (!忽略上半身隐藏限制)
            {
                if (当前下半身状态 != null && 当前下半身状态.需要隐藏上半身)
                    return false;
            }
        }

        // 技能状态中，不允许再进入任何技能
        if (当前上半身状态 is 玩家上半身技能状态)
            return false;

        if (当前下半身状态 is 玩家下半身技能状态)
            return false;

        // 这里就是你以后专门写“切技能前检测”的地方
        // 例如：
        // 1. 滑铲只能在地面
        // 2. 某个技能不能打断某些状态
        // 3. 某个技能只能蹲下时放
        //
        // 你以后就继续在这里往下加 if 判断，不要写到技能状态类里

        return true;
    }

    public bool 尝试切换技能状态_技能用()
    {
        var 槽位 = 取当前触发技能槽位_技能用();
        if (槽位 == 玩家技能槽位.无)
            return false;

        if (玩家技能状态 == null)
            return false;

        var 技能映射 = 玩家技能状态.解析技能映射(this, 槽位);
        if (技能映射 == null)
            return false;

        if (!允许进入当前技能_技能用(技能映射))
            return false;

        var 技能状态 = 玩家技能状态.取技能状态(技能映射);
        if (技能状态 == null)
            return false;

        当前激活技能槽位 = 槽位;
        当前激活技能映射 = 技能映射;

        if (技能映射.作用部位 == 玩家技能作用部位.上半身)
        {
            切换上半身(技能状态, "技能输入切换");
            return true;
        }

        切换下半身(技能状态, "技能输入切换");
        同步派生状态();
        处理上半身透明切换();
        return true;
    }

    public string 取当前激活技能状态块名()
    {
        return 玩家技能状态集合.取技能状态块名(当前激活技能槽位);
    }

    public void 请求结算胜利动作()
    {
        if (已切换过结算胜利动作)
            return;

        待切换结算胜利动作 = true;
    }

    public void 重置结算胜利动作标记()
    {
        待切换结算胜利动作 = false;
        已切换过结算胜利动作 = false;
    }

    public 玩家状态基类new 取当前可切换的结算胜利动作状态()
    {
        if (!待切换结算胜利动作 || 已切换过结算胜利动作)
            return null;

        if (!gameObject.activeInHierarchy)
            return null;

        if (生命值 <= 0f || 已死亡)
            return null;

        // 只允许“正常人类默认/持枪”进入胜利动作
        if (当前形态 != 玩家变身形态.正常人类)
            return null;

        // 上/下半身任意一边声明“阻止状态切换”，都先不切
        if (当前状态阻止方案切换())
            return null;

        玩家状态基类new 目标状态 =
            当前人类子模式 == 人类子模式.持枪
            ? 持枪下半身状态.胜利动作
            : 默认下半身状态.胜利动作;

        if (目标状态 == null)
            return null;

        // 保险：清掉技能占用
        当前激活技能槽位 = 玩家技能槽位.无;
        当前激活技能映射 = null;

        待切换结算胜利动作 = false;
        已切换过结算胜利动作 = true;
        return 目标状态;
    }

    public bool 当前形态支持人类子模式()
    {
        return 当前形态 == 玩家变身形态.正常人类 || 当前形态 == 玩家变身形态.飞行员;
    }

    void 刷新人类子模式()
    {
        if (!当前形态支持人类子模式())
        {
            当前人类子模式 = 人类子模式.默认;
            return;
        }

        当前人类子模式 = 持枪状态 ? 人类子模式.持枪 : 人类子模式.默认;
    }

    void 刷新当前模式与目标集合()
    {
        刷新人类子模式();

        期望上半身状态集合 = 解析目标上半身状态集合();
        期望下半身状态集合 = 解析目标下半身状态集合();

        if (当前上半身状态集合 == null)
            当前上半身状态集合 = 期望上半身状态集合;

        if (当前下半身状态集合 == null)
            当前下半身状态集合 = 期望下半身状态集合;

        bool 动画器身份变化 = 上一帧角色ID != 当前角色ID || 上一帧形态 != 当前形态 || 上一帧人类子模式 != 当前人类子模式;
        bool 状态方案变化 = 当前上半身状态集合 != 期望上半身状态集合
                         || 当前下半身状态集合 != 期望下半身状态集合
                         || 上一次已应用人类子模式 != 当前人类子模式;

        if (动画器身份变化)
            待强制刷新动画器 = true;

        if (状态方案变化 || 动画器身份变化)
            待刷新状态方案 = true;
    }

    I上半身状态集合 解析目标上半身状态集合()
    {
        switch (当前形态)
        {
            case 玩家变身形态.正常人类:
                return 当前人类子模式 == 人类子模式.持枪 ? 持枪上半身状态 : 默认上半身状态;

            //以下还没制作,等制作时再取消注释;

            case 玩家变身形态.胖子:
                return 胖子上半身状态;

            case 玩家变身形态.木乃伊:
                return 木乃伊上半身状态;

            case 玩家变身形态.僵尸:
                return 僵尸上半身状态;

            case 玩家变身形态.飞行员:
                return 飞行员上半身状态;
        }

        return 默认上半身状态;
    }

    I下半身状态集合 解析目标下半身状态集合()
    {
        switch (当前形态)
        {
            case 玩家变身形态.正常人类:
                return 当前人类子模式 == 人类子模式.持枪
                    ? 持枪下半身状态
                    : 默认下半身状态;

            //以下还没制作,等制作时再取消注释;

            case 玩家变身形态.胖子:
                return 胖子下半身状态;

            case 玩家变身形态.木乃伊:
                return 木乃伊下半身状态;

            case 玩家变身形态.僵尸:
                return 僵尸下半身状态;

            case 玩家变身形态.飞行员:
                return 飞行员下半身状态;
        }

        return 默认下半身状态;
    }


    bool 当前状态阻止方案切换()
    {
        if (当前下半身状态 != null && 当前下半身状态.阻止状态切换)
            return true;

        if (当前上半身状态 != null && 当前上半身状态.阻止状态切换)
            return true;

        return false;
    }

    void 形态切换后补无敌时间(玩家变身形态 旧形态, 玩家变身形态 新形态)
    {
        // 只看“形态”变化，不看 默认/持枪 子模式变化。
        // 所以正常人类 默认<->持枪、飞行员 默认<->持枪 都不会进这里。
        if (旧形态 == 新形态)
            return;

        if (数据脚本 == null)
            return;

        float 目标无敌时间 = 形态切换无敌时间 > 0f ? 形态切换无敌时间 : 3f;

        // 用 Max，避免玩家本来还有更长无敌时间时被缩短。
        数据脚本.无敌时间 = Mathf.Max(数据脚本.无敌时间, 目标无敌时间);
    }

    void 处理待同步的状态方案()
    {
        if (!待刷新状态方案 && !待强制刷新动画器)
            return;

        if (!gameObject.activeInHierarchy)
            return;

        bool 正在切换到或离开飞行员 =
    上一次已应用形态 != 当前形态 &&
    (上一次已应用形态 == 玩家变身形态.飞行员 || 当前形态 == 玩家变身形态.飞行员);

        bool 正在被强制打断的坐骑中间态 =
    当前下半身状态 != null &&
    当前下半身状态.阻止状态切换 &&
    (
        绑定的目标坐骑 != null ||
        (坐骑检测脚本 != null && !坐骑检测脚本.允许扫描)
    );

        if (正在切换到或离开飞行员 && 正在被强制打断的坐骑中间态)
        {
            强制结束坐骑中间态_形态切换用();
        }

        // 正常情况下，仍然尊重“阻止状态切换”
        // 但只要这次是“切到飞行员 / 从飞行员切走”，就允许强制刷新状态方案，
        // 避免旧的翻滚/特殊状态把新形态卡死。
        if (!正在切换到或离开飞行员 && 当前状态阻止方案切换())
            return;

        bool 需要切基础状态 = 待刷新状态方案 || 当前上半身状态 == null || 当前下半身状态 == null;
        玩家变身形态 旧已应用形态 = 上一次已应用形态;

        bool 刚切换到木乃伊 = 旧已应用形态 != 当前形态 && 当前形态 == 玩家变身形态.木乃伊;

        string 旧下半身标签 = 当前下半身状态 == null ? string.Empty : 当前下半身状态.动作同步标签;
        float 旧下半身进度 = 取动作同步进度(下半身动画器, 当前下半身状态);

        string 旧上半身标签 = 当前上半身状态 == null ? string.Empty : 当前上半身状态.动作同步标签;
        float 旧上半身进度 = 取动作同步进度(上半身动画器, 当前上半身状态);

        当前上半身状态集合 = 期望上半身状态集合;
        当前下半身状态集合 = 期望下半身状态集合;

        if (待强制刷新动画器)
            应用当前动画器配置(true);

        if (需要切基础状态)
        {
            var 新下半身 = 取形态切换专用下半身状态(旧已应用形态);
            var 新上半身 = 取当前方案上半身基础状态();

            // 关键修复：如果新下半身本来就要求隐藏上半身，
            // 那么方案切换时直接把上半身目标定为“新方案的透明状态”，
            // 不要先切到基础待机，再在同一帧末尾补切透明。
            if (新下半身 != null && 新下半身.需要隐藏上半身)
            {
                var 目标透明状态 = 取当前方案透明状态();
                if (目标透明状态 != null)
                    新上半身 = 目标透明状态;
            }

            bool 下半身可同步 = 新下半身 != null && !string.IsNullOrEmpty(旧下半身标签) && 旧下半身标签 == 新下半身.动作同步标签;
            bool 上半身可同步 = 新上半身 != null && !string.IsNullOrEmpty(旧上半身标签) && 旧上半身标签 == 新上半身.动作同步标签;

            if (!上半身可同步 && 新上半身 != null && !string.IsNullOrEmpty(旧下半身标签) && 旧下半身标签 == 新上半身.动作同步标签)
            {
                上半身可同步 = true;
                旧上半身进度 = 旧下半身进度;
            }

            if (下半身可同步)
                切换下半身_指定进度(新下半身, 旧下半身进度, "状态方案同步");
            else
                切换下半身(新下半身, "状态方案同步");

            if (上半身可同步)
                切换上半身_指定进度(新上半身, 旧上半身进度, "状态方案同步");
            else
                切换上半身(新上半身, "状态方案同步");
        }
        if (刚切换到木乃伊)
            生成木乃伊变身烟雾();

        // 关键：只有“形态”真正切换并完成状态方案同步后，才补无敌。
        // 正常人类 默认/持枪互切、飞行员 默认/持枪互切，只会改变 当前人类子模式，不会改变 当前形态，所以不会刷无敌。
        形态切换后补无敌时间(旧已应用形态, 当前形态);

        上一次已应用形态 = 当前形态;
        上一次已应用人类子模式 = 当前人类子模式;
        待刷新状态方案 = false;
        待强制刷新动画器 = false;
        同步派生状态();
    }

    void 应用当前动画器配置(bool 强制 = false)
    {
        if (!强制 && 上一帧角色ID == 当前角色ID && 上一帧形态 == 当前形态 && 上一帧人类子模式 == 当前人类子模式)
            return;

        var 目标配置 = 取匹配动画器配置();
        if (目标配置 != null)
        {
            if (上半身动画器 != null && 目标配置.上半身动画器文件 != null)
                上半身动画器.runtimeAnimatorController = 目标配置.上半身动画器文件;

            if (下半身动画器 != null && 目标配置.下半身动画器文件 != null)
                下半身动画器.runtimeAnimatorController = 目标配置.下半身动画器文件;

            if (上半身动画器 != null)
            {
                上半身动画器.Rebind();
                上半身动画器.Update(0f);
            }

            if (下半身动画器 != null)
            {
                下半身动画器.Rebind();
                下半身动画器.Update(0f);
            }
        }

        刷新身体颠簸脚本开关();
        刷新上下半身渲染顺序();
        上一帧角色ID = 当前角色ID;
        上一帧形态 = 当前形态;
        上一帧人类子模式 = 当前人类子模式;
    }

    角色形态动画器配置new 取匹配动画器配置()
    {
        foreach (var 配置 in 动画器配置列表)
        {
            if (配置 == null) continue;
            if (配置.角色ID != 当前角色ID) continue;
            if (配置.形态 != 当前形态) continue;

            if (当前形态支持人类子模式() && 配置.子模式 != 当前人类子模式)
                continue;

            return 配置;
        }

        return null;
    }

    void 同步派生状态()
    {
        蹲下中 = 当前下半身状态 != null && 当前下半身状态.是蹲下状态;
        上半身隐藏 = 当前下半身状态 != null && 当前下半身状态.需要隐藏上半身;
        攻击中 = 当前上半身状态 != null && 当前上半身状态.是攻击状态;
        锁定朝向中 = 当前上半身状态 != null && 当前上半身状态.锁定朝向;
        落地动作中 = 当前下半身状态 != null && 当前下半身状态.是落地动作状态;

        停顿中 =
            (当前上半身状态 != null && 当前上半身状态.是停顿状态)
            || (当前下半身状态 != null && 当前下半身状态.是停顿状态);
    }

    void 处理上半身透明切换()
    {
        if (!gameObject.activeInHierarchy)
            return;

        if (上半身动画器 == null || !上半身动画器.isActiveAndEnabled || !上半身动画器.gameObject.activeInHierarchy)
            return;

        if (!上半身隐藏)
            return;

        var 目标透明状态 = 取当前方案透明状态();
        if (目标透明状态 == null)
            return;

        if (当前上半身状态 != 目标透明状态)
        {
            切换上半身(目标透明状态, "下半身要求隐藏上半身");
            上半身动画器.Update(0f);
        }
    }

    玩家状态基类new 取当前方案透明状态()
    {
        if (当前上半身状态集合 != null)
            return 当前上半身状态集合.取透明状态(this);

        return 默认上半身状态.透明状态;
    }

    玩家状态基类new 取当前方案上半身基础状态()
    {
        if (当前上半身状态集合 != null)
            return 当前上半身状态集合.取基础状态(this);

        return 默认上半身状态.取基础状态(this);
    }

    玩家状态基类new 取当前方案下半身基础状态()
    {
        if (当前下半身状态集合 != null)
            return 当前下半身状态集合.取基础状态(this);

        return 默认下半身状态.取基础状态(this);
    }

    public 玩家状态基类new 取当前方案透明状态_技能用()
    {
        return 取当前方案透明状态();
    }

    public 玩家状态基类new 取当前方案上半身基础状态_技能用()
    {
        return 取当前方案上半身基础状态();
    }

    public 玩家状态基类new 取当前方案下半身基础状态_技能用()
    {
        return 取当前方案下半身基础状态();
    }

    public 玩家状态基类new 取当前方案下半身被击状态_技能用()
    {
        if (!玩家被击)
            return null;

        if (生命值 <= 0f)
            return null;

        var 被击出口 = 当前下半身状态集合 as I技能下半身被击出口;
        if (被击出口 == null)
            return null;

        return 被击出口.取技能中被击状态(this);
    }

    玩家状态基类new 取形态切换专用下半身状态(玩家变身形态 旧形态)
    {
        if (旧形态 != 当前形态)
        {
            // 其他形态 -> 胖子：播变胖
            if (当前形态 == 玩家变身形态.胖子)
                return 胖子下半身状态.变胖;

            // 胖子 -> 正常人类：播变瘦
            if (旧形态 == 玩家变身形态.胖子 && 当前形态 == 玩家变身形态.正常人类)
            {
                if (当前人类子模式 == 人类子模式.持枪)
                    return 持枪下半身状态.变瘦;

                return 默认下半身状态.变瘦;
            }

            // 其他任何形态 -> 僵尸
            if (当前形态 == 玩家变身形态.僵尸)
            {
                if (是否在地面)
                    return 僵尸下半身状态.雷劈前_地面被僵尸属性击中;

                return 僵尸下半身状态.雷劈前_空中被僵尸属性击中;
            }
        }

        return 取当前方案下半身基础状态();
    }

    public void 切换上半身(玩家状态基类new 新状态, string 原因 = "")
    {
        if (新状态 == null)
            return;

        var 旧状态 = 当前上半身状态;

        if (新状态.切换时更新状态集合引用 && 新状态.所属上半身状态集合 != null)
            当前上半身状态集合 = 新状态.所属上半身状态集合;

        if (当前上半身状态 == 新状态)
        {
            当前上半身状态.退出();
            当前上半身状态.进入();
            if (输出上半身状态切换日志)
                打印状态切换日志("上半身", 旧状态, 新状态);
            return;
        }

        当前上半身状态?.退出();
        当前上半身状态 = 新状态;
        当前上半身状态?.进入();

        if (输出上半身状态切换日志)
            打印状态切换日志("上半身", 旧状态, 新状态);
    }

    public void 切换下半身(玩家状态基类new 新状态, string 原因 = "")
    {
        if (新状态 == null)
            return;

        var 旧状态 = 当前下半身状态;

        if (新状态.切换时更新状态集合引用 && 新状态.所属下半身状态集合 != null)
            当前下半身状态集合 = 新状态.所属下半身状态集合;

        if (当前下半身状态 == 新状态)
        {
            当前下半身状态.退出();
            当前下半身状态.进入();
            if (输出下半身状态切换日志)
                打印状态切换日志("下半身", 旧状态, 新状态);
            return;
        }

        当前下半身状态?.退出();
        当前下半身状态 = 新状态;
        当前下半身状态?.进入();

        if (输出下半身状态切换日志)
            打印状态切换日志("下半身", 旧状态, 新状态);
    }

    void 打印状态切换日志(string 半身, 玩家状态基类new 旧状态, 玩家状态基类new 新状态)
    {
        string 旧名字 = 旧状态 == null ? "无" : 旧状态.GetType().Name;
        string 新名字 = 新状态 == null ? "无" : 新状态.GetType().Name;
        string 颜色 = 半身 == "上半身" ? "#FFFF66" : "#66FF66";
        Debug.Log($"<color={颜色}>{半身}: {旧名字} -> {新名字}</color>", this);
    }

    public void 播放动画(Animator 动画器, string 状态名, float 起始进度 = 0f)
    {
        if (动画器 == null)
            return;

        if (!动画器.isActiveAndEnabled || !动画器.gameObject.activeInHierarchy)
            return;

        if (动画器 == 上半身动画器 && 上半身动画事件接收器 != null)
        {
            上半身动画事件接收器.重置();
            上半身动画事件接收器.准备监听(状态名);
        }
        else if (动画器 == 下半身动画器 && 下半身动画事件接收器 != null)
        {
            下半身动画事件接收器.重置();
            下半身动画事件接收器.准备监听(状态名);
            下半身动画器.SetFloat("动画速度", 1f);
        }

        int stateHash = Animator.StringToHash(状态名);
        if (!动画器.HasState(0, stateHash))
        {
            Debug.LogError($"动画器里找不到状态块：{状态名}，当前控制器：{动画器.runtimeAnimatorController?.name}", 动画器);
            return;
        }

        动画器.Play(状态名, 0, 起始进度);
        动画器.Update(0f);
    }

    public float 取下半身前进进度()
    {
        if (当前下半身状态 != 默认下半身状态.前进)
            return 0f;

        if (下半身动画器 == null)
            return 0f;

        AnimatorStateInfo info = 下半身动画器.GetCurrentAnimatorStateInfo(0);
        if (!info.IsName("下半身前进"))
            return 0f;

        return info.normalizedTime % 1f;
    }

    public float 取当前下半身动画进度()
    {
        if (下半身动画器 == null)
            return 0f;

        AnimatorStateInfo info = 下半身动画器.GetCurrentAnimatorStateInfo(0);
        return info.normalizedTime % 1f;
    }

    void 刷新身体颠簸脚本开关()
    {
        if (身体颠簸控制器引用 == null)
            return;

        bool 应该启用 = 当前形态 == 玩家变身形态.正常人类;
        if (身体颠簸控制器引用.enabled != 应该启用)
            身体颠簸控制器引用.enabled = 应该启用;
    }

    public void 切换出刀标志()
    {
        出刀标志 = (出刀标志 == 0) ? 1 : 0;
    }

    public void 重置扔雷间隔()
    {
        if (当前形态 == 玩家变身形态.木乃伊)
        {
            扔雷间隔 = 蹲下中 ? 木乃伊蹲下扔雷间隔 : 木乃伊站立扔雷间隔;
            return;
        }

        扔雷间隔 = 扔雷初始间隔;
    }

    public void 执行生成子弹()
    {
        if (生成子弹脚本引用 != null)
        {
            生成子弹脚本引用.动画事件_主武器开火请求();
        }
    }

    public void 执行生成激光(int 激光标志)
    {
        if (生成子弹脚本引用 != null)
        {
            生成子弹脚本引用.动画事件_激光发射请求(激光标志);
        }
    }

    public void 特殊武器发射请求(int 标志)
    {
        if (生成子弹脚本引用 != null)
        {
            生成子弹脚本引用.动画事件_特殊武器发射请求(标志);
        }
    }

    public void 执行生成手雷()
    {
        if (生成子弹脚本引用 != null)
            生成子弹脚本引用.动画事件_扔雷请求();
    }

    public void 近身攻击()
    {
        if (玩家近身检测引用 != null)
            玩家近身检测引用.近身攻击();
    }

    public void 生成枪口特效(int 特效标志)
    {
        //if (生成子弹脚本引用 != null)
        //{
        //    bool 枪口特效反方向 = false;
        //    float 当前朝向 = Mathf.Sign(transform.localScale.x);

        //    if (水平按键 != 0 && (水平按键 * 当前朝向 < 0) && !是否在地面)
        //        枪口特效反方向 = true;

        //    生成子弹脚本引用.生成枪口特效(枪口特效反方向, 特效标志);
        //}
    }


    public void 生成被电烟雾()
    {
        if (闪烁后销毁引用 != null)
            闪烁后销毁引用.生成被电烟雾();
    }

    public void 生成木乃伊变身烟雾()
    {
        if (木乃伊变身烟雾预制体 == null)
            return;

        GameObject 烟雾 = Instantiate(木乃伊变身烟雾预制体, transform);

        if (烟雾 != null)
        {
            Transform 烟雾节点 = 烟雾.transform;
            烟雾节点.localPosition = 木乃伊变身烟雾偏移;
            烟雾节点.localRotation = Quaternion.identity;

            // 1. 获取预制体原本的局部缩放值，这样就不会把缩放写死
            Vector3 原始缩放 = 木乃伊变身烟雾预制体.transform.localScale;

            // 2. 获取当前脚本所在节点X轴的符号（如果是正数返回 1，如果是负数返回 -1）
            float 缩放符号 = Mathf.Sign(transform.localScale.x);

            // 3. 将预制体原本的X缩放 乘以 符号，Y和Z保持不变
            烟雾节点.localScale = new Vector3(原始缩放.x * 缩放符号, 原始缩放.y, 原始缩放.z);
        }
    }

    public 玩家状态基类new 检查进入坐骑()
    {
        if (坐骑检测脚本 == null || !坐骑检测脚本.允许扫描)
            return null;

        if (坐骑检测脚本.侦测到的坐骑 == null)
            return null;

        if (当前垂直速度 >= 0f)
            return null;

        if (当前形态 == 玩家变身形态.木乃伊 || 当前形态 == 玩家变身形态.僵尸)
            return null;

        坐骑入口new 目标坐骑 = 坐骑检测脚本.侦测到的坐骑;
        if (目标坐骑 == null)
            return null;

        if (!目标坐骑.玩家请求进入(this))
            return null;

        坐骑检测脚本.允许扫描 = false;
        绑定的目标坐骑 = 目标坐骑;
        return 当前下半身状态集合?.取进入坐骑状态(this);
    }

    bool 检测坐骑弹出中断()
    {
        if (!弹出坐骑中)
            return false;

        弹出坐骑中 = false;
        立即切换到弹出坐骑状态();
        return true;
    }

    void 在进入特殊状态前强制同步方案()
    {
        同步状态变量();
        更新输入变量();
        刷新当前模式与目标集合();

        当前上半身状态集合 = 期望上半身状态集合;
        当前下半身状态集合 = 期望下半身状态集合;

        应用当前动画器配置(true);
        上一次已应用形态 = 当前形态;
        上一次已应用人类子模式 = 当前人类子模式;
        待刷新状态方案 = false;
        待强制刷新动画器 = false;
        同步派生状态();
    }

    public void 立即切换到弹出坐骑状态()
    {
        if (当前形态 == 玩家变身形态.木乃伊 || 当前形态 == 玩家变身形态.僵尸)
            return;

        在进入特殊状态前强制同步方案();

        玩家状态基类new 目标透明状态 = 取当前方案透明状态();
        var 目标下半身状态 = 当前下半身状态集合?.取弹出坐骑状态(this);
        切换下半身(目标下半身状态, "坐骑弹出_立即切换");
        切换上半身(目标透明状态, "坐骑弹出_立即隐藏上半身");

        if (上半身动画器 != null) 上半身动画器.Update(0f);
        if (下半身动画器 != null) 下半身动画器.Update(0f);
        同步派生状态();
    }

    void 自动初始化所有状态集合()
    {
        var fields = GetType().GetFields(System.Reflection.BindingFlags.Public
                                       | System.Reflection.BindingFlags.NonPublic
                                       | System.Reflection.BindingFlags.Instance);

        foreach (var field in fields)
        {
            if (!typeof(状态集合自动初始化).IsAssignableFrom(field.FieldType))
                continue;

            var 状态集合 = field.GetValue(this) as 状态集合自动初始化;
            if (状态集合 != null)
                状态集合.初始化所有状态(this);
        }
    }

    float 取动作同步进度(Animator 动画器, 玩家状态基类new 当前状态)
    {
        if (当前状态 == null)
            return 0f;

        if (string.IsNullOrEmpty(当前状态.动作同步标签))
            return 0f;

        if (动画器 == null)
            return 0f;

        var info = 动画器.GetCurrentAnimatorStateInfo(0);
        return info.normalizedTime % 1f;
    }

    void 切换下半身_指定进度(玩家状态基类new 新状态, float 起始进度, string 原因 = "")
    {
        if (新状态 == null)
            return;

        var 旧状态 = 当前下半身状态;

        if (当前下半身状态 == 新状态)
        {
            当前下半身状态.退出();
            当前下半身状态.进入();

            if (下半身动画器 != null)
            {
                var info = 下半身动画器.GetCurrentAnimatorStateInfo(0);
                下半身动画器.Play(info.shortNameHash, 0, 起始进度);
                下半身动画器.Update(0f);
            }

            if (输出下半身状态切换日志)
                打印状态切换日志("下半身", 旧状态, 新状态);

            return;
        }

        当前下半身状态?.退出();
        当前下半身状态 = 新状态;
        当前下半身状态?.进入();

        if (下半身动画器 != null)
        {
            var info = 下半身动画器.GetCurrentAnimatorStateInfo(0);
            下半身动画器.Play(info.shortNameHash, 0, 起始进度);
            下半身动画器.Update(0f);
        }

        if (输出下半身状态切换日志)
            打印状态切换日志("下半身", 旧状态, 新状态);
    }

    void 切换上半身_指定进度(玩家状态基类new 新状态, float 起始进度, string 原因 = "")
    {
        if (新状态 == null)
            return;

        var 旧状态 = 当前上半身状态;

        if (当前上半身状态 == 新状态)
        {
            当前上半身状态.退出();
            当前上半身状态.进入();

            if (上半身动画器 != null)
            {
                var info = 上半身动画器.GetCurrentAnimatorStateInfo(0);
                上半身动画器.Play(info.shortNameHash, 0, 起始进度);
                上半身动画器.Update(0f);
            }

            if (输出上半身状态切换日志)
                打印状态切换日志("上半身", 旧状态, 新状态);

            return;
        }

        当前上半身状态?.退出();
        当前上半身状态 = 新状态;
        当前上半身状态?.进入();

        if (上半身动画器 != null)
        {
            var info = 上半身动画器.GetCurrentAnimatorStateInfo(0);
            上半身动画器.Play(info.shortNameHash, 0, 起始进度);
            上半身动画器.Update(0f);
        }

        if (输出上半身状态切换日志)
            打印状态切换日志("上半身", 旧状态, 新状态);
    }

    public void 坐骑受击弹出()
    {
        绑定的目标坐骑 = null;

        if (坐骑检测脚本 != null)
            坐骑检测脚本.允许扫描 = true;

        弹出坐骑中 = false;
        本次转身已翻转 = false;

        在进入特殊状态前强制同步方案();

        if (当前下半身状态集合 != null)
        {
            var 下半身恢复状态 = 当前下半身状态集合.取坐骑受击弹出恢复状态(this);
            if (下半身恢复状态 != null)
                切换下半身(下半身恢复状态, "坐骑受击弹出预处理");
        }

        if (当前上半身状态集合 != null)
        {
            var 上半身恢复状态 = 当前上半身状态集合.取坐骑受击弹出恢复状态(this);
            if (上半身恢复状态 != null)
                切换上半身(上半身恢复状态, "坐骑受击弹出预处理");
        }

        同步派生状态();

        if (上半身动画器 != null && 上半身动画器.isActiveAndEnabled && 上半身动画器.gameObject.activeInHierarchy)
            上半身动画器.Update(0f);

        if (下半身动画器 != null && 下半身动画器.isActiveAndEnabled && 下半身动画器.gameObject.activeInHierarchy)
            下半身动画器.Update(0f);
    }

    public void 强制恢复为坐骑乘坐状态(坐骑入口new 目标坐骑)
    {
        绑定的目标坐骑 = 目标坐骑;

        if (坐骑检测脚本 == null)
            坐骑检测脚本 = GetComponentInChildren<玩家进入坐骑检测new>(true);

        if (坐骑检测脚本 != null)
            坐骑检测脚本.允许扫描 = false;

        弹出坐骑中 = false;
        被击中 = false;
        玩家被击 = false;
        被击属性 = 0;
        本次转身已翻转 = false;

        if (物理脚本 != null)
            物理脚本.enabled = false;

        gameObject.SetActive(false);
    }

    public 持枪武器大类 取武器大类(int 当前子弹类型)
    {
        switch (当前子弹类型)
        {
            case 0:
                return 持枪武器大类.无;

            case 1:
            case 4:
                return 持枪武器大类.机枪;

            case 5:
            case 12:
                return 持枪武器大类.激光枪;

            case 2:
            case 3:
            case 6:
            case 13:
            case 7:
            case 8:
            case 9:
            case 10:
            case 11:
                return 持枪武器大类.G;
        }

        return 持枪武器大类.无;
    }

    public 持枪武器大类 当前武器大类
    {
        get { return 取武器大类(当前子弹ID); }
    }

    public bool 武器支持扫射(int 当前子弹类型)
    {
        var 大类 = 取武器大类(当前子弹类型);
        return 大类 == 持枪武器大类.机枪 || 大类 == 持枪武器大类.激光枪;
    }

    public bool 当前武器支持扫射()
    {
        return 武器支持扫射(当前子弹ID);
    }

    void 恢复上半身节点位置()
    {
        if (上半身节点对象 == null) return;

        Vector3 纯净位置 = 上半身节点对象.localPosition;
        纯净位置.x -= 上一帧施加的偏移量X;
        纯净位置.y -= 上一帧施加的偏移量Y;
        上半身节点对象.localPosition = 纯净位置;

        上一帧施加的偏移量X = 0f;
        上一帧施加的偏移量Y = 0f;
    }

    void 调整上半身节点位置()
    {
        if (下半身动画器 == null || 上半身节点对象 == null) return;

        float 修正X = 0f;
        float 修正Y = 0f;

        // 木乃伊低腰修正
        修正Y = 下半身动画器.GetFloat("腰部高度修正");

        // 僵尸手部锚点（未来僵尸形态会用）
        float 手部锚点X = 下半身动画器.GetFloat("手部锚点X");
        float 手部锚点Y = 下半身动画器.GetFloat("手部锚点Y");

        修正X += 手部锚点X;
        修正Y += 手部锚点Y;

        Vector3 最终位置 = 上半身节点对象.localPosition;
        最终位置.x += 修正X;
        最终位置.y += 修正Y;
        上半身节点对象.localPosition = 最终位置;

        上一帧施加的偏移量X = 修正X;
        上一帧施加的偏移量Y = 修正Y;
    }

    void 刷新上下半身渲染顺序()
    {
        if (上半身精灵渲染器 == null || 下半身精灵渲染器 == null)
            return;

        if (当前形态 == 玩家变身形态.僵尸)
        {
            // 僵尸：下半身挡住上半身
            上半身精灵渲染器.sortingOrder = 2;
            下半身精灵渲染器.sortingOrder = 3;
        }
        else if (当前形态 == 玩家变身形态.飞行员)
        {
            // 飞行员：上半身挡住下半身
            上半身精灵渲染器.sortingOrder = 3;
            下半身精灵渲染器.sortingOrder = 2;
        }
        else
        {
            // 其他形态：上半身挡住下半身
            上半身精灵渲染器.sortingOrder = 3;
            下半身精灵渲染器.sortingOrder = 2;
        }
    }

    void 强制结束坐骑中间态_形态切换用()
    {
        // 只做“恢复检测能力”的兜底，不去伪造正常弹出流程
        if (坐骑检测脚本 != null)
            坐骑检测脚本.允许扫描 = true;

        弹出坐骑中 = false;

        // 绑定引用也一起清掉，避免后续逻辑还以为自己仍处于某个坐骑过渡中
        if (绑定的目标坐骑 != null)
        {
            绑定的目标坐骑.准备弹出 = false;
            绑定的目标坐骑 = null;
        }
    }



}
