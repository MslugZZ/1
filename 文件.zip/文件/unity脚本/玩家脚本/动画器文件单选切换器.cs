using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
#endif

[ExecuteAlways]
[DisallowMultipleComponent]
public class 动画器文件单选切换器 : MonoBehaviour
{
    [System.Serializable]
    public class 动画器文件条目
    {
        [Header("显示在快速勾选列表里的名字")]
        public string 名称;

        [Header("当前是否选中")]
        public bool 是否勾选;

        [Header("要载入 Animator 组件的动画器文件")]
        public RuntimeAnimatorController 动画器文件;
    }

    [Header("要被切换动画器的 Animator 组件")]
    public Animator 动画器组件;

    [Header("动画器文件列表")]
    public List<动画器文件条目> 动画器文件列表 = new List<动画器文件条目>();

    [SerializeField, HideInInspector]
    private int 当前选中索引 = -1;

    private void Reset()
    {
        自动查找动画器组件();
    }

    private void OnValidate()
    {
        if (动画器组件 == null)
            自动查找动画器组件();

        if (动画器文件列表 == null)
            动画器文件列表 = new List<动画器文件条目>();

        // 这里只做“同步当前选中索引”，不在这里强行改勾选
        // 真正的单选互斥，统一走“切换到索引()”
        同步当前选中索引();
    }

    public void 自动查找动画器组件()
    {
        if (动画器组件 == null)
            动画器组件 = GetComponent<Animator>();
    }

    public void 切换到索引(int 索引)
    {
        if (Application.isPlaying)
            return;

        if (动画器文件列表 == null)
            return;

        if (索引 < 0 || 索引 >= 动画器文件列表.Count)
            return;

        if (动画器文件列表[索引] == null)
            return;

        for (int i = 0; i < 动画器文件列表.Count; i++)
        {
            if (动画器文件列表[i] != null)
                动画器文件列表[i].是否勾选 = (i == 索引);
        }

        当前选中索引 = 索引;

        自动查找动画器组件();
        if (动画器组件 != null)
            动画器组件.runtimeAnimatorController = 动画器文件列表[索引].动画器文件;

        标记已修改();
    }

    public void 取消全部勾选()
    {
        if (Application.isPlaying)
            return;

        if (动画器文件列表 == null)
            return;

        for (int i = 0; i < 动画器文件列表.Count; i++)
        {
            if (动画器文件列表[i] != null)
                动画器文件列表[i].是否勾选 = false;
        }

        当前选中索引 = -1;
        标记已修改();
    }

    public void 根据当前动画器同步勾选()
    {
        if (Application.isPlaying)
            return;

        自动查找动画器组件();
        if (动画器组件 == null)
            return;

        RuntimeAnimatorController 当前动画器 = 动画器组件.runtimeAnimatorController;

        int 匹配索引 = -1;

        for (int i = 0; i < 动画器文件列表.Count; i++)
        {
            if (动画器文件列表[i] != null &&
                动画器文件列表[i].动画器文件 == 当前动画器)
            {
                匹配索引 = i;
                break;
            }
        }

        for (int i = 0; i < 动画器文件列表.Count; i++)
        {
            if (动画器文件列表[i] != null)
                动画器文件列表[i].是否勾选 = (i == 匹配索引);
        }

        当前选中索引 = 匹配索引;
        标记已修改();
    }

    public void 新增空条目()
    {
        if (Application.isPlaying)
            return;
        if (动画器文件列表 == null)
            动画器文件列表 = new List<动画器文件条目>();

        动画器文件列表.Add(new 动画器文件条目());
        标记已修改();
    }

    public void 删除条目(int 索引)
    {
        if (Application.isPlaying)
            return;
        if (动画器文件列表 == null)
            return;

        if (索引 < 0 || 索引 >= 动画器文件列表.Count)
            return;

        bool 删除的是当前选中项 = (当前选中索引 == 索引);

        动画器文件列表.RemoveAt(索引);

        if (删除的是当前选中项)
        {
            当前选中索引 = -1;
        }
        else if (当前选中索引 > 索引)
        {
            当前选中索引--;
        }

        同步当前选中索引();
        标记已修改();
    }

    public void 上移条目(int 索引)
    {
        if (Application.isPlaying)
            return;
        if (动画器文件列表 == null)
            return;

        if (索引 <= 0 || 索引 >= 动画器文件列表.Count)
            return;

        var 临时 = 动画器文件列表[索引 - 1];
        动画器文件列表[索引 - 1] = 动画器文件列表[索引];
        动画器文件列表[索引] = 临时;

        if (当前选中索引 == 索引)
            当前选中索引 = 索引 - 1;
        else if (当前选中索引 == 索引 - 1)
            当前选中索引 = 索引;

        标记已修改();
    }

    public void 下移条目(int 索引)
    {
        if (Application.isPlaying)
            return;
        if (动画器文件列表 == null)
            return;

        if (索引 < 0 || 索引 >= 动画器文件列表.Count - 1)
            return;

        var 临时 = 动画器文件列表[索引 + 1];
        动画器文件列表[索引 + 1] = 动画器文件列表[索引];
        动画器文件列表[索引] = 临时;

        if (当前选中索引 == 索引)
            当前选中索引 = 索引 + 1;
        else if (当前选中索引 == 索引 + 1)
            当前选中索引 = 索引;

        标记已修改();
    }

    public int 获取当前选中索引()
    {
        return 当前选中索引;
    }

    public string 获取条目名称(int 索引)
    {
        if (动画器文件列表 == null || 索引 < 0 || 索引 >= 动画器文件列表.Count || 动画器文件列表[索引] == null)
            return "元素 " + 索引;

        if (!string.IsNullOrEmpty(动画器文件列表[索引].名称))
            return 动画器文件列表[索引].名称;

        return "元素 " + 索引;
    }

    private void 同步当前选中索引()
    {
        if (动画器文件列表 == null)
        {
            当前选中索引 = -1;
            return;
        }

        int 找到的索引 = -1;
        int 勾选数量 = 0;

        for (int i = 0; i < 动画器文件列表.Count; i++)
        {
            if (动画器文件列表[i] != null && 动画器文件列表[i].是否勾选)
            {
                勾选数量++;
                if (找到的索引 < 0)
                    找到的索引 = i;
            }
        }

        if (勾选数量 == 1)
        {
            当前选中索引 = 找到的索引;
        }
        else if (勾选数量 == 0)
        {
            当前选中索引 = -1;
        }
        else
        {
            // 如果有人绕过快速列表，直接把详细列表改成多勾选，
            // 这里只记录，不在这里硬改，避免 Unity 检查器回写打架
            当前选中索引 = 找到的索引;
        }
    }

    private void 标记已修改()
    {
#if UNITY_EDITOR
        if (!Application.isPlaying)
        {
            EditorUtility.SetDirty(this);

            if (动画器组件 != null)
                EditorUtility.SetDirty(动画器组件);
        }
#endif
    }
}