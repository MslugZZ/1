using System.Collections.Generic;
using UnityEngine;

public static class 地面规则缓存
{
    private static readonly Dictionary<int, 地面规则> 规则表 = new Dictionary<int, 地面规则>(512);

    public static void 注册(Collider2D 碰撞器, 地面规则 规则)
    {
        if (碰撞器 == null || 规则 == null)
            return;

        规则表[碰撞器.GetInstanceID()] = 规则;
    }

    public static void 注销(Collider2D 碰撞器, 地面规则 规则)
    {
        if (碰撞器 == null)
            return;

        int id = 碰撞器.GetInstanceID();
        if (!规则表.TryGetValue(id, out 地面规则 当前))
            return;

        if (规则 == null || 当前 == 规则)
            规则表.Remove(id);
    }

    public static bool 尝试获取(Collider2D 碰撞器, out 地面规则 规则)
    {
        规则 = null;
        if (碰撞器 == null)
            return false;

        int id = 碰撞器.GetInstanceID();
        if (!规则表.TryGetValue(id, out 规则))
            return false;

        if (规则 == null || !规则.isActiveAndEnabled || !规则.gameObject.activeInHierarchy)
        {
            规则表.Remove(id);
            规则 = null;
            return false;
        }

        return true;
    }

    public static bool 命中符合检测规则(RaycastHit2D 命中, 地面检测规则文件 检测规则)
    {
        return 命中.collider != null && 碰撞器符合检测规则(命中.collider, 检测规则);
    }

    public static bool 碰撞器符合检测规则(Collider2D 碰撞器, 地面检测规则文件 检测规则)
    {
        if (!尝试获取(碰撞器, out 地面规则 规则))
            return false;

        if (检测规则 != null)
            return 检测规则.是否允许(规则);

        return 规则.允许我方单位站立;
    }

    public static bool 命中可作为脚下地面(RaycastHit2D 命中, 地面检测规则文件 检测规则)
    {
        if (命中.collider == null)
            return false;

        if (!尝试获取(命中.collider, out 地面规则 规则))
            return false;

        if (检测规则 != null)
            return 检测规则.是否允许脚下地面(规则);

        return 规则.允许我方单位站立;
    }

    public static bool 碰撞器阻挡单位向上穿过(Collider2D 碰撞器, 地面检测规则文件 检测规则)
    {
        if (!尝试获取(碰撞器, out 地面规则 规则))
            return false;

        if (检测规则 != null)
            return 检测规则.是否允许头顶阻挡(规则);

        return 规则.阻挡单位向上穿过;
    }

    public static bool 碰撞器阻挡子弹出生安全检测(Collider2D 碰撞器)
    {
        if (!尝试获取(碰撞器, out 地面规则 规则))
            return false;

        return 规则.阻挡子弹出生安全检测;
    }

    public static bool 碰撞器阻挡子弹飞行(Collider2D 碰撞器)
    {
        if (!尝试获取(碰撞器, out 地面规则 规则))
            return false;

        return 规则.阻挡子弹飞行;
    }


    public static bool 碰撞器是水面(Collider2D 碰撞器, out 地面规则 规则)
    {
        if (!尝试获取(碰撞器, out 规则))
            return false;

        return 规则.是水面;
    }

    public static bool 碰撞器允许生成子弹命中水花(Collider2D 碰撞器, out 地面规则 规则)
    {
        if (!碰撞器是水面(碰撞器, out 规则))
            return false;

        return 规则.子弹命中水花大小 != 落水水花大小.不生成;
    }

    public static bool 尝试获取子弹命中水花大小(Collider2D 碰撞器, out 落水水花大小 水花大小, out 地面规则 规则)
    {
        水花大小 = 落水水花大小.不生成;

        if (!碰撞器允许生成子弹命中水花(碰撞器, out 规则))
            return false;

        水花大小 = 规则.子弹命中水花大小;
        return true;
    }

    public static bool 碰撞器是浅水水波地面(Collider2D 碰撞器, out 地面规则 规则)
    {
        if (!尝试获取(碰撞器, out 规则))
            return false;

        return 规则.是浅水
            && 规则.可作为脚下地面
            && 规则.单位站立水波大小 != 水波特效大小.不生成;
    }

    public static bool 碰撞器是我方浅水水波地面(Collider2D 碰撞器, out 地面规则 规则)
    {
        if (!碰撞器是浅水水波地面(碰撞器, out 规则))
            return false;

        return 规则.允许我方单位站立;
    }

    public static bool 碰撞器是敌方可站浅水水波地面(Collider2D 碰撞器, out 地面规则 规则)
    {
        if (!碰撞器是浅水水波地面(碰撞器, out 规则))
            return false;

        return 规则.允许敌方单位站立;
    }

    public static bool 碰撞器是深水(Collider2D 碰撞器, out 地面规则 规则)
    {
        if (!尝试获取(碰撞器, out 规则))
            return false;

        return 规则.是深水;
    }
}
