public interface I敌人索敌目标提供者
{
    /// <summary>
    /// 提供当前AI正在追踪/攻击/关注的目标。
    /// 例如小螃蟹返回 当前目标。
    /// </summary>
    bool 尝试获取当前索敌目标(out 敌人索敌目标 目标);
}