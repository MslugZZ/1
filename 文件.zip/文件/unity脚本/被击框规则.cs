﻿using UnityEngine;

/// <summary>
/// 移动攻击命中当前被击框时的基础响应。
/// 是否实际使用“穿透/阻挡”结果，由对应的子弹数据决定。
/// </summary>
public enum 子弹命中响应
{
    穿透并受伤 = 0,
    阻挡并受伤 = 1,
    阻挡不受伤 = 2,
    完全忽略 = 3
}

/// <summary>
/// 挂在被击框 Collider2D 所在节点本身。
/// 当前组件只描述目标被击框的属性，不区分攻击来自玩家、坐骑还是敌人。
/// </summary>
[DisallowMultipleComponent]
public class 被击框规则 : MonoBehaviour
{
    [Header("=== 绑定对象 ===")]
    [Tooltip("必须是当前节点上的被击框 Collider2D。添加组件时会自动填写；运行时仅在为空时兜底查找一次。")]
    public Collider2D 绑定碰撞体;

    [Tooltip("必须实现 接收攻击数据接口。可以指向当前节点或父节点上的受击代理/数据脚本。为空时会优先自动查找最近的接收器。")]
    public MonoBehaviour 接收攻击组件;

    [Header("=== 被击框属性 ===")]
    [Tooltip("近身攻击数据要求响应近身检测时，只有勾选的被击框才会进入近身命中流程。与攻击者阵营无关。")]
    public bool 响应近身检测 = false;

    [Tooltip("是否允许敌人索敌系统把当前被击框作为候选目标。")]
    public bool 允许作为索敌目标 = true;

    [Tooltip("被支持该规则的移动攻击命中时，当前被击框的穿透、阻挡和受伤响应。")]
    public 子弹命中响应 子弹响应 = 子弹命中响应.阻挡并受伤;

    [Header("=== 子弹出生规则 ===")]
    [Tooltip("预期子弹出生点位于当前被击框内部时，是否允许保留该出生位置。只影响敌方被击框造成的出生回退，不影响墙壁和地面。")]
    public bool 允许子弹内部生成 = false;

    [Tooltip("用于判断多个被击框是否属于同一个敌方单位。为空时会向父级查找最近的 敌人数据基类；复杂复合敌人可手动指定共同主体。")]
    public 敌人数据基类 所属敌人主体;

    [Header("=== 命中反馈缓存（可选） ===")]
    [Tooltip("当前被击框使用的受击反馈。为空时会从当前节点向父节点自动查找一次并缓存。")]
    public 受击反馈类型 受击反馈脚本;

    [Tooltip("可选：拖入项目中的 被击音效类型覆盖 组件。使用 MonoBehaviour 保存，避免命中时再向父节点查找。")]
    public MonoBehaviour 被击音效类型覆盖脚本;

    [Header("=== 最近一次实际命中信息｜运行时 ===")]
    [Tooltip("最近一次实际命中当前被击框的攻击来源。保存攻击数据中的来源节点，不保存子弹节点。每次实际命中时覆盖。")]
    public GameObject 攻击来源;

    [Tooltip("最近一次实际命中当前被击框的攻击属性。每次实际命中时覆盖。")]
    public int 攻击属性;

    private 接收攻击数据接口 接收攻击接口缓存;
    private bool 已完成运行时初始化;

    public 接收攻击数据接口 接收攻击接口
    {
        get { return 接收攻击接口缓存; }
    }

    public bool 当前可用
    {
        get
        {
            if (!isActiveAndEnabled)
                return false;

            if (绑定碰撞体 == null)
                return false;

            if (!绑定碰撞体.enabled)
                return false;

            if (!绑定碰撞体.gameObject.activeInHierarchy)
                return false;

            return true;
        }
    }

    public bool 当前响应会受伤
    {
        get
        {
            return 子弹响应 == 子弹命中响应.穿透并受伤 ||
                   子弹响应 == 子弹命中响应.阻挡并受伤;
        }
    }

    private void Reset()
    {
        自动补齐编辑器引用();
    }

    private void OnValidate()
    {
        // 引用已经存在时不会重复执行组件查找。
        自动补齐编辑器引用();
    }

    private void Awake()
    {
        初始化运行时缓存();
    }

    private void OnEnable()
    {
        if (!已完成运行时初始化)
        {
            初始化运行时缓存();
        }
        else
        {
            接收攻击接口缓存 = 接收攻击组件 as 接收攻击数据接口;

            if (所属敌人主体 == null)
                所属敌人主体 = GetComponentInParent<敌人数据基类>();
        }

        清空最近攻击信息();

        if (!检查是否允许注册())
            return;

        被击框规则缓存.注册(this);
    }

    private void OnDisable()
    {
        被击框规则缓存.注销(this);
    }

    private void OnDestroy()
    {
        被击框规则缓存.注销(this);
    }

    /// <summary>
    /// 只应在攻击已经确认实际命中后调用。
    /// 索敌、近身预检测和候选扫描阶段不得调用。
    /// </summary>
    public void 记录实际命中信息(攻击数据集 攻击数据)
    {
        攻击来源 = 攻击数据.攻击来源;
        攻击属性 = 攻击数据.攻击属性;
    }

    public void 清空最近攻击信息()
    {
        攻击来源 = null;
        攻击属性 = 0;
    }

    private void 初始化运行时缓存()
    {
        if (绑定碰撞体 == null)
            绑定碰撞体 = GetComponent<Collider2D>();

        if (接收攻击组件 == null)
            接收攻击组件 = 查找最近接收攻击组件();

        if (所属敌人主体 == null)
            所属敌人主体 = GetComponentInParent<敌人数据基类>();

        接收攻击接口缓存 = 接收攻击组件 as 接收攻击数据接口;

        if (受击反馈脚本 == null)
            受击反馈脚本 = 查找最近受击反馈();

        if (被击音效类型覆盖脚本 == null)
            被击音效类型覆盖脚本 = 查找最近被击音效覆盖();

        已完成运行时初始化 = true;
    }

    private void 自动补齐编辑器引用()
    {
        if (绑定碰撞体 == null)
            绑定碰撞体 = GetComponent<Collider2D>();

        if (接收攻击组件 == null)
            接收攻击组件 = 查找最近接收攻击组件();

        if (所属敌人主体 == null)
            所属敌人主体 = GetComponentInParent<敌人数据基类>();

        if (受击反馈脚本 == null)
            受击反馈脚本 = 查找最近受击反馈();

        if (被击音效类型覆盖脚本 == null)
            被击音效类型覆盖脚本 = 查找最近被击音效覆盖();
    }

    private bool 检查是否允许注册()
    {
        if (绑定碰撞体 == null)
        {
            被击框规则日志.报告规则配置错误(
                this,
                "没有绑定 Collider2D。该规则不会注册。"
            );
            return false;
        }

        if (绑定碰撞体.gameObject != gameObject)
        {
            被击框规则日志.报告规则配置错误(
                this,
                "绑定碰撞体不在当前节点。被击框规则必须挂在碰撞体所在节点本身，该规则不会注册。"
            );
            return false;
        }

        if (接收攻击组件 != null && 接收攻击接口缓存 == null)
        {
            被击框规则日志.报告规则配置错误(
                this,
                "接收攻击组件没有实现 接收攻击数据接口，该规则不会注册。"
            );
            return false;
        }

        if (当前响应会受伤 && 接收攻击接口缓存 == null)
        {
            被击框规则日志.报告规则配置错误(
                this,
                "当前子弹响应会受伤，但没有配置有效的接收攻击组件，该规则不会注册。"
            );
            return false;
        }

        return true;
    }

    private MonoBehaviour 查找最近接收攻击组件()
    {
        Transform 当前节点 = transform;

        while (当前节点 != null)
        {
            MonoBehaviour[] 组件列表 = 当前节点.GetComponents<MonoBehaviour>();
            for (int i = 0; i < 组件列表.Length; i++)
            {
                MonoBehaviour 组件 = 组件列表[i];
                if (组件 == null || 组件 == this)
                    continue;

                if (组件 is 接收攻击数据接口)
                    return 组件;
            }

            当前节点 = 当前节点.parent;
        }

        return null;
    }

    private 受击反馈类型 查找最近受击反馈()
    {
        Transform 当前节点 = transform;

        while (当前节点 != null)
        {
            受击反馈类型 反馈 = 当前节点.GetComponent<受击反馈类型>();
            if (反馈 != null)
                return 反馈;

            当前节点 = 当前节点.parent;
        }

        return null;
    }
    private MonoBehaviour 查找最近被击音效覆盖()
    {
        Transform 当前节点 = transform;

        while (当前节点 != null)
        {
            被击音效类型覆盖 覆盖 = 当前节点.GetComponent<被击音效类型覆盖>();
            if (覆盖 != null)
                return 覆盖;

            当前节点 = 当前节点.parent;
        }

        return null;
    }

}
