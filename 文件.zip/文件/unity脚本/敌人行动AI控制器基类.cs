using System.Collections.Generic;
using System.Text;
using UnityEngine;

public struct 敌人行动AI配置调试项
{
    public string 名称;
    public 敌人行动AI配置 配置;

    public 敌人行动AI配置调试项(string 名称, 敌人行动AI配置 配置)
    {
        this.名称 = 名称;
        this.配置 = 配置;
    }
}

/// <summary>
/// 敌人行动AI控制器基类。
/// 这里只放已经确认通用的行动AI/出场辅助功能：
/// 1. 出场目标位置X的运行时缓存与基础判断
/// 2. 自动同步配置名称
/// 3. 按键输出配置
/// 4. 按权重从某套配置里选择下一个行动模式
///
/// 不负责具体敌人的索敌、攻击、动画、状态库、死亡链。
/// </summary>
public abstract class 敌人行动AI控制器基类 : MonoBehaviour
{
    [显示在面板]
    [Header("=== 出场目标位置 ===")]
    [Tooltip("开启后，敌人生成会先移动到：生成位置X + 目标位置X。有些敌人无效")]
    public bool 使用目标位置X = false;

    [显示在面板]
    [Tooltip("相对生成点的X偏移。负数朝左。")]
    public float 目标位置X = 0f;

    [Tooltip("到达目标世界X的水平容差。")]
    public float 目标位置X到达容差 = 0.08f;

    [Header("=== 行动AI配置输出调试 ===")]
    [Tooltip("运行游戏时，按下这个按键会在控制台输出行动AI配置的完整参数。")]
    public KeyCode 输出行动AI配置按键 = KeyCode.Tab;

    [Tooltip("是否启用按键输出行动AI配置。")]
    public bool 启用按键输出行动AI配置 = true;

    /// <summary>
    /// 子类把自己拥有的行动AI配置加入结果列表。
    /// 例如小螃蟹加入：远程型/近战型/混合型三套配置。
    /// </summary>
    protected abstract void 收集行动AI配置(List<敌人行动AI配置调试项> 结果);

    /// <summary>
    /// 子类可以追加当前状态、当前目标、当前类型等运行时信息。
    /// </summary>
    protected virtual void 追加行动AI运行时信息(StringBuilder sb)
    {
    }

    [Header("=== 出场待机 ===")]
    [Min(0f)]
    [Tooltip("生成后先待机多久。无论是否启用目标位置X都生效。计时从出场流程缓存刷新时开始，即使单位在空中/下落中也会继续计时。默认不显示到制作场景属性面板；需要的子类用 [属性面板显示继承字段] 显式开启。")]
    public float 出场后待机时间 = 0f;

    [Min(0f)]
    [Tooltip("只有本次实际启动过目标位置X移动流程后，到达目标位置X才会执行这段待机。默认不显示到制作场景属性面板；需要的子类用 [属性面板显示继承字段] 显式开启。")]
    public float 到达目标位置后待机时间 = 0f;

    [Header("=== 出场目标位置运行时 ===")]
    [HideInInspector] public bool 已到达目标位置X = false;
    [HideInInspector] public float 生成位置X = 0f;
    [HideInInspector] public float 目标世界X = 0f;

    [Header("=== 出场待机运行时 ===")]
    [HideInInspector] public bool 已完成出场后待机 = true;
    [HideInInspector] public bool 已启动过目标位置X移动流程 = false;
    [HideInInspector] public bool 已开始到达目标位置后待机 = false;
    [HideInInspector] public bool 已完成到达目标位置后待机 = true;
    [HideInInspector] public float 出场后待机结束时间 = 0f;
    [HideInInspector] public float 到达目标位置后待机结束时间 = 0f;

    /// <summary>
    /// 子类如果有特殊规则，可以只重写这个钩子。
    /// 例如：移动型步枪兵不走“出场目标位置X”流程。
    /// </summary>
    protected virtual bool 允许执行出场目标位置X移动()
    {
        return true;
    }

    /// <summary>
    /// 运行时由关卡/单位生成器在“保存数据反射覆盖完成，并且最终生成坐标已经确定后”调用。
    /// 目标位置X是“生成位置X + 目标位置X”的偏移目标，不是独立世界坐标。
    /// 以后新增敌兵只要继承本基类，并使用这里的缓存/方法，就不需要再为目标X写一套重复逻辑。
    /// </summary>
    public virtual void 刷新出场目标位置X缓存()
    {
        刷新出场目标位置X基础缓存();
        初始化出场待机运行时();
    }

    protected virtual void 刷新出场目标位置X基础缓存()
    {
        生成位置X = transform.position.x;
        目标世界X = 生成位置X + 目标位置X;

        已到达目标位置X =
            !使用目标位置X ||
            Mathf.Abs(目标世界X - transform.position.x) <= Mathf.Max(0.001f, 目标位置X到达容差);
    }

    public virtual void 初始化出场待机运行时()
    {
        float now = Time.time;

        已完成出场后待机 = 出场后待机时间 <= 0f;
        出场后待机结束时间 = now + Mathf.Max(0f, 出场后待机时间);

        已启动过目标位置X移动流程 = false;
        已开始到达目标位置后待机 = false;
        已完成到达目标位置后待机 = 到达目标位置后待机时间 <= 0f;
        到达目标位置后待机结束时间 = 0f;
    }

    public virtual bool 需要执行出场后待机()
    {
        if (已完成出场后待机)
            return false;

        if (出场后待机时间 <= 0f)
        {
            已完成出场后待机 = true;
            return false;
        }

        if (Time.time >= 出场后待机结束时间)
        {
            已完成出场后待机 = true;
            return false;
        }

        return true;
    }

    public virtual void 标记已启动目标位置X移动流程()
    {
        已启动过目标位置X移动流程 = true;
    }

    public virtual bool 应该执行到达目标位置后待机()
    {
        if (!使用目标位置X)
            return false;

        if (!已到达目标位置X)
            return false;

        if (!已启动过目标位置X移动流程)
            return false;

        if (已完成到达目标位置后待机)
            return false;

        if (到达目标位置后待机时间 <= 0f)
        {
            已完成到达目标位置后待机 = true;
            return false;
        }

        return true;
    }

    public virtual bool 需要执行到达目标位置后待机()
    {
        if (!应该执行到达目标位置后待机())
            return false;

        if (!已开始到达目标位置后待机)
        {
            已开始到达目标位置后待机 = true;
            到达目标位置后待机结束时间 = Time.time + Mathf.Max(0f, 到达目标位置后待机时间);
        }

        if (Time.time >= 到达目标位置后待机结束时间)
        {
            已完成到达目标位置后待机 = true;
            return false;
        }

        return true;
    }

    public virtual float 获取出场后待机剩余时间()
    {
        if (已完成出场后待机)
            return 0f;

        return Mathf.Max(0f, 出场后待机结束时间 - Time.time);
    }

    public virtual float 获取到达目标位置后待机剩余时间()
    {
        if (已完成到达目标位置后待机 || !已开始到达目标位置后待机)
            return 0f;

        return Mathf.Max(0f, 到达目标位置后待机结束时间 - Time.time);
    }

    public virtual bool 需要先移动到目标位置X()
    {
        return 允许执行出场目标位置X移动() && 使用目标位置X && !已到达目标位置X;
    }

    public virtual void 标记到达目标位置X()
    {
        已到达目标位置X = true;
    }

    public virtual bool 已经到达目标位置X()
    {
        return Mathf.Abs(目标世界X - transform.position.x) <= Mathf.Max(0.001f, 目标位置X到达容差);
    }

    public virtual int 获取目标位置X移动方向()
    {
        float dx = 目标世界X - transform.position.x;
        if (Mathf.Abs(dx) <= Mathf.Max(0.001f, 目标位置X到达容差))
            return 0;

        return dx > 0f ? 1 : -1;
    }

#if UNITY_EDITOR
    protected virtual void OnValidate()
    {
        同步全部行动AI配置名称();
    }
#endif

    protected void 检查输出行动AI配置按键()
    {
        if (!启用按键输出行动AI配置)
            return;

        if (输出行动AI配置按键 == KeyCode.None)
            return;

        if (!Input.GetKeyDown(输出行动AI配置按键))
            return;

        输出全部行动AI配置到控制台();
    }

    public void 同步全部行动AI配置名称()
    {
        List<敌人行动AI配置调试项> 配置列表 = new List<敌人行动AI配置调试项>();
        收集行动AI配置(配置列表);

        for (int i = 0; i < 配置列表.Count; i++)
        {
            同步行动AI配置名称(配置列表[i].配置);
        }
    }

    private void 同步行动AI配置名称(敌人行动AI配置 配置)
    {
        if (配置 == null)
            return;

        if (配置.模式配置列表 == null)
            return;

        for (int i = 0; i < 配置.模式配置列表.Count; i++)
        {
            敌人行动模式配置 模式配置 = 配置.模式配置列表[i];
            if (模式配置 == null)
                continue;

            模式配置.名称 = 模式配置.当前模式.ToString();

            if (模式配置.切换模式列表 == null)
                continue;

            for (int j = 0; j < 模式配置.切换模式列表.Count; j++)
            {
                敌人行动切换条目 条目 = 模式配置.切换模式列表[j];
                if (条目 == null)
                    continue;

                条目.名称 = 条目.目标模式.ToString();
            }
        }
    }

    public void 输出全部行动AI配置到控制台()
    {
        StringBuilder sb = new StringBuilder(4096);

        sb.AppendLine("============================================================");
        sb.AppendLine($"【敌人行动AI配置输出】对象：{name}");
        追加行动AI运行时信息(sb);
        sb.AppendLine("============================================================");

        List<敌人行动AI配置调试项> 配置列表 = new List<敌人行动AI配置调试项>();
        收集行动AI配置(配置列表);

        for (int i = 0; i < 配置列表.Count; i++)
        {
            追加行动AI配置文本(sb, 配置列表[i].名称, 配置列表[i].配置);
        }

        sb.AppendLine("============================================================");

        Debug.Log(sb.ToString(), this);
    }

    private void 追加行动AI配置文本(StringBuilder sb, string 配置名称, 敌人行动AI配置 配置)
    {
        sb.AppendLine("");
        sb.AppendLine($"==================== {配置名称} ====================");

        if (配置 == null)
        {
            sb.AppendLine("配置 = 空");
            return;
        }

        sb.AppendLine($"全局兜底模式：{配置.全局兜底模式}");
        sb.AppendLine($"输出调试日志：{配置.输出调试日志}");

        if (配置.模式配置列表 == null)
        {
            sb.AppendLine("模式配置列表 = 空");
            return;
        }

        sb.AppendLine($"模式配置列表数量：{配置.模式配置列表.Count}");

        for (int i = 0; i < 配置.模式配置列表.Count; i++)
        {
            敌人行动模式配置 模式配置 = 配置.模式配置列表[i];

            sb.AppendLine("");
            sb.AppendLine($"---- 模式配置元素 [{i}] ----");

            if (模式配置 == null)
            {
                sb.AppendLine("元素 = 空");
                continue;
            }

            sb.AppendLine($"名称：{模式配置.名称}");
            sb.AppendLine($"当前模式：{模式配置.当前模式}");
            sb.AppendLine($"启用：{模式配置.启用}");
            sb.AppendLine($"无可用切换时兜底模式：{模式配置.无可用切换时兜底模式}");
            sb.AppendLine($"输出切换调试日志：{模式配置.输出切换调试日志}");

            if (模式配置.切换模式列表 == null)
            {
                sb.AppendLine("切换模式列表 = 空");
                continue;
            }

            sb.AppendLine($"切换模式列表数量：{模式配置.切换模式列表.Count}");

            float 总有效权重 = 0f;
            for (int j = 0; j < 模式配置.切换模式列表.Count; j++)
            {
                敌人行动切换条目 条目 = 模式配置.切换模式列表[j];
                if (条目 == null)
                    continue;

                if (!条目.启用)
                    continue;

                if (条目.权重 <= 0f)
                    continue;

                总有效权重 += 条目.权重;
            }

            sb.AppendLine($"总有效权重：{总有效权重}");

            for (int j = 0; j < 模式配置.切换模式列表.Count; j++)
            {
                敌人行动切换条目 条目 = 模式配置.切换模式列表[j];

                sb.AppendLine($"  切换条目 [{j}]");

                if (条目 == null)
                {
                    sb.AppendLine("    条目 = 空");
                    continue;
                }

                bool 有效 = 条目.启用 && 条目.权重 > 0f;
                float 实际概率 = 总有效权重 > 0f && 有效 ? 条目.权重 / 总有效权重 : 0f;

                sb.AppendLine($"    名称：{条目.名称}");
                sb.AppendLine($"    启用：{条目.启用}");
                sb.AppendLine($"    目标模式：{条目.目标模式}");
                sb.AppendLine($"    权重：{条目.权重}");
                sb.AppendLine($"    实际概率：{实际概率:P1}");
                sb.AppendLine($"    强制选择：{条目.强制选择}");
                sb.AppendLine($"    调试输出：{条目.调试输出}");
            }
        }
    }

    protected 敌人行动模式 从行动AI配置选择下一个模式(
        敌人行动AI配置 当前配置,
        敌人行动模式 当前模式,
        string 日志前缀,
        bool 额外输出调试日志 = false
    )
    {
        if (当前配置 == null)
            return 敌人行动模式.调位;

        敌人行动模式配置 配置 = 当前配置.获取模式配置(当前模式);
        if (配置 == null || !配置.启用)
        {
            if (额外输出调试日志 || 当前配置.输出调试日志)
            {
                Debug.LogWarning(
                    $"{日志前缀} 找不到行动模式配置：{当前模式}，使用全局兜底：{当前配置.全局兜底模式}",
                    this
                );
            }

            return 当前配置.全局兜底模式;
        }

        List<敌人行动切换条目> 列表 = 配置.切换模式列表;
        if (列表 == null || 列表.Count == 0)
        {
            输出行动切换日志(当前配置, 配置, 当前模式, 配置.无可用切换时兜底模式, 日志前缀, "切换列表为空", 额外输出调试日志);
            return 配置.无可用切换时兜底模式;
        }

        // 1. 强制选择优先：列表里第一个有效强制项。
        for (int i = 0; i < 列表.Count; i++)
        {
            敌人行动切换条目 条目 = 列表[i];
            if (!切换条目可用(条目))
                continue;

            if (!条目.强制选择)
                continue;

            输出行动切换日志(当前配置, 配置, 当前模式, 条目.目标模式, 日志前缀, "强制选择", 额外输出调试日志 || 条目.调试输出);
            return 条目.目标模式;
        }

        // 2. 按权重随机。
        float 总权重 = 0f;
        for (int i = 0; i < 列表.Count; i++)
        {
            敌人行动切换条目 条目 = 列表[i];
            if (!切换条目可用(条目))
                continue;

            总权重 += Mathf.Max(0f, 条目.权重);
        }

        if (总权重 <= 0f)
        {
            输出行动切换日志(当前配置, 配置, 当前模式, 配置.无可用切换时兜底模式, 日志前缀, "没有可用权重", 额外输出调试日志);
            return 配置.无可用切换时兜底模式;
        }

        float 随机值 = Random.Range(0f, 总权重);
        float 累计 = 0f;

        for (int i = 0; i < 列表.Count; i++)
        {
            敌人行动切换条目 条目 = 列表[i];
            if (!切换条目可用(条目))
                continue;

            累计 += Mathf.Max(0f, 条目.权重);
            if (随机值 <= 累计)
            {
                输出行动切换日志(
                    当前配置,
                    配置,
                    当前模式,
                    条目.目标模式,
                    日志前缀,
                    $"权重随机 随机值={随机值:F3}/总权重={总权重:F3}",
                    额外输出调试日志 || 条目.调试输出
                );

                return 条目.目标模式;
            }
        }

        输出行动切换日志(当前配置, 配置, 当前模式, 配置.无可用切换时兜底模式, 日志前缀, "随机兜底", 额外输出调试日志);
        return 配置.无可用切换时兜底模式;
    }

    protected virtual bool 切换条目可用(敌人行动切换条目 条目)
    {
        if (条目 == null)
            return false;

        if (!条目.启用)
            return false;

        if (条目.权重 <= 0f)
            return false;

        return true;
    }

    private void 输出行动切换日志(
        敌人行动AI配置 当前配置,
        敌人行动模式配置 模式配置,
        敌人行动模式 当前模式,
        敌人行动模式 下一个模式,
        string 日志前缀,
        string 原因,
        bool 额外输出调试日志
    )
    {
        if (当前配置 == null)
            return;

        bool 输出 =
            额外输出调试日志 ||
            当前配置.输出调试日志 ||
            (模式配置 != null && 模式配置.输出切换调试日志);

        if (!输出)
            return;

        Debug.Log($"<color=#66CCFF>{日志前缀}</color> {当前模式} => {下一个模式}，原因：{原因}", this);
    }
}
