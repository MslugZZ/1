using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

[System.Serializable]
public class 敌人索敌目标
{
    public 玩家数据 玩家;
    public 坐骑入口new 坐骑;
    public 敌人数据基类 敌人;
    public Collider2D 被击框;
    public int 玩家P = -1;

    [SerializeField]
    private Transform 目标Transform;

    public bool 是坐骑目标 => 坐骑 != null;
    public bool 是注册被击框目标 => 被击框 != null;

    // 关键：为了兼容你现有状态集合里的 当前目标.transform。
    // 如果是坐骑目标，每次读取 transform 时都会刷新到坐骑被击框/碰撞器中心。
    public Transform transform
    {
        get
        {
            if (坐骑 != null)
            {
                Vector3 位置 = 敌人索敌工具.获取坐骑索敌位置(坐骑);
                目标Transform = 敌人索敌工具.获取或创建玩家索敌代理点(玩家P, 位置);
            }

            if (被击框 != null)
                目标Transform = 被击框.transform;
            else if (敌人 != null)
                目标Transform = 敌人.transform;

            return 目标Transform;
        }
    }

    public Vector3 目标位置
    {
        get
        {
            if (被击框 != null)
                return 被击框.bounds.center;

            Transform t = transform;
            return t != null ? t.position : Vector3.zero;
        }
    }

    /// <summary>
    /// 用于AI分岔判断的“目标所在路面Y”。
    /// 优先取目标当前脚下地面线Y；
    /// 如果目标离地，则使用上一次有效路面Y；
    /// 最后才兜底用被击框底部Y / transform.y。
    /// </summary>
    public float 目标脚底Y
    {
        get
        {
            if (敌人索敌工具.尝试获取索敌目标脚底Y(this, out float y))
                return y;

            return 目标位置.y;
        }
    }

    public int 目标Key
    {
        get
        {
            unchecked
            {
                int key = 17;

                key = key * 31 + 玩家P;

                if (玩家 != null)
                    key = key * 31 + 玩家.GetInstanceID();

                if (坐骑 != null)
                    key = key * 31 + 坐骑.GetInstanceID();

                if (敌人 != null)
                    key = key * 31 + 敌人.GetInstanceID();

                if (被击框 != null)
                    key = key * 31 + 被击框.GetInstanceID();

                return key;
            }
        }
    }

    public bool 有效
    {
        get
        {
            if (坐骑 != null)
            {
                if (!坐骑.gameObject.activeInHierarchy || !坐骑.是否被驾驶 || 坐骑.玩家P != 玩家P)
                    return false;

                Collider2D 坐骑被击框 = 敌人索敌工具.获取坐骑索敌被击框(坐骑);
                被击框规则 坐骑规则;
                return 被击框判定工具.尝试获取可索敌规则(坐骑被击框, out 坐骑规则, true);
            }

            if (玩家 != null)
            {
                if (!玩家.gameObject.activeInHierarchy)
                    return false;

                Collider2D 玩家被击框 = 敌人索敌工具.获取玩家索敌被击框(玩家);
                被击框规则 玩家规则;
                return 被击框判定工具.尝试获取可索敌规则(玩家被击框, out 玩家规则, true);
            }

            if (被击框 != null || 敌人 != null)
            {
                if (敌人 == null) return false;
                if (被击框 == null) return false;
                if (!敌人.gameObject.activeInHierarchy) return false;
                if (!被击框.gameObject.activeInHierarchy) return false;
                if (!被击框.enabled) return false;

                被击框规则 敌人规则;
                return 被击框判定工具.尝试获取可索敌规则(被击框, out 敌人规则, true);
            }

            return false;
        }
    }

    public 敌人索敌目标(玩家数据 新玩家, 坐骑入口new 新坐骑, int 新玩家P, Transform 新目标Transform)
    {
        玩家 = 新玩家;
        坐骑 = 新坐骑;
        玩家P = 新玩家P;
        目标Transform = 新目标Transform;
    }


    public 敌人索敌目标(敌人数据基类 新敌人, Collider2D 新被击框)
    {
        玩家 = null;
        坐骑 = null;
        玩家P = -1;
        敌人 = 新敌人;
        被击框 = 新被击框;
        目标Transform = 新被击框 != null ? 新被击框.transform : (新敌人 != null ? 新敌人.transform : null);
    }
}

public static class 敌人索敌工具
{
    private static readonly Transform[] 玩家索敌代理点 = new Transform[2];

    // 目标离地时使用的“上一次有效路面Y”缓存。
    // Key 用 玩家/坐骑 的 InstanceID。
    private static readonly Dictionary<int, float> 目标上次有效路面Y缓存 = new Dictionary<int, float>(16);

    private static readonly BindingFlags 反射标志 =
        BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

    // =========================================================
    // 旧玩家判断：保留给其他旧脚本用
    // =========================================================

    /// <summary>
    /// 玩家节点还存在且处于激活状态，就算有效玩家本体。
    /// 注意：玩家进入坐骑后通常会 inactive，所以这里会返回 false。
    /// 敌人AI建议使用下面的“索敌目标”接口。
    /// </summary>
    public static bool 是有效目标(玩家数据 玩家)
    {
        if (玩家 == null) return false;
        if (!玩家.gameObject.activeInHierarchy) return false;
        return true;
    }

    public static 玩家数据 获取最近有效玩家(Vector3 当前位置)
    {
        玩家数据 p1 = 是有效目标(玩家数据.玩家数据P1) ? 玩家数据.玩家数据P1 : null;
        玩家数据 p2 = 是有效目标(玩家数据.玩家数据P2) ? 玩家数据.玩家数据P2 : null;

        if (p1 == null) return p2;
        if (p2 == null) return p1;

        float p1距离平方 = (p1.transform.position - 当前位置).sqrMagnitude;
        float p2距离平方 = (p2.transform.position - 当前位置).sqrMagnitude;

        return p1距离平方 <= p2距离平方 ? p1 : p2;
    }

    public static 玩家数据 获取随机有效玩家()
    {
        bool p1有效 = 是有效目标(玩家数据.玩家数据P1);
        bool p2有效 = 是有效目标(玩家数据.玩家数据P2);

        if (p1有效 && p2有效)
            return Random.value < 0.5f ? 玩家数据.玩家数据P1 : 玩家数据.玩家数据P2;

        if (p1有效) return 玩家数据.玩家数据P1;
        if (p2有效) return 玩家数据.玩家数据P2;

        return null;
    }

    public static 玩家数据 获取随机有效玩家_尽量不同(玩家数据 上一次目标)
    {
        bool p1有效 = 是有效目标(玩家数据.玩家数据P1);
        bool p2有效 = 是有效目标(玩家数据.玩家数据P2);

        if (!p1有效 && !p2有效)
            return null;

        if (p1有效 && !p2有效)
            return 玩家数据.玩家数据P1;

        if (!p1有效 && p2有效)
            return 玩家数据.玩家数据P2;

        if (上一次目标 == 玩家数据.玩家数据P1)
            return Random.value < 0.7f ? 玩家数据.玩家数据P2 : 玩家数据.玩家数据P1;

        if (上一次目标 == 玩家数据.玩家数据P2)
            return Random.value < 0.7f ? 玩家数据.玩家数据P1 : 玩家数据.玩家数据P2;

        return Random.value < 0.5f ? 玩家数据.玩家数据P1 : 玩家数据.玩家数据P2;
    }

    public static 玩家数据 获取有效玩家_最近优先但可随机(Vector3 当前位置, float 随机改目标概率 = 0.35f)
    {
        玩家数据 最近目标 = 获取最近有效玩家(当前位置);
        玩家数据 随机目标 = 获取随机有效玩家();

        if (最近目标 == null) return null;
        if (随机目标 == null) return 最近目标;
        if (最近目标 == 随机目标) return 最近目标;

        return Random.value < 随机改目标概率 ? 随机目标 : 最近目标;
    }

    // =========================================================
    // 新索敌目标接口：支持玩家进入坐骑
    // =========================================================

    public static bool 是否存在有效索敌目标()
    {
        return 获取P1索敌目标() != null || 获取P2索敌目标() != null;
    }

    public static bool 是否所有索敌目标都失效()
    {
        return !是否存在有效索敌目标();
    }

    public static 敌人索敌目标 获取最近有效目标(Vector3 当前位置)
    {
        敌人索敌目标 p1 = 获取P1索敌目标();
        敌人索敌目标 p2 = 获取P2索敌目标();

        if (p1 == null) return p2;
        if (p2 == null) return p1;

        float p1距离平方 = (p1.目标位置 - 当前位置).sqrMagnitude;
        float p2距离平方 = (p2.目标位置 - 当前位置).sqrMagnitude;

        return p1距离平方 <= p2距离平方 ? p1 : p2;
    }


    public static bool 是否存在有效索敌目标(敌人数据基类 查询者, float 最大距离 = -1f)
    {
        if (查询者 == null)
            return 是否存在有效索敌目标();

        return 获取最近有效目标(查询者.transform.position, 查询者, 最大距离) != null;
    }

    public static bool 是否所有索敌目标都失效(敌人数据基类 查询者, float 最大距离 = -1f)
    {
        return !是否存在有效索敌目标(查询者, 最大距离);
    }

    public static 敌人索敌目标 获取最近有效目标(Vector3 当前位置, 敌人数据基类 查询者, float 最大距离 = -1f)
    {
        if (查询者 == null)
            return 获取最近有效目标(当前位置);

        敌人索敌目标 最近目标 = null;
        float 最近距离平方 = 最大距离 > 0f ? 最大距离 * 最大距离 : float.MaxValue;

        // 敌军默认继续兼容旧逻辑：优先把 P1/P2 玩家/坐骑纳入候选。
        if (!查询者.是否友军)
        {
            敌人索敌目标 玩家或坐骑目标 = 获取最近有效目标(当前位置);
            if (玩家或坐骑目标 != null && 玩家或坐骑目标.有效 && 索敌目标符合图层和标签(玩家或坐骑目标, 查询者.当前索敌图层, 查询者.当前索敌标签))
            {
                float d = (玩家或坐骑目标.目标位置 - 当前位置).sqrMagnitude;
                if (d <= 最近距离平方)
                {
                    最近距离平方 = d;
                    最近目标 = 玩家或坐骑目标;
                }
            }
        }

        敌人索敌目标 注册表目标 = 获取最近注册被击框目标(当前位置, 查询者, 查询者.当前索敌图层, 查询者.当前索敌标签, 最近距离平方);
        if (注册表目标 != null && 注册表目标.有效)
        {
            float d = (注册表目标.目标位置 - 当前位置).sqrMagnitude;
            if (d <= 最近距离平方)
                最近目标 = 注册表目标;
        }

        return 最近目标;
    }

    /// <summary>
    /// 获取查询者当前能够索敌的全部有效目标。
    /// 结果会先被清空；筛选规则与“获取最近有效目标”保持一致，支持玩家、坐骑和注册被击框目标。
    /// 最大距离小于等于0表示不限制距离。
    /// </summary>
    public static int 获取全部有效目标(敌人数据基类 查询者, List<敌人索敌目标> 结果, float 最大距离 = -1f)
    {
        if (结果 == null)
            return 0;

        结果.Clear();
        if (查询者 == null)
            return 0;

        Vector3 当前位置 = 查询者.transform.position;
        float 最大距离平方 = 最大距离 > 0f ? 最大距离 * 最大距离 : float.MaxValue;

        // 敌军继续兼容玩家/坐骑目标。P1、P2必须分别加入，不能只取两者中的最近者。
        if (!查询者.是否友军)
        {
            尝试加入全部目标结果(
                获取P1索敌目标(),
                查询者,
                当前位置,
                最大距离平方,
                结果);

            尝试加入全部目标结果(
                获取P2索敌目标(),
                查询者,
                当前位置,
                最大距离平方,
                结果);
        }

        敌人被击框注册表.清理无效项();
        List<敌人被击框注册项> 注册列表 = 敌人被击框注册表.获取目标列表(查询者.是否友军);
        if (注册列表 == null || 注册列表.Count == 0)
            return 结果.Count;

        for (int i = 0; i < 注册列表.Count; i++)
        {
            敌人被击框注册项 项 = 注册列表[i];
            if (项 == null || !项.当前可被索敌 || 项.所属敌人 == 查询者)
                continue;

            Collider2D col = 项.碰撞器;
            if (!碰撞体符合图层和标签(col, 查询者.当前索敌图层, 查询者.当前索敌标签))
                continue;

            敌人索敌目标 目标 = new 敌人索敌目标(项.所属敌人, col);
            尝试加入全部目标结果(目标, 查询者, 当前位置, 最大距离平方, 结果);
        }

        return 结果.Count;
    }

    /// <summary>
    /// 分配并返回查询者当前能够索敌的全部有效目标。
    /// 高频逻辑建议复用List并调用上面的填充重载，避免反复分配列表。
    /// </summary>
    public static List<敌人索敌目标> 获取全部有效目标(敌人数据基类 查询者, float 最大距离 = -1f)
    {
        List<敌人索敌目标> 结果 = new List<敌人索敌目标>();
        获取全部有效目标(查询者, 结果, 最大距离);
        return 结果;
    }

    private static void 尝试加入全部目标结果(
        敌人索敌目标 目标,
        敌人数据基类 查询者,
        Vector3 当前位置,
        float 最大距离平方,
        List<敌人索敌目标> 结果)
    {
        if (目标 == null || !目标.有效)
            return;

        if (!索敌目标符合图层和标签(目标, 查询者.当前索敌图层, 查询者.当前索敌标签))
            return;

        if ((目标.目标位置 - 当前位置).sqrMagnitude > 最大距离平方)
            return;

        // 注册表正常情况下不会重复注册同一Collider；这里再做一次保护，
        // 避免异常重复项影响左右回头点和最近目标选择。
        for (int i = 0; i < 结果.Count; i++)
        {
            敌人索敌目标 已有 = 结果[i];
            if (已有 == null)
                continue;

            if (目标.被击框 != null && 已有.被击框 == 目标.被击框)
                return;

            if (目标.玩家P >= 0 &&
                已有.玩家P == 目标.玩家P &&
                已有.玩家 == 目标.玩家 &&
                已有.坐骑 == 目标.坐骑)
            {
                return;
            }
        }

        结果.Add(目标);
    }

    /// <summary>
    /// 获取当前 X 方向前方最近的有效索敌目标。只用目标位置X判断前方/身后，不用Y过滤。
    /// 主要用于趴下炮筒兵：目标在空中或飞机坐骑上时，只要X在前方，也允许进入趴下开炮。
    /// </summary>
    public static 敌人索敌目标 获取最近有效目标_仅前方X(Vector3 当前位置, int 前方方向, float x容差 = 0.05f)
    {
        前方方向 = 前方方向 >= 0 ? 1 : -1;
        x容差 = Mathf.Max(0f, x容差);

        敌人索敌目标 最近目标 = null;
        float 最近水平距离 = float.MaxValue;

        更新最近前方目标_仅X(获取P1索敌目标(), 当前位置, 前方方向, x容差, ref 最近目标, ref 最近水平距离);
        更新最近前方目标_仅X(获取P2索敌目标(), 当前位置, 前方方向, x容差, ref 最近目标, ref 最近水平距离);

        return 最近目标;
    }

    /// <summary>
    /// 获取当前 X 方向前方最近的有效索敌目标，并按查询者的索敌图层/标签过滤。只用目标位置X判断前方/身后，不用Y过滤。
    /// </summary>
    public static 敌人索敌目标 获取最近有效目标_仅前方X(Vector3 当前位置, 敌人数据基类 查询者, int 前方方向, float x容差 = 0.05f, float 最大水平距离 = -1f)
    {
        if (查询者 == null)
            return 获取最近有效目标_仅前方X(当前位置, 前方方向, x容差);

        前方方向 = 前方方向 >= 0 ? 1 : -1;
        x容差 = Mathf.Max(0f, x容差);

        敌人索敌目标 最近目标 = null;
        float 最近水平距离 = 最大水平距离 > 0f ? 最大水平距离 : float.MaxValue;

        if (!查询者.是否友军)
        {
            敌人索敌目标 p1 = 获取P1索敌目标();
            if (p1 != null && p1.有效 && 索敌目标符合图层和标签(p1, 查询者.当前索敌图层, 查询者.当前索敌标签))
                更新最近前方目标_仅X(p1, 当前位置, 前方方向, x容差, ref 最近目标, ref 最近水平距离);

            敌人索敌目标 p2 = 获取P2索敌目标();
            if (p2 != null && p2.有效 && 索敌目标符合图层和标签(p2, 查询者.当前索敌图层, 查询者.当前索敌标签))
                更新最近前方目标_仅X(p2, 当前位置, 前方方向, x容差, ref 最近目标, ref 最近水平距离);
        }

        敌人索敌目标 注册表目标 = 获取最近注册被击框目标_仅前方X(当前位置, 查询者, 查询者.当前索敌图层, 查询者.当前索敌标签, 前方方向, x容差, 最近水平距离);
        if (注册表目标 != null && 注册表目标.有效)
            更新最近前方目标_仅X(注册表目标, 当前位置, 前方方向, x容差, ref 最近目标, ref 最近水平距离);

        return 最近目标;
    }

    private static void 更新最近前方目标_仅X(敌人索敌目标 目标, Vector3 当前位置, int 前方方向, float x容差, ref 敌人索敌目标 最近目标, ref float 最近水平距离)
    {
        if (目标 == null || !目标.有效)
            return;

        float dx = 目标.目标位置.x - 当前位置.x;
        if (前方方向 > 0)
        {
            if (dx < -x容差)
                return;
        }
        else
        {
            if (dx > x容差)
                return;
        }

        float 水平距离 = Mathf.Abs(dx);
        if (水平距离 <= 最近水平距离)
        {
            最近水平距离 = 水平距离;
            最近目标 = 目标;
        }
    }

    private static 敌人索敌目标 获取最近注册被击框目标_仅前方X(Vector3 当前位置, 敌人数据基类 查询者, LayerMask 目标图层, IReadOnlyList<string> 目标标签, int 前方方向, float x容差, float 最大水平距离)
    {
        if (查询者 == null)
            return null;

        敌人被击框注册表.清理无效项();
        List<敌人被击框注册项> 列表 = 敌人被击框注册表.获取目标列表(查询者.是否友军);
        if (列表 == null || 列表.Count == 0)
            return null;

        敌人被击框注册项 最近项 = null;
        float 最近水平距离 = 最大水平距离;

        for (int i = 0; i < 列表.Count; i++)
        {
            敌人被击框注册项 项 = 列表[i];
            if (项 == null || !项.当前可被索敌)
                continue;

            if (项.所属敌人 == 查询者)
                continue;

            Collider2D col = 项.碰撞器;
            if (!碰撞体符合图层和标签(col, 目标图层, 目标标签))
                continue;

            float dx = col.bounds.center.x - 当前位置.x;
            if (前方方向 > 0)
            {
                if (dx < -x容差)
                    continue;
            }
            else
            {
                if (dx > x容差)
                    continue;
            }

            float 水平距离 = Mathf.Abs(dx);
            if (水平距离 <= 最近水平距离)
            {
                最近水平距离 = 水平距离;
                最近项 = 项;
            }
        }

        if (最近项 == null)
            return null;

        return new 敌人索敌目标(最近项.所属敌人, 最近项.碰撞器);
    }

    private static 敌人索敌目标 获取最近注册被击框目标(Vector3 当前位置, 敌人数据基类 查询者, LayerMask 目标图层, IReadOnlyList<string> 目标标签, float 最大距离平方)
    {
        if (查询者 == null)
            return null;

        敌人被击框注册表.清理无效项();
        List<敌人被击框注册项> 列表 = 敌人被击框注册表.获取目标列表(查询者.是否友军);
        if (列表 == null || 列表.Count == 0)
            return null;

        敌人被击框注册项 最近项 = null;
        float 最近距离平方 = 最大距离平方;

        for (int i = 0; i < 列表.Count; i++)
        {
            敌人被击框注册项 项 = 列表[i];
            if (项 == null || !项.当前可被索敌)
                continue;

            if (项.所属敌人 == 查询者)
                continue;

            Collider2D col = 项.碰撞器;
            if (!碰撞体符合图层和标签(col, 目标图层, 目标标签))
                continue;

            float d = ((Vector3)col.bounds.center - 当前位置).sqrMagnitude;
            if (d <= 最近距离平方)
            {
                最近距离平方 = d;
                最近项 = 项;
            }
        }

        if (最近项 == null)
            return null;

        return new 敌人索敌目标(最近项.所属敌人, 最近项.碰撞器);
    }

    public static bool 索敌目标符合图层和标签(敌人索敌目标 目标, LayerMask 目标图层, IReadOnlyList<string> 目标标签)
    {
        if (目标 == null)
            return false;

        if (目标.被击框 != null)
            return 碰撞体符合图层和标签(目标.被击框, 目标图层, 目标标签);

        if (目标.坐骑 != null)
            return 碰撞体符合图层和标签(获取坐骑被击框碰撞器(目标.坐骑), 目标图层, 目标标签);

        if (目标.玩家 != null)
            return 碰撞体符合图层和标签(获取玩家被击框碰撞器(目标.玩家), 目标图层, 目标标签);

        return false;
    }

    /// <summary>
    /// 方法名保留用于兼容旧调用者；新系统忽略标签参数，只检查图层和被击框规则。
    /// </summary>
    public static bool 碰撞体符合图层和标签(Collider2D col, LayerMask 目标图层, IReadOnlyList<string> 目标标签)
    {
        if (col == null)
            return false;

        if (!col.gameObject.activeInHierarchy)
            return false;

        if (!col.enabled)
            return false;

        if (目标图层.value == 0)
            return false;

        if ((目标图层.value & (1 << col.gameObject.layer)) == 0)
            return false;

        被击框规则 规则;
        return 被击框判定工具.尝试获取可索敌规则(col, out 规则, true);
    }

    public static 敌人索敌目标 获取随机有效目标()
    {
        敌人索敌目标 p1 = 获取P1索敌目标();
        敌人索敌目标 p2 = 获取P2索敌目标();

        if (p1 != null && p2 != null)
            return Random.value < 0.5f ? p1 : p2;

        if (p1 != null) return p1;
        if (p2 != null) return p2;

        return null;
    }

    public static 敌人索敌目标 获取随机有效目标_尽量不同(敌人索敌目标 上一次目标)
    {
        敌人索敌目标 p1 = 获取P1索敌目标();
        敌人索敌目标 p2 = 获取P2索敌目标();

        if (p1 == null && p2 == null)
            return null;

        if (p1 != null && p2 == null)
            return p1;

        if (p1 == null && p2 != null)
            return p2;

        int 上次P = 上一次目标 != null ? 上一次目标.玩家P : -1;

        if (上次P == 0)
            return Random.value < 0.7f ? p2 : p1;

        if (上次P == 1)
            return Random.value < 0.7f ? p1 : p2;

        return Random.value < 0.5f ? p1 : p2;
    }

    public static 敌人索敌目标 获取有效目标_最近优先但可随机(Vector3 当前位置, float 随机改目标概率 = 0.35f)
    {
        敌人索敌目标 最近目标 = 获取最近有效目标(当前位置);
        敌人索敌目标 随机目标 = 获取随机有效目标();

        if (最近目标 == null) return null;
        if (随机目标 == null) return 最近目标;
        if (最近目标.玩家P == 随机目标.玩家P) return 最近目标;

        return Random.value < 随机改目标概率 ? 随机目标 : 最近目标;
    }

    private static 敌人索敌目标 获取P1索敌目标()
    {
        return 获取玩家索敌目标(玩家数据.玩家数据P1, 0);
    }

    private static 敌人索敌目标 获取P2索敌目标()
    {
        return 获取玩家索敌目标(玩家数据.玩家数据P2, 1);
    }

    private static 敌人索敌目标 获取玩家索敌目标(玩家数据 玩家, int 玩家P)
    {
        // 1. 如果玩家正在驾驶坐骑，优先把坐骑的“可被攻击位置”当作目标。
        坐骑入口new 驾驶坐骑 = 查找玩家当前驾驶坐骑(玩家P);
        if (驾驶坐骑 != null)
        {
            Vector3 坐骑目标位置 = 获取坐骑索敌位置(驾驶坐骑);
            Transform 代理点 = 获取或创建玩家索敌代理点(玩家P, 坐骑目标位置);

            return new 敌人索敌目标(
                玩家,
                驾驶坐骑,
                玩家P,
                代理点
            );
        }

        // 2. 没坐骑时，玩家本体 active 才能作为目标。
        if (玩家 != null && 玩家.gameObject.activeInHierarchy)
        {
            return new 敌人索敌目标(
                玩家,
                null,
                玩家P,
                玩家.transform
            );
        }

        return null;
    }

    private static 坐骑入口new 查找玩家当前驾驶坐骑(int 玩家P)
    {
        return 坐骑入口new.获取玩家当前驾驶坐骑(玩家P);
    }

    // =========================================================
    // 索敌位置：用于瞄准/追踪
    // =========================================================

    public static Vector3 获取坐骑索敌位置(坐骑入口new 坐骑)
    {
        if (坐骑 == null)
            return Vector3.zero;

        // 优先级1：坐骑被击框节点。
        // 这里用 Collider2D.bounds.center，所以会正确包含 BoxCollider2D.offset。
        Collider2D 被击框 = 获取坐骑被击框碰撞器(坐骑);
        if (被击框 != null && 被击框.enabled)
            return 被击框.bounds.center;

        // 优先级2：公共主物理碰撞器。
        BoxCollider2D 主物理框 = 坐骑.获取公共主物理碰撞器();
        if (主物理框 != null && 主物理框.enabled)
            return 主物理框.bounds.center;

        // 优先级3：坐骑根节点。
        return 坐骑.transform.position;
    }

    // =========================================================
    // 目标脚底/路面Y：用于AI分岔判断
    // =========================================================

    public static bool 尝试获取索敌目标脚底Y(敌人索敌目标 目标, out float 脚底Y)
    {
        脚底Y = 0f;

        if (目标 == null)
            return false;

        if (目标.坐骑 != null)
        {
            if (尝试获取坐骑索敌脚底Y(目标.坐骑, out 脚底Y))
                return true;
        }

        if (目标.玩家 != null)
        {
            if (尝试获取玩家索敌脚底Y(目标.玩家, out 脚底Y))
                return true;
        }

        if (目标.transform != null)
        {
            脚底Y = 目标.transform.position.y;
            return true;
        }

        return false;
    }

    public static bool 尝试获取坐骑索敌脚底Y(坐骑入口new 坐骑, out float 脚底Y)
    {
        脚底Y = 0f;

        if (坐骑 == null)
            return false;

        int 目标Key = 坐骑.GetInstanceID();

        if (坐骑.坐骑索敌被击框 == null)
            坐骑.缓存坐骑索敌被击框();

        Collider2D 被击框 = 坐骑.坐骑索敌被击框;
        float 目标X = 被击框 != null ? 被击框.bounds.center.x : 坐骑.transform.position.x;

        // 第一优先：坐骑当前脚下路面Y。
        // 如果坐骑控制器实现了 I脚下地面碰撞器，就能正确处理跳跃/被击飞。
        if (尝试从脚下地面提供者获取路面Y(坐骑, 目标Key, 目标X, out 脚底Y))
            return true;

        // 第二优先：坐骑被击框底部。
        if (被击框 != null && 被击框.enabled && 被击框.gameObject.activeInHierarchy)
        {
            脚底Y = 被击框.bounds.min.y;
            return true;
        }

        BoxCollider2D 主物理框 = 坐骑.获取公共主物理碰撞器();

        if (主物理框 != null && 主物理框.enabled && 主物理框.gameObject.activeInHierarchy)
        {
            脚底Y = 主物理框.bounds.min.y;
            return true;
        }

        脚底Y = 坐骑.transform.position.y;
        return true;
    }

    public static bool 尝试获取玩家索敌脚底Y(玩家数据 玩家, out float 脚底Y)
    {
        脚底Y = 0f;

        if (玩家 == null)
            return false;

        int 目标Key = 玩家.GetInstanceID();
        float 目标X = 玩家.transform.position.x;

        // 第一优先：玩家当前脚下路面Y。
        // 这比被击框底部更适合判断上路/下路。
        if (尝试从脚下地面提供者获取路面Y(玩家, 目标Key, 目标X, out 脚底Y))
            return true;

        // 第二优先：脚底范围/被击框底部，仅作为兜底。
        I脚底范围提供者 脚底范围提供者 = 玩家.GetComponent<I脚底范围提供者>();

        if (脚底范围提供者 == null)
            脚底范围提供者 = 玩家.GetComponentInChildren<I脚底范围提供者>(true);

        if (脚底范围提供者 != null &&
            脚底范围提供者.尝试获取脚底检测Bounds(out Bounds 脚底Bounds))
        {
            脚底Y = 脚底Bounds.min.y;
            return true;
        }

        Collider2D 被击框 = 查找玩家被击框碰撞器(玩家);

        if (被击框 != null && 被击框.enabled && 被击框.gameObject.activeInHierarchy)
        {
            脚底Y = 被击框.bounds.min.y;
            return true;
        }

        脚底Y = 玩家.transform.position.y;
        return true;
    }

    /// <summary>
    /// 从目标的 I脚下地面碰撞器 获取当前脚下地面；
    /// 如果目标当前在地面，采样当前 EdgeCollider2D 的路面Y并缓存；
    /// 如果目标当前离地，返回上一次缓存的路面Y。
    /// </summary>
    private static bool 尝试从脚下地面提供者获取路面Y(Component 根组件, int 目标Key, float 目标X, out float 路面Y)
    {
        路面Y = 0f;

        if (根组件 == null)
            return false;

        I脚下地面碰撞器 脚下地面 = 查找脚下地面提供者(根组件);

        if (脚下地面 != null && 脚下地面.是否在地面)
        {
            Component 脚下地面组件 = 脚下地面 as Component;
            Collider2D 当前脚下地面 = 反射获取当前脚下地面碰撞器(脚下地面组件);

            if (当前脚下地面 != null)
            {
                if (尝试从脚下地面计算路面Y(当前脚下地面, 目标X, out 路面Y))
                {
                    目标上次有效路面Y缓存[目标Key] = 路面Y;
                    return true;
                }
            }
        }

        // 目标离地时，不使用空中脚底Y，改用上一次有效路面Y。
        if (目标上次有效路面Y缓存.TryGetValue(目标Key, out 路面Y))
            return true;

        return false;
    }

    private static I脚下地面碰撞器 查找脚下地面提供者(Component 根组件)
    {
        if (根组件 == null)
            return null;

        I脚下地面碰撞器 提供者 = 根组件.GetComponent<I脚下地面碰撞器>();

        if (提供者 != null)
            return 提供者;

        MonoBehaviour[] 所有脚本 = 根组件.GetComponentsInChildren<MonoBehaviour>(true);

        for (int i = 0; i < 所有脚本.Length; i++)
        {
            if (所有脚本[i] is I脚下地面碰撞器 p)
                return p;
        }

        return null;
    }

    /// <summary>
    /// 为了避免强制要求 I脚下地面碰撞器 接口必须声明 当前脚下地面碰撞器，
    /// 这里用反射读取实现类里的 public Collider2D 当前脚下地面碰撞器。
    /// 你的 玩家控制器new / 通用物理移动基类 都已经有这个属性。
    /// </summary>
    private static Collider2D 反射获取当前脚下地面碰撞器(Component 组件)
    {
        if (组件 == null)
            return null;

        PropertyInfo 属性 = 组件.GetType().GetProperty("当前脚下地面碰撞器", 反射标志);

        if (属性 == null)
            return null;

        if (!typeof(Collider2D).IsAssignableFrom(属性.PropertyType))
            return null;

        object 值 = 属性.GetValue(组件, null);
        return 值 as Collider2D;
    }

    /// <summary>
    /// 给定一个脚下地面 Collider2D 和目标X，求这个地面在目标X附近的世界Y。
    /// 主要适配 EdgeCollider2D。
    /// </summary>
    private static bool 尝试从脚下地面计算路面Y(Collider2D 地面碰撞器, float 目标X, out float 路面Y)
    {
        路面Y = 0f;

        if (地面碰撞器 == null)
            return false;

        EdgeCollider2D edge = 地面碰撞器 as EdgeCollider2D;

        if (edge == null || edge.pointCount < 2)
        {
            // 兜底：非Edge地面直接用bounds顶部。
            路面Y = 地面碰撞器.bounds.max.y;
            return true;
        }

        float 最佳距离 = float.PositiveInfinity;
        float 最佳Y = 0f;
        bool 找到 = false;

        Vector2 offset = edge.offset;

        for (int i = 0; i < edge.pointCount - 1; i++)
        {
            Vector2 a = edge.transform.TransformPoint(edge.points[i] + offset);
            Vector2 b = edge.transform.TransformPoint(edge.points[i + 1] + offset);

            float t;

            if (Mathf.Abs(b.x - a.x) <= 0.0001f)
            {
                // 近似竖线，直接取中点。
                t = 0.5f;
            }
            else
            {
                float minX = Mathf.Min(a.x, b.x);
                float maxX = Mathf.Max(a.x, b.x);
                float clampedX = Mathf.Clamp(目标X, minX, maxX);
                t = Mathf.InverseLerp(a.x, b.x, clampedX);
            }

            t = Mathf.Clamp01(t);

            Vector2 p = Vector2.Lerp(a, b, t);
            float dx = Mathf.Abs(p.x - 目标X);

            if (dx < 最佳距离)
            {
                最佳距离 = dx;
                最佳Y = p.y;
                找到 = true;
            }
        }

        if (!找到)
            return false;

        路面Y = 最佳Y;
        return true;
    }

    // =========================================================
    // 被击框查找兜底
    // =========================================================

    private static Collider2D 查找玩家被击框碰撞器(玩家数据 玩家)
    {
        return 获取玩家索敌被击框(玩家);
    }

    public static Collider2D 获取玩家索敌被击框(玩家数据 玩家)
    {
        if (玩家 == null)
            return null;

        if (玩家.玩家索敌被击框 == null)
            玩家.缓存玩家索敌被击框();

        Collider2D col = 玩家.玩家索敌被击框;
        if (col != null && col.enabled && col.gameObject.activeInHierarchy)
            return col;

        return null;
    }

    private static Collider2D 获取玩家被击框碰撞器(玩家数据 玩家)
    {
        return 获取玩家索敌被击框(玩家);
    }

    public static Collider2D 获取坐骑索敌被击框(坐骑入口new 坐骑)
    {
        if (坐骑 == null)
            return null;

        if (坐骑.坐骑索敌被击框 == null)
            坐骑.缓存坐骑索敌被击框();

        Collider2D col = 坐骑.坐骑索敌被击框;
        if (col != null && col.enabled && col.gameObject.activeInHierarchy)
            return col;

        return null;
    }

    private static Collider2D 获取坐骑被击框碰撞器(坐骑入口new 坐骑)
    {
        return 获取坐骑索敌被击框(坐骑);
    }

    // =========================================================
    // 坐骑目标代理点
    // =========================================================

    public static Transform 获取或创建玩家索敌代理点(int 玩家P, Vector3 世界位置)
    {
        int 索引 = Mathf.Clamp(玩家P, 0, 1);

        Transform 代理 = 玩家索敌代理点[索引];

        if (代理 == null)
        {
            GameObject go = new GameObject($"敌人索敌目标点_P{索引 + 1}");
            go.hideFlags = HideFlags.HideInHierarchy;
            代理 = go.transform;
            玩家索敌代理点[索引] = 代理;
        }

        代理.position = 世界位置;
        return 代理;
    }
}
