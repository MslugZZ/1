﻿using UnityEngine;
using UnityEngine.Serialization;
using System.Collections.Generic;

/// <summary>
/// 给 斜坡吸附助手 读取“边缘兜底开关”用的通用接口。
/// </summary>
public interface I边缘兜底开关
{
    bool 开启边缘兜底 { get; }
}

public interface I吸附限
{
    bool 启用吸附限制 { get; }
    float 空中最大下吸附 { get; }
    float 地面最大下吸附 { get; }
}

[System.Serializable]
public class 姿态碰撞器配置
{
    [Tooltip("方便在检查器里标记用途，例如：身体碰撞框、被击框、头部被击框、脚部被击框。")]
    public string 名称 = "碰撞器";

    [Tooltip("需要随站立/趴下姿态改变尺寸的 BoxCollider2D。")]
    public BoxCollider2D 碰撞器;

    public bool 启用 = true;

    [Header("站立")]
    public Vector2 站立尺寸 = new Vector2(1.0f, 2.0f);
    public Vector2 站立中心 = new Vector2(0f, 1.0f);

    [Header("趴下 / 蹲下")]
    public Vector2 趴下尺寸 = new Vector2(1.2f, 1.0f);
    public Vector2 趴下中心 = new Vector2(0f, 0.5f);
}

/// <summary>
/// 通用物理移动基类
/// 目标：
/// 1. 地面单位可用
/// 2. 空中单位可用
/// 3. 支持：单向墙 / 斜坡吸附 / 夹角阻挡 / 平台搭乘 / 挤压
/// 4. 功能全部可开关
/// </summary>
public abstract class 通用物理移动基类 : MonoBehaviour, I平台搭乘者, I挤压目标, I边缘兜底开关, I吸附限, I弹飞目标, I脚下地面碰撞器, I分岔输入源
{
    [Header("=== 核心引用 ===")]
    public Rigidbody2D 刚体;
    public BoxCollider2D 物理碰撞器;
    public 与单向墙碰撞 墙壁碰撞器;

    [Header("=== 运行模式开关 ===")]
    public bool 启用主动水平移动 = true;
    public bool 启用主动垂直移动 = false;
    public bool 启用重力 = true;
    public bool 启用地面吸附 = true;
    public bool 启用斜坡吸附 = true;
    public bool 启用夹角阻挡 = true;
    public bool 启用与单向墙碰撞 = true;
    public bool 启用平台搭乘 = true;
    [Tooltip("挤压相关参数都是本单位参与被挤压,不是挤压别人.\n比如:被挤压 / 被推动 / 被压死 / 被挤死")]
    public bool 启用挤压 = true;

    [Header("=== 挤压细分开关 ===")]
    [Tooltip("勾选后，本单位会检测头顶上方的挤压标志：可阻挡向上移动，也可解析上方下压锁定。" +
        "关闭后，上方挤压标志不会把本单位压下或压死。")]
    public bool 启用顶部阻挡解析 = true;
    public bool 启用下压致死判定 = true;
    public bool 启用水平推动 = true;
    public bool 启用水平挤死 = true;

    [Header("=== 作为水平推动来源时的主动减速 ===")]
    [Tooltip("同节点存在启用中的挤压标志，且水平推动确实接触我方目标时，只降低本单位主动水平位移。平台、外力和其它附加位移不受影响。")]
    public bool 启用水平推动主动减速 = true;

    [Range(0f, 1f)]
    [Tooltip("我方目标没有朝本单位主动移动时，本单位主动水平速度使用的倍率。")]
    public float 水平推动主动速度倍率 = 0.5f;

    [SerializeField, Tooltip("运行时只读：1=未推动，0.5=普通推动，0=目标朝本单位主动移动。")]
    private float 当前水平推动主动速度倍率 = 1f;

    [Header("=== 水平推动主动减速诊断 ===")]
    [Tooltip("开启后记录推动目标扫描、目标主动方向、抵抗判定和最终倍率。只用于测试，确认后建议关闭。")]
    public bool 启用水平推动主动减速诊断 = false;

    [Tooltip("开启诊断后，是否把诊断结果输出到Console。")]
    public bool 水平推动主动减速诊断_输出Console = true;

    [Min(1), Tooltip("Console诊断最小输出间隔（按Unity渲染帧计），避免每个物理帧刷屏。")]
    public int 水平推动主动减速诊断_输出间隔帧 = 10;

    [SerializeField, TextArea(3, 12), Tooltip("运行时只读：最近一次水平推动主动减速诊断。")]
    private string 水平推动主动减速诊断_最后结果 = "";

    private int 水平推动主动减速诊断_上次输出帧 = -999999;

    [Header("=== 边缘兜底 ===")]
    [Tooltip("给斜坡吸附助手读取的常用开关。注意：还需要按下方说明，给斜坡吸附助手做一次小改动才会真正生效。")]
    public bool 开启边缘兜底 = false;
    bool I边缘兜底开关.开启边缘兜底 => 开启边缘兜底;
    [Header("=== 吸附限制 ===")]
    [Tooltip("默认关闭。勾选后，斜坡吸附助手会限制“本帧最多允许向下吸附多少距离”，防止长射线时空中瞬移吸地。")]
    public bool 启用吸附限制 = true;

    [Tooltip("上一帧不在地面时，最多允许向下吸附的距离。建议先从 0.03 开始调。")]
    public float 空中最大下吸附 = 0.03f;

    [Tooltip("上一帧在地面/平台上时，最多允许向下吸附的距离。建议先从 0.12 开始调。")]
    public float 地面最大下吸附 = 1.5f;

    bool I吸附限.启用吸附限制 => 启用吸附限制;
    float I吸附限.空中最大下吸附 => 空中最大下吸附;
    float I吸附限.地面最大下吸附 => 地面最大下吸附;

    [Header("=== 旧版单碰撞器尺寸（兼容旧单位，可不填）===")]
    [Tooltip("开启后，通用物理移动基类会按 当前趴下姿态 写入主物理碰撞器的 size/offset。默认开启以兼容旧单位。关闭后，主物理碰撞器尺寸可交给动画姿态碰撞同步器等外部脚本控制。")]
    public bool 启用主物理碰撞器姿态尺寸同步 = true;

    [Tooltip("主物理碰撞器的站立尺寸。旧字段保留，避免影响已有单位。")]
    public Vector2 站立碰撞器尺寸 = new Vector2(1.0f, 2.0f);
    public Vector2 站立碰撞器中心 = new Vector2(0f, 1.0f);
    [Tooltip("主物理碰撞器的趴下/蹲下尺寸。旧字段保留，避免影响已有单位。")]
    public Vector2 趴下碰撞器尺寸 = new Vector2(1.2f, 1.0f);
    public Vector2 趴下碰撞器中心 = new Vector2(0f, 0.5f);

    [Header("=== 多碰撞器姿态尺寸 ===")]
    [Tooltip("开启后，通用物理移动基类会按 当前趴下姿态 写入下方 姿态碰撞器列表 里的碰撞器 size/offset。默认开启以兼容旧单位。关闭后，列表里的碰撞器尺寸可交给动画姿态碰撞同步器等外部脚本控制。")]
    public bool 启用姿态碰撞器列表尺寸同步 = true;

    [Tooltip("可选。大型单位或多被击框单位使用。每个元素把一个碰撞器引用和它的站立/趴下尺寸放在一起。" +
        "主物理碰撞器仍然会使用上面的旧字段；如果同一个碰撞器也填进这里，则列表里的配置会最后覆盖。")]
    public List<姿态碰撞器配置> 姿态碰撞器列表 = new List<姿态碰撞器配置>();

    [Header("=== 基础移动参数 ===")]
    [显示在面板]
    [Tooltip("单位整体速度倍率。1=正常，2=两倍速度，0.5=半速。影响本单位移动、重力/下落上限、状态计时和动画播放速度。")]
    public float 整体速度 = 1f;

    public float 有效整体速度 => Mathf.Max(0.01f, 整体速度);

    public float 套用速度倍率(float 原速度)
    {
        return 原速度 * 有效整体速度;
    }

    public float 套用时间倍率(float 原时间)
    {
        return 原时间 / 有效整体速度;
    }

    public float 套用计时Delta(float deltaTime)
    {
        return deltaTime * 有效整体速度;
    }

    [显示在面板]
    [Tooltip("地面移动的单位生效")]
    public float 地面水平移动速度 = 3f;
    [显示在面板]
    [Tooltip("趴下移动的单位生效")]
    public float 趴下水平移动速度 = 2f;
    [显示在面板]
    [Tooltip("空中移动的单位生效")]
    public float 空中水平移动速度 = 3f;
    [显示在面板]
    [Tooltip("空中移动的单位生效")]
    public float 主动垂直移动速度 = 3f;
    [显示在面板]
    public float 重力 = 25f;
    [显示在面板]
    public float 最大下落速度 = 15f;
    public float 皮肤宽度 = 0.015f;

    [Header("=== 死亡/外部速度 ===")]
    [Tooltip("由死亡表现、弹飞等外部逻辑启用。启用后，当前速度.x 会作为额外水平位移参与物理流程；当前速度.y 本来就参与重力流程。")]
    public bool 启用死亡外部速度 = false;

    [Tooltip("死亡动画事件调用停止全部移动后启用。启用期间不再应用重力、主动移动和死亡外部速度，直到外部重新设置死亡速度。")]
    public bool 死亡冻结全部移动 = false;

    [Tooltip("死亡/特殊状态临时忽略某类地面。优先使用地面检测规则；旧图层仅作为没有规则文件时的兼容兜底。持续时间小于0表示一直忽略，直到手动停止或落到实心地面。")]
    [SerializeField] protected bool 临时忽略地面启用 = false;

    [SerializeField] protected float 临时忽略地面剩余时间 = 0f;

    [SerializeField, Tooltip("旧版兼容兜底：仅当没有提供 临时忽略地面检测规则 时才会按图层忽略。新逻辑请优先使用规则文件。")]
    protected LayerMask 临时忽略地面图层;

    [SerializeField, Tooltip("新版临时忽略规则：命中的Collider符合这个地面检测规则文件时，地面吸附和单向世界2D线段裁剪都会跳过它。")]
    protected 地面检测规则文件 临时忽略地面检测规则;

    [Header("=== 地面检测 ===")]
    public Transform 射线起点;
    public Transform 地面检测点;
    [Tooltip("仅用于 Physics2D 查询候选Collider，不决定地面身份。真正能否站立/穿过/阻挡，由 地面规则 + 地面检测规则文件 决定。")]
    public LayerMask 地面图层;
    public float 射线长度 = 0.5f;
    public float 地面射线检测长度 = 1.5f;
    public float 地面缓冲距离 = 0.05f;

    [Header("=== 地面规则检测 ===")]
    [Tooltip("脚下地面检测规则。为空时，本基类默认按敌方单位规则：敌方可站我方/敌方/双方地面，但不可站 不可站/深水。玩家不走这里。")]
    public 地面检测规则文件 脚下地面检测规则;

    [Tooltip("脚下地面检测规则为空时，自动创建一份敌方单位默认规则。关闭后会退回 地面规则缓存 的我方默认规则。")]
    public bool 未指定检测规则时使用敌方默认脚下规则 = true;

    protected 地面检测规则文件 运行时敌方默认脚下规则;

    [Header("=== 水波特效 ===")]
    [Tooltip("默认开启。单位站在水面材质地面上时生成水波特效；离开水面时播放出水并回收。")]
    public bool 启用水波特效 = true;

    [Tooltip("本单位自己的水波素材大小。大型单位可以设为 不生成，或关闭 启用水波特效。具体预制体由 水花特效配置 里对应的水波条目决定。")]
    public 水波特效大小 水波大小 = 水波特效大小.中;

    [Tooltip("关闭时，水面规则只决定是否允许生成水波，实际水波大小使用本单位的 水波大小。开启时，实际水波大小改用脚下 地面规则.单位站立水波大小；但本单位 水波大小=不生成 时仍然不会生成。")]
    public bool 使用地面规则水波大小 = false;

    [Tooltip("可由外部注入。为空时，会尝试从 Resources 读取 默认水波配置Resources路径。")]
    public 水花特效配置 水波特效配置;

    [Tooltip("当 水波特效配置 为空时，从 Resources 读取这个路径。例如 Assets/Resources/配置/默认水花特效配置.asset 对应 配置/默认水花特效配置。")]
    public string 默认水波配置Resources路径 = "配置/默认水花特效配置";

    [Tooltip("开启后，水波从当前场景自动创建的对象池中生成。水波不需要动画事件回池，出水动画播完后自动回池。")]
    public bool 使用水波对象池 = true;

    [Tooltip("默认关闭：保持旧规则，水波单位ID=主体单位ID+1。开启后才使用下方的自定义单位ID。")]
    public bool 使用自定义水波动态层级单位ID = false;

    [Tooltip("仅在“使用自定义水波动态层级单位ID”开启时生效。")]
    public string 水波动态层级单位ID = "4";

    [Tooltip("水波播放父节点。为空则生成在场景根节点；回池后会自动移动到 水波特效对象池_自动创建 下。")]
    public Transform 水波特效父节点;

    [Tooltip("水波最终位置偏移。最终位置 = 脚下水面视觉位置 + 水花配置里的水波自身偏移 + 这里的偏移。")]
    public Vector3 水波特效位置偏移 = new Vector3(0f, 0.4f, 0f);

    [Tooltip("开启后，单位或父节点水平翻转时，水波特效位置偏移的X会同步反向。用于默认朝左/朝右素材翻转后保持脚边水波位置正确。")]
    public bool 水波特效位置偏移跟随水平翻转 = true;

    private static 水花特效配置 默认水波配置缓存;
    protected 水面特效控制器 当前水波特效;
    protected System.Action 水波特效结束回调;
    protected 水波特效大小 当前水波实际大小 = 水波特效大小.不生成;
    protected bool 水波上一帧接触水面 = false;
    protected bool 水波正在冻结跟随 = false;
    protected bool 水波有最后接触位置 = false;
    protected Vector3 水波最后接触基础位置;
    protected Vector3 水波冻结基础位置;
    protected 动态层级分组器 水波动态层级来源缓存;

    [Header("=== AI分岔输入 ===")]
    [Tooltip("勾选后，本单位会向斜坡吸附助手提供AI分岔输入。玩家不用勾，敌人需要走分岔时勾。")]
    public bool 启用AI分岔输入 = false;

    [Tooltip("勾选后，只有单位正在水平移动时才输出上/下分岔输入，避免原地待机时乱吸到分岔。")]
    public bool AI分岔需要水平移动 = true;

    [Tooltip("目标脚底Y高于/低于分岔中心Y多少，才判定为上路/下路。避免地面不平")]
    public float AI分岔Y判定阈值 = 0.12f;

    [Tooltip("进入同一个分岔窗口后，一旦选择上/下，就锁定到离开该窗口，避免目标Y抖动导致来回切。")]
    public bool AI分岔进入窗口后锁定选择 = true;

    [Tooltip("输出AI分岔选择日志。")]
    public bool AI分岔调试日志 = false;

    [Tooltip("勾选后，同一个目标在同一个分岔窗口内只选择一次；如果目标变化，则解除锁定并重新选择。")]
    public bool AI分岔目标变化时重新选择 = true;

    [SerializeField] protected int AI分岔当前垂直输入 = 0; // 1=上，-1=下，0=无
    [SerializeField] protected int AI分岔当前窗口Key = 0;
    [SerializeField] protected bool AI分岔在窗口内 = false;
    [SerializeField] protected bool AI分岔已锁定选择 = false;
    [SerializeField] protected int AI分岔锁定目标Key = 0;

    protected I敌人索敌目标提供者 AI分岔目标提供者缓存;

    [Header("=== 夹角探测 ===")]
    public Transform 右侧夹角探测点;
    public Transform 左侧夹角探测点;
    public LayerMask 夹角向上检测图层;
    public LayerMask 夹角向下检测图层;
    public float 夹角向上射线长度 = 2f;
    public float 夹角向下射线长度 = 2f;
    public float 斜坡最小角度 = 5f;
    public float 夹角最大允许上方距离 = 0.8f;
    public bool 绘制夹角探测射线 = true;

    [Header("=== 自身作为可搭乘移动地面 ===")]
    [Tooltip("默认关闭。仅在本单位自身带有可供其他单位站立的移动地面，并且本单位不需要再搭乘其他平台时开启。\n开启后，基类会提前完成本单位物理移动，并把本物理帧最终位移直接提交给下方列表中的所有地面，消除MovePosition位置差采样造成的一帧延迟。")]
    public bool 启用子节点搭乘地面同步 = false;

    [FormerlySerializedAs("挎斗地面位移源")]
    [Tooltip("手动拖入需要跟随本单位根节点最终位移的可搭乘地面位移源。支持多个，例如运输车多个站立区、BOSS多个可站立部位。\n列表为空时不会自动扫描子节点，也不会产生同步开销。")]
    public List<可搭乘Edge地面位移源> 子节点搭乘地面列表 = new List<可搭乘Edge地面位移源>();

    [Header("=== 平台搭乘 ===")]
    public bool 平台拖动直接叠加到位移 = true;

    [Tooltip("开启后，上一帧脚下平台向上移动但本帧贴地裁决暂时丢失命中时，不再直接保持在地面，而是先用预测后的脚底位置重新检测上一帧平台。检测成功才继续保持站立。")]
    public bool 平台搭乘_丢失命中时必须验证脚下 = true;

    [Tooltip("开启后，站在移动平台/浮动地面上并发生水平位移时，会在最终水平位移位置再验证一次脚下平台高度。用于修正上下浮动斜坡上水平移动时的贴地高度。")]
    public bool 平台搭乘_水平移动后验证移动平台贴地 = true;

    [Tooltip("平台搭乘验证脚下时，在常规射线长度基础上额外增加的下探距离。")]
    public float 平台搭乘_验证额外射线长度 = 0.25f;

    [Tooltip("平台搭乘验证脚下时，允许把本帧最终Y位移修正的最大距离。防止验证射线误命中过远地面导致瞬移吸附。")]
    public float 平台搭乘_最大验证Y修正距离 = 1.5f;

    [Header("=== 挤压系统 ===")]
    [Tooltip("用于新挤压系统做图层/标签筛选的目标节点。通常拖主碰撞器所在节点。")]
    public GameObject 被推动碰撞器节点;

    [SerializeField] protected LayerMask 新挤压检测图层 = 0;
    [SerializeField] protected float 新挤压头顶条带高度 = 0.08f;
    [SerializeField] protected float 新挤压头顶射线长度 = 1.2f;
    [SerializeField] protected float 新挤压头顶射线间距 = 0.5f;
    [SerializeField] protected bool 新挤压绘制调试 = false;
    [SerializeField, Range(0, 10)] protected int 新挤压推动权重 = 0;
    [SerializeField] protected float 新挤压_附近收集水平额外余量 = 0.5f;
    [SerializeField] protected float 新挤压_附近收集垂直额外余量 = 0.25f;

    protected readonly List<挤压来源候选> 新挤压_头顶候选缓存 = new List<挤压来源候选>(16);
    protected readonly List<挤压来源候选> 新挤压_水平候选缓存 = new List<挤压来源候选>(32);

    [Header("=== 调试 ===")]
    public bool 开启挤压调试日志 = true;

    [SerializeField] public bool 是否在地面 = false;
    [SerializeField] public bool 当前趴下姿态 = false;
    [SerializeField] public bool 当前停顿中 = false;
    [SerializeField] public float 移动意图X = 0f;
    [SerializeField] public float 移动意图Y = 0f;
    [SerializeField] public Vector2 当前速度 = Vector2.zero;

    [SerializeField, Tooltip("运行时只读：本物理帧经过碰撞、斜坡、平台和挤压等全部裁剪后，最终提交给 Rigidbody2D.MovePosition 的位移。可供载具把同一物理帧位移直接提供给搭乘者。")]
    private Vector2 本物理帧最终提交位移_调试 = Vector2.zero;

    public Vector2 本物理帧最终提交位移 => 本物理帧最终提交位移_调试;

    [SerializeField] protected bool 挤压_右侧被墙挡 = false;
    [SerializeField] protected bool 挤压_左侧被墙挡 = false;

    [SerializeField] protected float 调试_当前上距 = -1f;
    [SerializeField] protected float 调试_当前下距 = -1f;
    [SerializeField] protected float 调试_目标上距 = -1f;
    [SerializeField] protected float 调试_目标下距 = -1f;

    protected RaycastHit2D 当前地面碰撞信息 = default;


    [Header("=== 落地排序图层偏移 ===")]
    [SerializeField, Tooltip("开启后，单位落到带有 地面排序图层偏移规则 的地面时，临时偏移自身和子节点 SortingGroup 的排序图层。离地时不恢复，下一次真正落地后再裁决。")]
    protected bool 启用落地排序图层偏移 = true;

    [SerializeField, Tooltip("单位落到带有 地面排序图层偏移规则 的地面时，用它临时偏移自身和子节点 SortingGroup 的排序图层。")]
    protected 落地排序图层偏移器 落地排序图层偏移器;

    [SerializeField, Tooltip("开启后，Awake 时如果本节点没有 落地排序图层偏移器 会自动添加。")]
    protected bool 自动添加落地排序图层偏移器 = true;

    private bool 落地排序_上次在地面 = false;
    private Collider2D 落地排序_上次脚下碰撞器 = null;

    // 移动平台纵向搭乘缓存：
    // 上升平台会先移动 Edge 触发器，随后本单位本帧的向下射线可能从旧脚底打不到已经上移的平台。
    // 因此在物理流程开始时，先用“上一帧脚下地面”读取平台本帧位移，把单位预先带上去，再执行贴地裁决。
    protected Collider2D 平台搭乘_上一帧脚下碰撞体 = null;
    protected bool 平台搭乘_上一帧站在地面 = false;
    protected Collider2D 平台搭乘_Edge位移源缓存碰撞体 = null;
    protected 可搭乘Edge地面位移源 平台搭乘_Edge位移源缓存 = null;
    protected bool 平台搭乘_Edge位移源缓存已查询 = false;
    protected readonly RaycastHit2D[] 平台搭乘_脚下验证命中缓存 = new RaycastHit2D[16];
    protected readonly RaycastHit2D[] 空中向下防穿地扫掠缓存 = new RaycastHit2D[16];
    protected readonly RaycastHit2D[] 二次贴地上方扫掠缓存 = new RaycastHit2D[16];

    protected Vector2 外部平台拖动累计位移 = Vector2.zero;

    protected float 挤压_额外水平位移 = 0f;
    protected float 挤压_额外垂直位移 = 0f;

    protected 挤压标志 新挤压_本帧来源 = null;
    protected bool 新挤压_本帧来自顶部阻挡 = false;
    protected bool 新挤压_本帧来自有效下压 = false;

    protected 挤压标志 新挤压_上帧有效下压来源 = null;
    protected bool 新挤压_上帧存在有效下压 = false;

    protected bool 新挤压_本轮水平候选已收集 = false;
    protected int 夹角阻挡锁定方向 = 0; // 1=向右, -1=向左
    protected 挤压标志 水平推动主动减速_根标志 = null;
    private bool 水平推动主动减速_已查询根标志 = false;

    protected bool 上一帧趴下姿态 = false;

    private 搭乘地面同步提前执行器 子节点搭乘地面同步_提前执行器;
    private bool 子节点搭乘地面同步_上次启用状态 = false;
    private bool 通用物理_已记录执行时间 = false;
    private float 通用物理_上次执行FixedTime = float.NegativeInfinity;
    private bool 通用物理_正在执行物理帧 = false;

    protected virtual void 尝试设置新挤压检测图层默认值()
    {
        int 挤压来源图层 = LayerMask.NameToLayer("挤压来源");
        if (挤压来源图层 < 0)
            return;

        int 挤压来源Mask = 1 << 挤压来源图层;

        // 旧脚本默认是 ~0，会全图层收集；新默认改为只收集“挤压来源”。
        // value=0 通常代表新挂组件/未配置，也给一个安全默认值。
        if (新挤压检测图层.value == 0 || 新挤压检测图层.value == ~0)
            新挤压检测图层 = 挤压来源Mask;
    }

    // ==========================================
    // Unity 生命周期
    // ==========================================
    protected virtual void Reset()
    {
        刚体 = GetComponent<Rigidbody2D>();
        物理碰撞器 = GetComponent<BoxCollider2D>();
        墙壁碰撞器 = GetComponent<与单向墙碰撞>();
        水平推动主动减速_根标志 = GetComponent<挤压标志>();
        水平推动主动减速_已查询根标志 = true;
        尝试设置新挤压检测图层默认值();
    }

    protected virtual void Awake()
    {
        尝试设置新挤压检测图层默认值();

        if (刚体 == null) 刚体 = GetComponent<Rigidbody2D>();
        if (物理碰撞器 == null) 物理碰撞器 = GetComponent<BoxCollider2D>();
        if (墙壁碰撞器 == null) 墙壁碰撞器 = GetComponent<与单向墙碰撞>();
        水平推动主动减速_根标志 = GetComponent<挤压标志>();
        水平推动主动减速_已查询根标志 = true;

        if (被推动碰撞器节点 == null && 物理碰撞器 != null)
            被推动碰撞器节点 = 物理碰撞器.gameObject;

        if (刚体 != null)
        {
            刚体.isKinematic = true;
            刚体.freezeRotation = true;
        }

        刷新碰撞体尺寸(当前趴下姿态);
        上一帧趴下姿态 = 当前趴下姿态;

        确保落地排序图层偏移器();

        初始化后钩子();
        刷新子节点搭乘地面同步运行状态(true);
    }

    protected virtual void FixedUpdate()
    {
        执行通用物理帧一次();
    }

    /// <summary>
    /// 由“搭乘地面同步提前执行器”调用。普通单位不需要调用。
    /// 同一个FixedTime只会执行一次，Unity稍后正常调用本组件FixedUpdate时会自动跳过，避免重复移动。
    /// </summary>
    public void 搭乘地面同步_提前执行物理帧()
    {
        if (!启用子节点搭乘地面同步 || !isActiveAndEnabled)
            return;

        执行通用物理帧一次();
    }

    private void 执行通用物理帧一次()
    {
        float 当前FixedTime = Time.fixedTime;

        if (通用物理_正在执行物理帧)
            return;

        if (通用物理_已记录执行时间 && 通用物理_上次执行FixedTime == 当前FixedTime)
            return;

        通用物理_已记录执行时间 = true;
        通用物理_上次执行FixedTime = 当前FixedTime;
        通用物理_正在执行物理帧 = true;

        try
        {
            刷新子节点搭乘地面同步运行状态(false);

            if (刚体 == null || 物理碰撞器 == null)
            {
                本物理帧最终提交位移_调试 = Vector2.zero;
                提交子节点搭乘地面本帧位移(Vector2.zero);
                return;
            }

            更新临时忽略地面计时();

            if (上一帧趴下姿态 != 当前趴下姿态)
            {
                刷新碰撞体尺寸(当前趴下姿态);
                上一帧趴下姿态 = 当前趴下姿态;
            }

            物理前更新();
            处理移动与物理();
            物理后更新();
            提交子节点搭乘地面本帧位移(本物理帧最终提交位移_调试);
            更新水波特效();

            新挤压_上帧存在有效下压 = 新挤压_本帧来自有效下压 && 新挤压_本帧来源 != null;
            新挤压_上帧有效下压来源 = 新挤压_上帧存在有效下压 ? 新挤压_本帧来源 : null;

            外部平台拖动累计位移 = Vector2.zero;
        }
        finally
        {
            通用物理_正在执行物理帧 = false;
        }
    }

    // ==========================================
    // 地面规则检测
    // ==========================================
    protected virtual 地面检测规则文件 获取脚下地面检测规则()
    {
        if (脚下地面检测规则 != null)
            return 脚下地面检测规则;

        if (!未指定检测规则时使用敌方默认脚下规则)
            return null;

        if (运行时敌方默认脚下规则 == null)
        {
            运行时敌方默认脚下规则 = ScriptableObject.CreateInstance<地面检测规则文件>();
            运行时敌方默认脚下规则.hideFlags = HideFlags.DontSave;

            运行时敌方默认脚下规则.接受我方地面 = true;
            运行时敌方默认脚下规则.接受敌方地面 = true;
            运行时敌方默认脚下规则.接受天花板 = false;
            运行时敌方默认脚下规则.接受水面 = true;

            运行时敌方默认脚下规则.接受我方归属 = true;
            运行时敌方默认脚下规则.接受敌方归属 = true;
            运行时敌方默认脚下规则.接受双方归属 = true;
            运行时敌方默认脚下规则.接受不可站归属 = false;

            运行时敌方默认脚下规则.接受非水面 = true;
            运行时敌方默认脚下规则.接受浅水 = true;
            运行时敌方默认脚下规则.接受深水 = false;

            运行时敌方默认脚下规则.检查可作为脚下地面 = 地面布尔条件.必须为真;
            运行时敌方默认脚下规则.检查阻挡单位向上穿过 = 地面布尔条件.不检查;
            运行时敌方默认脚下规则.检查阻挡子弹飞行 = 地面布尔条件.不检查;
            运行时敌方默认脚下规则.检查阻挡子弹出生安全检测 = 地面布尔条件.不检查;
            运行时敌方默认脚下规则.允许只允许从上方站立 = true;
        }

        return 运行时敌方默认脚下规则;
    }

    // ==========================================
    // 水波特效
    // ==========================================
    protected virtual Vector3 获取实际水波特效位置偏移()
    {
        Vector3 偏移 = 水波特效位置偏移;

        if (!水波特效位置偏移跟随水平翻转)
            return 偏移;

        float 水平缩放 = transform.lossyScale.x;
        if (Mathf.Abs(水平缩放) <= 0.0001f)
            水平缩放 = transform.localScale.x;

        if (水平缩放 < 0f)
            偏移.x = -偏移.x;

        return 偏移;
    }

    protected virtual void 更新水波特效()
    {
        if (!启用水波特效 || 水波大小 == 水波特效大小.不生成)
        {
            if (水波上一帧接触水面 || 当前水波特效 != null)
                立即清理水波特效();

            水波上一帧接触水面 = false;
            return;
        }

        bool 当前接触水面 = 尝试获取当前脚下水波基础位置(out Vector3 当前基础位置);
        Vector3 实际水波特效位置偏移 = 获取实际水波特效位置偏移();

        if (!水波上一帧接触水面 && 当前接触水面)
        {
            水波正在冻结跟随 = false;
            确保有水波特效实例(当前基础位置 + 实际水波特效位置偏移);
            if (当前水波特效 != null)
                当前水波特效.播放进水从头();
        }

        if (水波上一帧接触水面 && !当前接触水面)
        {
            if (当前水波特效 != null)
            {
                水波冻结基础位置 = 水波有最后接触位置 ? 水波最后接触基础位置 : 当前水波特效.transform.position - 实际水波特效位置偏移;
                水波正在冻结跟随 = true;
                当前水波特效.播放出水并结束();
            }
        }

        if (当前接触水面)
        {
            水波最后接触基础位置 = 当前基础位置;
            水波有最后接触位置 = true;
        }

        if (当前水波特效 != null)
        {
            Vector3 目标位置;
            if (水波正在冻结跟随)
                目标位置 = 水波冻结基础位置 + 实际水波特效位置偏移;
            else if (当前接触水面)
                目标位置 = 当前基础位置 + 实际水波特效位置偏移;
            else
                目标位置 = 当前水波特效.transform.position;

            当前水波特效.transform.position = 目标位置;
        }

        水波上一帧接触水面 = 当前接触水面;
    }

    protected virtual bool 尝试获取当前脚下水波基础位置(out Vector3 基础位置)
    {
        基础位置 = transform.position;
        当前水波实际大小 = 水波特效大小.不生成;

        if (!是否在地面)
            return false;

        Collider2D 地面碰撞体 = 当前地面碰撞信息.collider;
        if (地面碰撞体 == null)
            return false;

        if (!地面规则缓存.碰撞器是敌方可站浅水水波地面(地面碰撞体, out 地面规则 规则))
            return false;

        // 本单位永远拥有最终开关权：大型单位可以把 水波大小 设为 不生成，或关闭 启用水波特效。
        if (水波大小 == 水波特效大小.不生成)
            return false;

        当前水波实际大小 = 使用地面规则水波大小 ? 规则.单位站立水波大小 : 水波大小;
        if (当前水波实际大小 == 水波特效大小.不生成)
            return false;

        Vector2 参考位置 = 地面检测点 != null ? (Vector2)地面检测点.position : (Vector2)transform.position;
        Vector2 水面位置 = 计算水波基础位置(地面碰撞体, 参考位置);

        水花特效配置 配置 = 获取水波特效配置();
        if (配置 != null)
            水面位置 += 配置.获取水波生成偏移(当前水波实际大小);

        基础位置 = new Vector3(水面位置.x, 水面位置.y, transform.position.z);
        return true;
    }

    protected virtual Vector2 计算水波基础位置(Collider2D 地面碰撞体, Vector2 参考位置)
    {
        Vector2 水面点 = 参考位置;

        if (地面碰撞体 != null)
        {
            Vector2 p = 地面碰撞体.ClosestPoint(参考位置);
            if (!float.IsNaN(p.x) && !float.IsNaN(p.y) && !float.IsInfinity(p.x) && !float.IsInfinity(p.y))
                水面点 = p;

            if (地面规则缓存.尝试获取(地面碰撞体, out 地面规则 规则))
                水面点.y += 规则.水面特效高度偏移;
        }

        return 水面点;
    }

    protected virtual 水花特效配置 获取水波特效配置()
    {
        if (水波特效配置 != null)
            return 水波特效配置;

        if (默认水波配置缓存 == null && !string.IsNullOrEmpty(默认水波配置Resources路径))
            默认水波配置缓存 = Resources.Load<水花特效配置>(默认水波配置Resources路径);

        水波特效配置 = 默认水波配置缓存;
        return 水波特效配置;
    }

    protected virtual GameObject 获取当前水波预制体()
    {
        水花特效配置 配置 = 获取水波特效配置();
        if (配置 == null)
            return null;

        水波特效大小 大小 = 当前水波实际大小 != 水波特效大小.不生成 ? 当前水波实际大小 : 水波大小;
        if (大小 == 水波特效大小.不生成)
            return null;

        return 配置.获取水波预制体(大小);
    }

    protected virtual 动态层级分组器 获取水波动态层级来源()
    {
        if (水波动态层级来源缓存 == null)
            水波动态层级来源缓存 = GetComponent<动态层级分组器>();

        if (水波动态层级来源缓存 == null)
            水波动态层级来源缓存 = GetComponentInParent<动态层级分组器>();

        return 水波动态层级来源缓存;
    }

    protected virtual void 确保有水波特效实例(Vector3 出生位置)
    {
        if (当前水波特效 != null)
            return;

        GameObject 预制体 = 获取当前水波预制体();
        if (预制体 == null)
            return;

        if (使用水波对象池)
        {
            当前水波特效 = 水波特效对象池.生成(预制体, 出生位置, Quaternion.identity, 水波特效父节点);
        }
        else
        {
            GameObject 实例 = Instantiate(预制体, 出生位置, Quaternion.identity, 水波特效父节点);
            当前水波特效 = 实例 != null ? 实例.GetComponent<水面特效控制器>() : null;
        }

        if (当前水波特效 == null)
            return;

        当前水波特效.绑定动态层级来源(
            获取水波动态层级来源(),
            使用自定义水波动态层级单位ID ? 水波动态层级单位ID : null);

        if (水波特效结束回调 != null)
            当前水波特效.当特效结束 -= 水波特效结束回调;

        水波特效结束回调 = () =>
        {
            当前水波特效 = null;
            水波正在冻结跟随 = false;
            水波有最后接触位置 = false;
            水波特效结束回调 = null;
        };

        当前水波特效.当特效结束 += 水波特效结束回调;
    }

    protected virtual 地面属性 获取水波用地面属性(Collider2D col)
    {
        if (col == null)
            return null;

        // 地面规则要求规则脚本挂在地面 Collider 同节点；地面属性这里只作为水面视觉高度偏移的可选辅助，也只取同节点，避免多个地面 Collider 互相串规则。
        return col.GetComponent<地面属性>();
    }

    protected virtual void 立即清理水波特效()
    {
        水波上一帧接触水面 = false;
        水波正在冻结跟随 = false;
        水波有最后接触位置 = false;
        当前水波实际大小 = 水波特效大小.不生成;

        if (当前水波特效 == null)
            return;

        if (水波特效结束回调 != null)
        {
            当前水波特效.当特效结束 -= 水波特效结束回调;
            水波特效结束回调 = null;
        }

        if (使用水波对象池)
            当前水波特效.回收到对象池();
        else
            Destroy(当前水波特效.gameObject);

        当前水波特效 = null;
    }

    protected virtual void OnDisable()
    {
        本物理帧最终提交位移_调试 = Vector2.zero;
        通用物理_已记录执行时间 = false;
        通用物理_正在执行物理帧 = false;
        清空子节点搭乘地面本帧位移();
        立即清理水波特效();
    }

    protected virtual void OnDestroy()
    {
        立即清理水波特效();
    }

    private void 刷新子节点搭乘地面同步运行状态(bool 强制刷新)
    {
        if (!强制刷新 && 子节点搭乘地面同步_上次启用状态 == 启用子节点搭乘地面同步)
        {
            if (启用子节点搭乘地面同步)
                确保子节点搭乘地面同步提前执行器();
            return;
        }

        子节点搭乘地面同步_上次启用状态 = 启用子节点搭乘地面同步;

        if (启用子节点搭乘地面同步)
        {
            确保子节点搭乘地面同步提前执行器();
            设置列表中搭乘地面位移模式(true);
        }
        else
        {
            设置列表中搭乘地面位移模式(false);
        }
    }

    private void 确保子节点搭乘地面同步提前执行器()
    {
        if (子节点搭乘地面同步_提前执行器 == null)
            子节点搭乘地面同步_提前执行器 = GetComponent<搭乘地面同步提前执行器>();

        if (子节点搭乘地面同步_提前执行器 == null)
            子节点搭乘地面同步_提前执行器 = gameObject.AddComponent<搭乘地面同步提前执行器>();

        子节点搭乘地面同步_提前执行器.绑定(this);
    }

    private void 设置列表中搭乘地面位移模式(bool 使用外部直接提交)
    {
        if (子节点搭乘地面列表 == null)
            return;

        for (int i = 0; i < 子节点搭乘地面列表.Count; i++)
        {
            可搭乘Edge地面位移源 位移源 = 子节点搭乘地面列表[i];
            if (位移源 == null)
                continue;

            位移源.设置外部直接提交模式(使用外部直接提交);
        }
    }

    private void 提交子节点搭乘地面本帧位移(Vector2 最终位移)
    {
        if (!启用子节点搭乘地面同步 || 子节点搭乘地面列表 == null)
            return;

        for (int i = 0; i < 子节点搭乘地面列表.Count; i++)
        {
            可搭乘Edge地面位移源 位移源 = 子节点搭乘地面列表[i];
            if (位移源 == null || !位移源.isActiveAndEnabled)
                continue;

            位移源.提交本物理帧位移(最终位移);
        }
    }

    private void 清空子节点搭乘地面本帧位移()
    {
        if (子节点搭乘地面列表 == null)
            return;

        for (int i = 0; i < 子节点搭乘地面列表.Count; i++)
        {
            可搭乘Edge地面位移源 位移源 = 子节点搭乘地面列表[i];
            if (位移源 != null)
                位移源.清空本帧位移();
        }
    }

    // ==========================================
    // 给外部状态机/AI 调用的公共入口
    // ==========================================
    public virtual void 设置移动意图(float 水平, float 垂直 = 0f)
    {
        移动意图X = Mathf.Clamp(水平, -1f, 1f);
        移动意图Y = Mathf.Clamp(垂直, -1f, 1f);
    }

    public virtual void 设置停顿状态(bool 停顿)
    {
        当前停顿中 = 停顿;
    }

    public virtual void 设置趴下状态(bool 趴下)
    {
        当前趴下姿态 = 趴下;
    }

    public virtual void 清空移动意图()
    {
        移动意图X = 0f;
        移动意图Y = 0f;
    }

    public virtual void 设置垂直速度(float 速度)
    {
        当前速度.y = 速度;
    }

    public virtual void 设置水平速度(float 速度)
    {
        当前速度.x = 速度;
    }

    public virtual void 添加瞬时速度(Vector2 增量)
    {
        当前速度 += 增量;
    }

    /// <summary>
    /// 获取当前对外可继承的惯性速度。
    /// 当前速度.x 主要表示死亡/弹飞等外部速度；普通主动水平移动还需要叠加 移动意图X * 当前水平移动速度。
    /// 子类如果有特殊移动速度，覆写 获取当前水平移动速度 后这里会自动使用子类速度。
    /// </summary>
    public virtual Vector2 获取当前惯性速度()
    {
        Vector2 速度 = 当前速度;

        if (!死亡冻结全部移动 && 启用主动水平移动 && !当前停顿中)
            速度.x += 移动意图X * 获取当前水平移动速度();

        return 速度;
    }

    /// <summary>
    /// 给死亡表现/特殊外力调用：直接设置本单位的外部速度。
    /// X 会作为额外水平速度参与位移；Y 会继续受重力影响。
    /// </summary>
    public virtual void 设置死亡外部速度(Vector2 速度, bool 是否清空移动意图 = true, bool 解除停顿 = true, bool 强制离地 = false)
    {
        死亡冻结全部移动 = false;
        启用死亡外部速度 = true;
        当前速度 = 速度;

        if (是否清空移动意图)
            清空移动意图();

        if (解除停顿)
            设置停顿状态(false);

        if (强制离地)
            立即离地();
    }

    public virtual void 设置死亡水平速度(float 速度, bool 启用外部速度 = true)
    {
        死亡冻结全部移动 = false;

        if (启用外部速度)
            启用死亡外部速度 = true;

        当前速度.x = 速度;
        移动意图X = 0f;
    }

    public virtual void 停止死亡水平移动()
    {
        当前速度.x = 0f;
        移动意图X = 0f;
    }

    public virtual void 停止死亡垂直移动()
    {
        当前速度.y = 0f;
        移动意图Y = 0f;
    }

    public virtual void 停止死亡全部移动()
    {
        当前速度 = Vector2.zero;
        移动意图X = 0f;
        移动意图Y = 0f;
        启用死亡外部速度 = false;
        死亡冻结全部移动 = true;
    }

    public virtual void 设置临时忽略地面图层(LayerMask 忽略图层, float 持续时间)
    {
        // 旧版兼容入口：没有规则文件的旧调用才会走图层忽略。
        // 新逻辑请使用 设置临时忽略地面检测规则 / 开始忽略地面检测规则。
        临时忽略地面检测规则 = null;
        临时忽略地面图层 = 忽略图层;
        临时忽略地面剩余时间 = 持续时间;
        临时忽略地面启用 = 忽略图层.value != 0 && !Mathf.Approximately(持续时间, 0f);

        if (临时忽略地面启用)
            立即离地();
    }

    public virtual void 开始忽略地面图层(LayerMask 忽略图层, float 持续时间 = -1f)
    {
        设置临时忽略地面图层(忽略图层, 持续时间);
    }

    public virtual void 设置临时忽略地面检测规则(地面检测规则文件 检测规则, float 持续时间)
    {
        临时忽略地面检测规则 = 检测规则;
        临时忽略地面图层 = new LayerMask();
        临时忽略地面剩余时间 = 持续时间;
        临时忽略地面启用 = 检测规则 != null && !Mathf.Approximately(持续时间, 0f);

        if (临时忽略地面启用)
            立即离地();
    }

    public virtual void 开始忽略地面检测规则(地面检测规则文件 检测规则, float 持续时间 = -1f)
    {
        设置临时忽略地面检测规则(检测规则, 持续时间);
    }

    public virtual void 停止忽略地面图层()
    {
        停止临时忽略地面();
    }

    public virtual void 停止忽略地面检测规则()
    {
        停止临时忽略地面();
    }

    protected virtual void 停止临时忽略地面()
    {
        临时忽略地面启用 = false;
        临时忽略地面剩余时间 = 0f;
        临时忽略地面图层 = new LayerMask();
        临时忽略地面检测规则 = null;
    }

    protected virtual void 更新临时忽略地面计时()
    {
        if (!临时忽略地面启用)
            return;

        // 负数表示一直忽略，直到外部手动停止。
        if (临时忽略地面剩余时间 < 0f)
            return;

        临时忽略地面剩余时间 -= Time.fixedDeltaTime;

        if (临时忽略地面剩余时间 <= 0f)
            停止临时忽略地面();
    }

    protected virtual 地面检测规则文件 获取临时忽略地面检测规则()
    {
        if (!临时忽略地面启用)
            return null;

        return 临时忽略地面检测规则;
    }

    protected virtual LayerMask 获取当前有效地面图层()
    {
        // 新版规则忽略不能从LayerMask里整层剔除，否则同层实心地面也会被误跳过。
        // 这里保留完整候选图层，具体跳过哪个Collider交给 地面规则 + 地面检测规则文件。
        if (临时忽略地面启用 && 临时忽略地面检测规则 != null)
            return 地面图层;

        // 旧版兼容：没有规则文件时才允许按图层剔除。
        if (!临时忽略地面启用 || 临时忽略地面图层.value == 0)
            return 地面图层;

        LayerMask 有效图层 = new LayerMask();
        有效图层.value = 地面图层.value & ~临时忽略地面图层.value;
        return 有效图层;
    }

    public virtual void 立即落地()
    {
        当前速度.y = 0f;
        是否在地面 = true;
    }

    public virtual void 立即离地()
    {
        是否在地面 = false;
        当前地面碰撞信息 = default;
        平台搭乘_上一帧脚下碰撞体 = null;
        平台搭乘_上一帧站在地面 = false;
        平台搭乘_清理Edge位移源缓存();
    }

    public virtual void 刷新碰撞体尺寸(bool 是趴下姿态)
    {
        // 旧主碰撞器字段：默认继续保留，保证已有单位不需要改配置。
        // 新单位如果需要按动画状态同步碰撞器尺寸，可以关闭此开关，避免和动画同步器互相覆盖。
        if (启用主物理碰撞器姿态尺寸同步)
        {
            刷新单个碰撞体尺寸(
                物理碰撞器,
                站立碰撞器尺寸,
                站立碰撞器中心,
                趴下碰撞器尺寸,
                趴下碰撞器中心,
                是趴下姿态
            );
        }

        // 新多碰撞器配置：用于身体碰撞框、被击框、头/脚等多个部位分别调尺寸。
        // 默认继续开启以兼容旧单位；关闭后列表里的碰撞器可交给动画姿态碰撞同步器控制。
        if (!启用姿态碰撞器列表尺寸同步)
            return;

        if (姿态碰撞器列表 == null)
            return;

        for (int i = 0; i < 姿态碰撞器列表.Count; i++)
        {
            姿态碰撞器配置 配置 = 姿态碰撞器列表[i];
            if (配置 == null || !配置.启用)
                continue;

            刷新单个碰撞体尺寸(
                配置.碰撞器,
                配置.站立尺寸,
                配置.站立中心,
                配置.趴下尺寸,
                配置.趴下中心,
                是趴下姿态
            );
        }
    }

    protected virtual void 刷新单个碰撞体尺寸(
        BoxCollider2D 碰撞器,
        Vector2 站立尺寸,
        Vector2 站立中心,
        Vector2 趴下尺寸,
        Vector2 趴下中心,
        bool 是趴下姿态
    )
    {
        if (碰撞器 == null)
            return;

        if (是趴下姿态)
        {
            碰撞器.size = 趴下尺寸;
            碰撞器.offset = 趴下中心;
        }
        else
        {
            碰撞器.size = 站立尺寸;
            碰撞器.offset = 站立中心;
        }
    }

    // ==========================================
    // 可给子类覆写的钩子
    // ==========================================
    protected virtual void 初始化后钩子() { }
    protected virtual void 物理前更新() { }
    protected virtual void 物理后更新() { }

    protected virtual void 确保落地排序图层偏移器()
    {
        if (落地排序图层偏移器 == null)
            落地排序图层偏移器 = GetComponent<落地排序图层偏移器>();

        if (落地排序图层偏移器 == null && 自动添加落地排序图层偏移器)
            落地排序图层偏移器 = gameObject.AddComponent<落地排序图层偏移器>();
    }

    protected virtual void 刷新落地排序图层偏移状态(Collider2D 本帧脚下碰撞器)
    {
        if (!启用落地排序图层偏移)
            return;

        确保落地排序图层偏移器();

        if (落地排序图层偏移器 == null)
            return;

        bool 本帧在地面 = 是否在地面 && 本帧脚下碰撞器 != null;

        // 大量敌人共用本基类时，避免每个 FixedUpdate 对同一个脚下地面重复刷新。
        if (本帧在地面 == 落地排序_上次在地面 && 本帧脚下碰撞器 == 落地排序_上次脚下碰撞器)
            return;

        落地排序_上次在地面 = 本帧在地面;
        落地排序_上次脚下碰撞器 = 本帧脚下碰撞器;

        落地排序图层偏移器.根据脚下地面刷新(本帧在地面, 本帧脚下碰撞器);
    }

    /// <summary>
    /// 默认：任何来源都允许推动。
    /// 子类可以覆写做特殊过滤。
    /// </summary>
    protected virtual bool 新挤压_允许被该来源推动(挤压标志 标志)
    {
        return 标志 != null;
    }

    /// <summary>
    /// 子类覆写：被挤死后的实际处理。
    /// 例如：玩家死亡、敌人切死亡状态、坐骑自爆。
    /// </summary>
    protected virtual void 处理被挤压死亡(Vector2 挤压方向, Component 来源)
    {
    }

    protected void 打印挤压致死日志(string 类型, Vector2 挤压方向, Component 来源)
    {
        if (!开启挤压调试日志) return;

        string 来源名 = 来源 != null ? 来源.name : "空";
        string 来源类型 = 来源 != null ? 来源.GetType().Name : "空";

        Debug.Log(
            $"[挤压判定-{类型}] 单位:{name} 方向:{挤压方向} 来源:{来源名} 来源脚本:{来源类型} 位置:{transform.position}",
            this
        );
    }

    /// <summary>
    /// 子类覆写：是否允许空中单位主动垂直输入时仍保留旧Y速度。
    /// 默认 false：直接由主动垂直输入控制 Y。
    /// </summary>
    protected virtual bool 主动垂直输入时保留旧Y速度 => false;

    protected virtual float 获取当前水平移动速度()
    {
        float 基础速度;

        if (!启用地面吸附)
            基础速度 = 空中水平移动速度;
        else
            基础速度 = 当前趴下姿态 ? 趴下水平移动速度 : 地面水平移动速度;

        return 套用速度倍率(基础速度);
    }

    /// <summary>
    /// 本帧调用“与单向墙碰撞.计算安全水平移动”时使用的预测Y偏移。
    /// 默认返回原本使用的最终Y移动量，因此未重写此方法的单位行为完全不变。
    /// 特殊载具可在爬障碍时重写，临时把整组水平射线抬到障碍顶面上方。
    /// </summary>
    protected virtual float 获取水平墙检测预测Y偏移(float 最终Y移动量)
    {
        return 最终Y移动量;
    }

    protected virtual void 平台搭乘_清理Edge位移源缓存()
    {
        平台搭乘_Edge位移源缓存碰撞体 = null;
        平台搭乘_Edge位移源缓存 = null;
        平台搭乘_Edge位移源缓存已查询 = false;
    }

    protected virtual 可搭乘Edge地面位移源 平台搭乘_获取Edge位移源(Collider2D 脚下碰撞体)
    {
        if (脚下碰撞体 == null)
            return null;

        if (平台搭乘_Edge位移源缓存碰撞体 != 脚下碰撞体 || !平台搭乘_Edge位移源缓存已查询)
        {
            平台搭乘_Edge位移源缓存碰撞体 = 脚下碰撞体;
            平台搭乘_Edge位移源缓存 = 脚下碰撞体.GetComponentInParent<可搭乘Edge地面位移源>();
            平台搭乘_Edge位移源缓存已查询 = true;
        }

        if (平台搭乘_Edge位移源缓存 != null
            && 平台搭乘_Edge位移源缓存.enabled
            && 平台搭乘_Edge位移源缓存.是否可搭乘碰撞器(脚下碰撞体))
            return 平台搭乘_Edge位移源缓存;

        return null;
    }

    protected virtual bool 平台搭乘_启用边缘验证兜底 => false;

    protected virtual bool 平台搭乘_脚下碰撞体允许锁定(Collider2D 脚下碰撞体)
    {
        var edge位移源 = 平台搭乘_获取Edge位移源(脚下碰撞体);
        return edge位移源 != null && edge位移源.启用脚下平台锁定;
    }

    protected virtual bool 平台搭乘_尝试获取脚下平台位移(Collider2D 脚下碰撞体, out Vector2 平台位移)
    {
        var edge位移源 = 平台搭乘_获取Edge位移源(脚下碰撞体);
        return 平台位移解析工具.尝试获取脚下平台位移(脚下碰撞体, edge位移源, out 平台位移);
    }

    protected virtual bool 平台搭乘_验证指定平台仍在脚下(
        Collider2D 目标平台,
        Transform 实际射线起点,
        Transform 实际地面检测点,
        float 预测x偏移,
        float 预测y偏移,
        out RaycastHit2D 平台命中,
        out float 验证后y移动量)
    {
        平台命中 = default;
        验证后y移动量 = 预测y偏移;

        if (!启用平台搭乘 || !启用地面吸附 || 目标平台 == null)
            return false;

        if (!目标平台.enabled || !目标平台.gameObject.activeInHierarchy)
            return false;

        if (实际射线起点 == null)
            实际射线起点 = transform;

        float 脚底基准Y = 实际地面检测点 != null
            ? 实际地面检测点.position.y
            : (物理碰撞器 != null ? 物理碰撞器.bounds.min.y : transform.position.y);

        float 射线起点相对脚底上抬 = 实际射线起点.position.y - 脚底基准Y;
        float 预测射线起点Y = 脚底基准Y + 预测y偏移 + 射线起点相对脚底上抬;

        float 验证射线长度 = Mathf.Max(射线长度, 射线长度 * Mathf.Max(1f, 地面射线检测长度));
        验证射线长度 += Mathf.Abs(预测y偏移) + Mathf.Max(0f, 平台搭乘_验证额外射线长度);
        验证射线长度 = Mathf.Max(0.05f, 验证射线长度);

        int 检测图层 = 获取当前有效地面图层().value;
        if (检测图层 == 0)
            return false;

        bool 有命中 = false;
        RaycastHit2D 最佳命中 = default;

        Vector2 中心起点 = new Vector2(实际射线起点.position.x + 预测x偏移, 预测射线起点Y);
        平台搭乘_尝试验证平台射线(中心起点, 验证射线长度, 检测图层, 目标平台, ref 有命中, ref 最佳命中);

        if (平台搭乘_启用边缘验证兜底 && 物理碰撞器 != null && 物理碰撞器.enabled && 物理碰撞器.gameObject.activeInHierarchy)
        {
            Bounds b = 物理碰撞器.bounds;
            float inset = Mathf.Min(0.05f, b.size.x * 0.1f);
            Vector2 左起点 = new Vector2(b.min.x + inset + 预测x偏移, 预测射线起点Y);
            Vector2 右起点 = new Vector2(b.max.x - inset + 预测x偏移, 预测射线起点Y);

            平台搭乘_尝试验证平台射线(左起点, 验证射线长度, 检测图层, 目标平台, ref 有命中, ref 最佳命中);
            平台搭乘_尝试验证平台射线(右起点, 验证射线长度, 检测图层, 目标平台, ref 有命中, ref 最佳命中);
        }

        bool 使用脚底基准验证 = false;


        if (!有命中)
        {
            // 保护基准兜底：
            // 普通贴地可能已经把 当前y移动量 拉到较低的场景普通地面。
            // 如果继续用这个错误Y作为锁定验证基准，上一帧锁定的高处废墟Edge会验证失败。
            // 这里回到“当前脚底原始高度”再验证同一个Collider，只影响上一帧已锁定平台，不提高其它废墟地面优先级。
            float 脚底基准射线起点Y = 脚底基准Y + 射线起点相对脚底上抬;
            bool 脚底基准有命中 = false;
            RaycastHit2D 脚底基准最佳命中 = default;
            Vector2 脚底基准中心起点 = new Vector2(实际射线起点.position.x + 预测x偏移, 脚底基准射线起点Y);

            平台搭乘_尝试验证平台射线(脚底基准中心起点, 验证射线长度, 检测图层, 目标平台, ref 脚底基准有命中, ref 脚底基准最佳命中);


            if (脚底基准有命中)
            {
                有命中 = true;
                最佳命中 = 脚底基准最佳命中;
                使用脚底基准验证 = true;
            }
        }

        if (!有命中)
            return false;

        float 候选y移动量 = (最佳命中.point.y + 地面缓冲距离) - 脚底基准Y;
        float 最大修正 = Mathf.Max(0f, 平台搭乘_最大验证Y修正距离);
        float 验证参考y移动量 = 使用脚底基准验证 ? 0f : 预测y偏移;
        if (最大修正 > 0f && Mathf.Abs(候选y移动量 - 验证参考y移动量) > 最大修正)
            return false;

        平台命中 = 最佳命中;
        验证后y移动量 = 候选y移动量;
        return true;
    }

    protected virtual void 平台搭乘_尝试验证平台射线(
        Vector2 起点,
        float 距离,
        int 检测图层,
        Collider2D 目标平台,
        ref bool 有命中,
        ref RaycastHit2D 最佳命中)
    {
        int 命中数 = Physics2D.RaycastNonAlloc(
            起点,
            Vector2.down,
            平台搭乘_脚下验证命中缓存,
            距离,
            检测图层
        );

        for (int i = 0; i < 命中数; i++)
        {
            RaycastHit2D hit = 平台搭乘_脚下验证命中缓存[i];
            if (hit.collider == null || hit.collider != 目标平台)
                continue;

            if (hit.normal.y <= 0.02f)
                continue;

            if (!有命中 || hit.point.y > 最佳命中.point.y)
            {
                有命中 = true;
                最佳命中 = hit;
            }
        }
    }
    protected virtual void 平台搭乘_最终保护上一帧锁定平台(ref RaycastHit2D 当前地面命中, ref float 当前y移动量)
    {
        if (!启用平台搭乘 || !启用地面吸附 || !是否在地面)
            return;

        if (!平台搭乘_上一帧站在地面 || 平台搭乘_上一帧脚下碰撞体 == null)
            return;

        if (当前地面命中.collider == null || 当前地面命中.collider == 平台搭乘_上一帧脚下碰撞体)
            return;

        if (!平台搭乘_脚下碰撞体允许锁定(平台搭乘_上一帧脚下碰撞体))
            return;

        if (!平台搭乘_验证指定平台仍在脚下(
            平台搭乘_上一帧脚下碰撞体,
            射线起点 != null ? 射线起点 : transform,
            地面检测点 != null ? 地面检测点 : transform,
            0f,
            当前y移动量,
            out RaycastHit2D 锁定平台命中,
            out float 锁定平台y移动量))
            return;

        当前地面命中 = 锁定平台命中;
        当前y移动量 = 锁定平台y移动量;
        是否在地面 = true;

        if (物理碰撞器 != null)
            斜坡吸附助手.同步地面吸附记忆(物理碰撞器, 锁定平台命中);
    }

    // ==========================================
    // 物理主流程
    // ==========================================
    protected virtual void 处理移动与物理()
    {
        // 每个物理帧先清零，所有提前 return 的分支都会向外暴露零位移，避免沿用上一帧结果。
        本物理帧最终提交位移_调试 = Vector2.zero;

        float dt = Time.fixedDeltaTime;
        const float EPS = 1e-4f;

        新挤压_本帧来源 = null;
        新挤压_本帧来自顶部阻挡 = false;
        新挤压_本帧来自有效下压 = false;

        新挤压_重置本轮水平候选缓存();

        if (死亡冻结全部移动)
        {
            当前速度 = Vector2.zero;
            外部平台拖动累计位移 = Vector2.zero;
            挤压_额外水平位移 = 0f;
            挤压_额外垂直位移 = 0f;
            平台搭乘_上一帧脚下碰撞体 = null;
            平台搭乘_上一帧站在地面 = false;
            平台搭乘_清理Edge位移源缓存();
            return;
        }

        // 先缓存上一帧脚下平台位移。
        // 这一步必须发生在贴地/斜坡吸附之前：平台向上移动时，如果单位不先被托起，
        // 本帧向下射线可能打不到已经上移到脚底上方的 Edge 触发器，从而误判离地。
        Vector2 脚下平台位移 = Vector2.zero;
        bool 本帧取得脚下平台位移 = false;
        bool 本帧使用上一帧平台缓存 = false;
        bool 本帧上一帧平台允许锁定 = false;

        if (启用平台搭乘 && 平台搭乘_上一帧站在地面 && 平台搭乘_上一帧脚下碰撞体 != null)
        {
            本帧上一帧平台允许锁定 = 平台搭乘_脚下碰撞体允许锁定(平台搭乘_上一帧脚下碰撞体);

            // 只有平台本身允许“脚下平台锁定”时，才允许使用上一帧脚下平台做预带动。
            // 否则关闭 可搭乘Edge地面位移源.启用脚下平台锁定 后，必须回到旧流程：
            // 本帧贴地成功后，再读取当前脚下平台位移。
            if (本帧上一帧平台允许锁定)
            {
                本帧取得脚下平台位移 = 平台搭乘_尝试获取脚下平台位移(平台搭乘_上一帧脚下碰撞体, out 脚下平台位移);
                本帧使用上一帧平台缓存 = true;
            }
        }

        // ------------------------------
        // 1. 垂直速度更新
        // ------------------------------
        if (启用主动垂直移动)
        {
            float 目标垂直速度 = 当前停顿中 ? 0f : 移动意图Y * 套用速度倍率(主动垂直移动速度);

            if (主动垂直输入时保留旧Y速度)
            {
                当前速度.y += 目标垂直速度 * dt;
            }
            else
            {
                当前速度.y = 目标垂直速度;
            }
        }
        else
        {
            if (启用重力 && !是否在地面)
                当前速度.y -= 套用速度倍率(重力) * dt;

            当前速度.y = Mathf.Max(当前速度.y, -套用速度倍率(最大下落速度));
        }

        float 理想y移动量 = 当前速度.y * dt + 挤压_额外垂直位移;
        if (平台拖动直接叠加到位移)
            理想y移动量 += 外部平台拖动累计位移.y;

        // 脚下平台锁定/稳定搭乘：上一帧已经站在启用锁定的Edge地面上时，先继承它本帧Y位移，
        // 再执行贴地裁决。这样电梯抖动/水船下沉时，单位不会先被判空中再吸到其它地面。
        // 注意：必须同时要求 本帧上一帧平台允许锁定；否则关闭平台锁定开关后仍会提前吃Y位移。
        if (本帧上一帧平台允许锁定 && 本帧取得脚下平台位移 && Mathf.Abs(脚下平台位移.y) > EPS)
            理想y移动量 += 脚下平台位移.y;

        挤压_额外垂直位移 = 0f;

        // ------------------------------
        // 2. 头顶阻挡 / 下压锁定
        // ------------------------------
        if (启用挤压 && 启用顶部阻挡解析)
        {
            if (新挤压_解析头顶纵向约束(
                理想y移动量,
                out float 修正后Dy,
                out 新挤压_本帧来源,
                out 新挤压_本帧来自顶部阻挡,
                out 新挤压_本帧来自有效下压))
            {
                if (修正后Dy < 理想y移动量 - EPS && 当前速度.y > 0f)
                    当前速度.y = 0f;

                理想y移动量 = 修正后Dy;
            }
        }

        // ------------------------------
        // 3. 单向墙/世界线段：垂直安全移动
        // ------------------------------
        bool isStandingOnPlatform = false;
        float 安全y移动量 = 理想y移动量;

        地面检测规则文件 当前脚下检测规则 = 获取脚下地面检测规则();
        地面检测规则文件 当前临时忽略检测规则 = 获取临时忽略地面检测规则();

        if (启用与单向墙碰撞 && 墙壁碰撞器 != null)
        {
            // 新版：单向世界2D 的线段裁剪也必须按 地面检测规则文件 过滤/忽略。
            // 旧图层忽略只作为没有规则文件时的兼容兜底，避免同Layer实心地面被一起穿透。
            LayerMask 垂直扫掠忽略图层 = default;
            if (当前临时忽略检测规则 == null && 临时忽略地面启用 && 临时忽略地面图层.value != 0)
                垂直扫掠忽略图层 = 临时忽略地面图层;

            安全y移动量 = 墙壁碰撞器.计算安全垂直移动(
                理想y移动量,
                皮肤宽度,
                out isStandingOnPlatform,
                垂直扫掠忽略图层,
                当前临时忽略检测规则,
                当前脚下检测规则
            );
        }

        if (安全y移动量 < 理想y移动量 - EPS && 当前速度.y > 0f)
            当前速度.y = 0f;

        // 只有上一帧已经在地面时，垂直安全检测得到的“平台接触”才允许作为贴地保持依据。
        // 空中后跳/跳刀/下落时，不能让 isStandingOnPlatform 绕过斜坡吸附助手的空中落地穿越判断；
        // 否则身体中段或下方其它地面会被误判成脚下保持地面，可能从废墟地面跳到下方场景地面。
        bool 贴地裁决使用平台保持 = 是否在地面 && isStandingOnPlatform;

        // ------------------------------
        // 4. 贴地 / 斜坡吸附
        // ------------------------------
        float 最终y移动量 = 安全y移动量;
        当前地面碰撞信息 = default;

        Transform 实际射线起点 = 射线起点 != null ? 射线起点 : transform;
        Transform 实际地面检测点 = 地面检测点 != null ? 地面检测点 : transform;

        if (启用地面吸附)
        {
            if (启用斜坡吸附)
            {
                float 动态射线长度 = 当前速度.y < 0f ? 射线长度 + Mathf.Abs(理想y移动量) : 射线长度;

                是否在地面 = 斜坡吸附助手.贴地裁决(
                    实际射线起点,
                    实际地面检测点,
                    获取当前有效地面图层(),
                    动态射线长度,
                    地面射线检测长度,
                    地面缓冲距离,
                    当前速度.y,
                    是否在地面,
                    贴地裁决使用平台保持,
                    物理碰撞器,
                    安全y移动量,
                    out 最终y移动量,
                    out 当前地面碰撞信息,
                    当前脚下检测规则,
                    当前临时忽略检测规则
                );
            }
            else
            {
                是否在地面 = isStandingOnPlatform && 当前速度.y <= 0.01f;
                最终y移动量 = 安全y移动量;
            }

            if (理想y移动量 > 0f)
            {
                if (最终y移动量 > 安全y移动量) 最终y移动量 = 安全y移动量;
                if (当前速度.y > 0.001f) 是否在地面 = false;
            }

            if (是否在地面 && 当前速度.y < 0f)
                当前速度.y = 0f;
        }
        else
        {
            是否在地面 = false;
            最终y移动量 = 安全y移动量;
        }

        // 脚下平台锁定：
        // 对显式开启“脚下平台锁定”的 Edge 位移源，上一帧站在它上面时，本帧优先验证同一个平台。
        // 验证成功后，即使普通贴地裁决先命中场景地面，也会保持上一帧平台，避免电梯抖动/水船下沉时被其它地面抢走。
        if (本帧上一帧平台允许锁定
            && 本帧使用上一帧平台缓存
            && 平台搭乘_上一帧脚下碰撞体 != null
            && (!是否在地面 || 当前地面碰撞信息.collider != 平台搭乘_上一帧脚下碰撞体))
        {
            RaycastHit2D 锁定平台验证命中;
            float 锁定平台验证y移动量;
            bool 锁定平台验证通过 = 平台搭乘_验证指定平台仍在脚下(
                平台搭乘_上一帧脚下碰撞体,
                实际射线起点,
                实际地面检测点,
                0f,
                安全y移动量,
                out 锁定平台验证命中,
                out 锁定平台验证y移动量
            );

            if (锁定平台验证通过)
            {
                是否在地面 = true;
                当前地面碰撞信息 = 锁定平台验证命中;
                最终y移动量 = 锁定平台验证y移动量;

                if (当前速度.y < 0f)
                    当前速度.y = 0f;
            }
        }

        // 上升平台保护：
        // 旧逻辑只要上一帧平台向上移动且本帧贴地失败，就直接保持“在地面”。
        // 这样在上下浮动的斜坡/船面上会把贴地失败误当成仍站立，导致单位保持旧高度水平滑行。
        // 新逻辑保留平台预托举，但必须用预测脚底位置重新验证上一帧平台仍在脚下；验证失败就真正离地。
        if (!是否在地面
            && 本帧使用上一帧平台缓存
            && 脚下平台位移.y > EPS
            && 平台搭乘_上一帧脚下碰撞体 != null)
        {
            bool 验证通过 = !平台搭乘_丢失命中时必须验证脚下;
            RaycastHit2D 平台验证命中 = default;
            float 平台验证y移动量 = 最终y移动量;

            if (!验证通过)
            {
                验证通过 = 平台搭乘_验证指定平台仍在脚下(
                    平台搭乘_上一帧脚下碰撞体,
                    实际射线起点,
                    实际地面检测点,
                    0f,
                    最终y移动量,
                    out 平台验证命中,
                    out 平台验证y移动量
                );
            }

            if (验证通过)
            {
                是否在地面 = true;
                if (平台验证命中.collider != null)
                {
                    当前地面碰撞信息 = 平台验证命中;
                    最终y移动量 = 平台验证y移动量;
                }

                if (当前速度.y < 0f)
                    当前速度.y = 0f;
            }
        }

        // 下压致死：来源连续两帧有效下压，且我已经压到地面/落脚面
        if (启用挤压 && 启用下压致死判定 &&
    新挤压_本帧来自有效下压 &&
    新挤压_本帧来源 != null &&
    新挤压_上帧存在有效下压 &&
    新挤压_上帧有效下压来源 == 新挤压_本帧来源 &&
    新挤压_本帧来源.压到落脚面致死 &&
    挤压_当前是否在地面())
        {
            Component 来源 = 新挤压_本帧来源.获取兼容旧挤压体来源();
            打印挤压致死日志("下压压死", Vector2.down, 来源);
            挤压_被挤压死亡(Vector2.down, 来源);
            return;
        }

        // ------------------------------
        // 5. 水平主动位移
        // ------------------------------
        float 原始主动位移 = 0f;
        if (!死亡冻结全部移动 && 启用主动水平移动 && !当前停顿中)
            原始主动位移 = 移动意图X * 获取当前水平移动速度() * dt;

        float 主动位移 = 原始主动位移;
        float 死亡外部水平位移 = (!死亡冻结全部移动 && 启用死亡外部速度) ? 当前速度.x * dt : 0f;

        // 如果不是从上一帧平台缓存取得，则在本帧贴地裁决完成后再尝试读取脚下平台位移，
        // 供水平移动和普通下降平台使用。
        if (!本帧取得脚下平台位移 && 启用平台搭乘 && 是否在地面 && 当前地面碰撞信息.collider != null)
        {
            本帧取得脚下平台位移 = 平台搭乘_尝试获取脚下平台位移(当前地面碰撞信息.collider, out 脚下平台位移);
        }

        // 推动减速只作用于“原始主动位移”。
        // 预测来源位移仍包含平台/外力等真实会带动挤压标志的部分，用于判断是否正在形成水平推动。
        float 推动判断来源水平位移 = 原始主动位移 + 死亡外部水平位移 + 挤压_额外水平位移;
        if (平台拖动直接叠加到位移)
            推动判断来源水平位移 += 外部平台拖动累计位移.x;
        if (启用平台搭乘)
            推动判断来源水平位移 += 脚下平台位移.x;

        当前水平推动主动速度倍率 = 获取水平推动主动速度倍率(原始主动位移, 推动判断来源水平位移);
        主动位移 = 原始主动位移 * 当前水平推动主动速度倍率;

        float 自主总x移动量 = 主动位移 + 死亡外部水平位移 + 挤压_额外水平位移;
        if (平台拖动直接叠加到位移)
            自主总x移动量 += 外部平台拖动累计位移.x;
        if (启用平台搭乘)
            自主总x移动量 += 脚下平台位移.x;

        挤压_额外水平位移 = 0f;

        float 自主x移动量_实体后 = 自主总x移动量;

        if (启用挤压)
            自主x移动量_实体后 = 新挤压_约束水平主动移动(自主总x移动量);

        挤压标志 本帧水平推动来源 = null;
        float 本帧水平推动位移 = 0f;

        if (启用挤压 && 启用水平推动)
            新挤压_尝试获取被动推动(out 本帧水平推动来源, out 本帧水平推动位移);

        float 合并后尝试x移动量 = 自主x移动量_实体后 + 本帧水平推动位移;

        // ------------------------------
        // 6. 单向墙/世界线段：水平安全移动
        // ------------------------------
        float 安全x移动量 = 合并后尝试x移动量;

        if (启用与单向墙碰撞 && 墙壁碰撞器 != null)
        {
            float 水平墙检测预测Y偏移 =
                获取水平墙检测预测Y偏移(最终y移动量);

            安全x移动量 = 墙壁碰撞器.计算安全水平移动(
                合并后尝试x移动量,
                皮肤宽度,
                水平墙检测预测Y偏移,
                // 平台限定墙只按本单位自身的主动/外部水平意图判定方向，
                // 不让脚下平台位移把相对移动抵消成0。
                主动位移 + 死亡外部水平位移);
        }

        // ------------------------------
        // 7. 夹角阻挡
        // ------------------------------
        if (启用夹角阻挡)
        {
            int 当前尝试方向 = 0;
            if (合并后尝试x移动量 > 0.0001f) 当前尝试方向 = 1;
            else if (合并后尝试x移动量 < -0.0001f) 当前尝试方向 = -1;

            if (当前尝试方向 != 0 && 夹角阻挡锁定方向 != 0 && 当前尝试方向 != 夹角阻挡锁定方向)
            {
                夹角阻挡锁定方向 = 0;
            }

            bool 允许进行夹角阻挡判定 =
                (右侧夹角探测点 != null || 左侧夹角探测点 != null) &&
                夹角向上检测图层.value != 0 &&
                夹角向下检测图层.value != 0;

            if (允许进行夹角阻挡判定)
            {
                Transform 当前前向探测点 = 夹角阻挡助手.按位移方向获取前向探测点(
                    合并后尝试x移动量,
                    右侧夹角探测点,
                    左侧夹角探测点
                );

                bool 应阻挡 = 夹角阻挡助手.应该阻挡朝前移动(
                    当前前向探测点,
                    new Vector2(合并后尝试x移动量, 最终y移动量),
                    夹角向上检测图层,
                    夹角向下检测图层,
                    夹角向上射线长度,
                    夹角向下射线长度,
                    斜坡最小角度,
                    夹角最大允许上方距离,
                    transform.root,
                    绘制夹角探测射线,
                    out 调试_当前上距,
                    out 调试_当前下距,
                    out 调试_目标上距,
                    out 调试_目标下距
                );

                if (!应阻挡 && 当前尝试方向 != 0 && 夹角阻挡锁定方向 == 当前尝试方向)
                {
                    bool 仍在夹角里 = 夹角阻挡助手.前向探测点仍处于上斜坡夹角内(
                        当前前向探测点,
                        合并后尝试x移动量,
                        夹角向上检测图层,
                        夹角向下检测图层,
                        夹角向上射线长度,
                        夹角向下射线长度,
                        斜坡最小角度,
                        夹角最大允许上方距离,
                        transform.root,
                        绘制夹角探测射线,
                        out 调试_当前上距,
                        out 调试_当前下距
                    );

                    应阻挡 = 仍在夹角里;
                }

                if (应阻挡)
                {
                    if (当前尝试方向 != 0)
                        夹角阻挡锁定方向 = 当前尝试方向;

                    安全x移动量 = 0f;

                    if (最终y移动量 > 安全y移动量)
                        最终y移动量 = 安全y移动量;
                }
                else
                {
                    if (当前尝试方向 == 0 && 夹角阻挡锁定方向 != 0)
                    {
                        Transform 锁定方向探测点 = 夹角阻挡助手.按位移方向获取前向探测点(
                            夹角阻挡锁定方向,
                            右侧夹角探测点,
                            左侧夹角探测点
                        );

                        bool 仍在夹角里 = 夹角阻挡助手.前向探测点仍处于上斜坡夹角内(
                            锁定方向探测点,
                            夹角阻挡锁定方向,
                            夹角向上检测图层,
                            夹角向下检测图层,
                            夹角向上射线长度,
                            夹角向下射线长度,
                            斜坡最小角度,
                            夹角最大允许上方距离,
                            transform.root,
                            绘制夹角探测射线,
                            out _,
                            out _
                        );

                        if (!仍在夹角里)
                            夹角阻挡锁定方向 = 0;
                    }
                }
            }
            else
            {
                调试_当前上距 = -1f;
                调试_当前下距 = -1f;
                调试_目标上距 = -1f;
                调试_目标下距 = -1f;
                夹角阻挡锁定方向 = 0;
            }
        }
        else
        {
            调试_当前上距 = -1f;
            调试_当前下距 = -1f;
            调试_目标上距 = -1f;
            调试_目标下距 = -1f;
            夹角阻挡锁定方向 = 0;
        }

        // ------------------------------
        // 8. 记录左右墙挡
        // ------------------------------
        挤压_右侧被墙挡 = 合并后尝试x移动量 > 0f && 安全x移动量 < 合并后尝试x移动量 - EPS;
        挤压_左侧被墙挡 = 合并后尝试x移动量 < 0f && 安全x移动量 > 合并后尝试x移动量 + EPS;

        // ------------------------------
        // 9. 挤压二次约束 & 水平挤死
        // ------------------------------
        if (启用挤压)
        {
            // 被动推动来源本身需要被忽略，否则它会把自己的推力挡回去。
            // 但其它挤压来源仍然要参与阻挡；如果本帧推动位移被其它挤压来源挡住，
            // 也应当视为“被夹住”，不能只认普通墙壁/夹角阻挡。
            float 挤压二次约束前x移动量 = 安全x移动量;
            安全x移动量 = 新挤压_约束水平主动移动(安全x移动量, 本帧水平推动来源);

            if (启用水平挤死 &&
                本帧水平推动来源 != null &&
                本帧水平推动来源.水平挤死 &&
                Mathf.Abs(本帧水平推动来源.本帧中心水平速度) >= 本帧水平推动来源.水平挤死最小速度)
            {
                int 推动方向 = (int)Mathf.Sign(本帧水平推动位移);
                bool 推动方向有效 = 推动方向 != 0;

                bool 被几何挡住 =
                    推动方向有效 &&
                    (
                        挤压_本帧某方向被墙挡(推动方向) ||
                        夹角阻挡锁定方向 == 推动方向
                    );

                bool 被其它挤压来源挡住 = false;
                if (推动方向有效)
                {
                    if (推动方向 > 0)
                        被其它挤压来源挡住 = 安全x移动量 < 挤压二次约束前x移动量 - EPS;
                    else
                        被其它挤压来源挡住 = 安全x移动量 > 挤压二次约束前x移动量 + EPS;
                }

                if (被几何挡住 || 被其它挤压来源挡住)
                {
                    Vector2 挤压方向 = new Vector2(推动方向, 0f);
                    Component 来源 = 本帧水平推动来源.获取兼容旧挤压体来源();
                    打印挤压致死日志(被其它挤压来源挡住 ? "水平夹死-挤压来源" : "水平夹死", 挤压方向, 来源);
                    挤压_被挤压死亡(挤压方向, 来源);
                    return;
                }
            }
        }

        // ------------------------------
        // 10. 最终位移
        // ------------------------------
        // 站地后二次贴地：
        // 前面的贴地裁决发生在水平位移之前。上一帧锁定在移动Edge地面上、本帧又有水平位移时，
        // 水船/电梯上浮并走上斜坡，必须在最终X位置再让斜坡吸附助手做一次“只上抬”的防穿修正。
        if (平台搭乘_水平移动后验证移动平台贴地
            && 本帧上一帧平台允许锁定
            && 启用平台搭乘
            && 启用地面吸附
            && 是否在地面
            && 平台搭乘_上一帧脚下碰撞体 != null
            && 物理碰撞器 != null
            && Mathf.Abs(安全x移动量) > EPS)
        {
            if (斜坡吸附助手.站地后二次贴地仅上抬(
                物理碰撞器,
                获取当前有效地面图层(),
                安全x移动量,
                最终y移动量,
                地面缓冲距离,
                out float 二次贴地Y,
                out RaycastHit2D 二次贴地命中,
                平台搭乘_上一帧脚下碰撞体,
                0.08f,
                平台搭乘_验证额外射线长度,
                平台搭乘_最大验证Y修正距离,
                0.02f,
                当前脚下检测规则,
                当前临时忽略检测规则,
                地面检测点))
            {
                if (二次贴地Y > 最终y移动量 + EPS)
                {
                    bool 二次贴地顶头;
                    float 安全二次贴地Y = 通用物理_计算二次贴地安全上抬_排除当前支撑地面(
                        二次贴地Y,
                        皮肤宽度,
                        out 二次贴地顶头
                    );

                    if (启用挤压 && 启用顶部阻挡解析)
                    {
                        if (新挤压_解析头顶纵向约束(
                            安全二次贴地Y,
                            out float 挤压约束后二次贴地Y,
                            out _,
                            out _,
                            out _))
                        {
                            安全二次贴地Y = 挤压约束后二次贴地Y;
                        }
                    }

                    if (安全二次贴地Y >= 二次贴地Y - EPS)
                    {
                        最终y移动量 = 二次贴地Y;
                        当前地面碰撞信息 = 二次贴地命中;
                        是否在地面 = true;

                        if (当前速度.y < 0f)
                            当前速度.y = 0f;
                    }
                    else
                    {
                        // 上方空间不足时，不把单位横向推进上浮斜坡内部。
                        安全x移动量 = 0f;
                    }
                }
            }
        }

        // 空中向下移动防穿地兜底：
        // 普通贴地/平台锁定先执行；如果它们没有接住，再用最终X位置的脚底中心确认是否真正穿过地面。
        // 这里只允许修正Y，不再用物理碰撞器边角命中裁剪X，避免宽体单位斜坡边角锁死水平移动。
        if (通用物理_尝试裁剪空中向下穿地(ref 安全x移动量, ref 最终y移动量, out RaycastHit2D 防穿地地面命中))
        {
            是否在地面 = true;
            当前地面碰撞信息 = 防穿地地面命中;
            当前速度.y = 0f;

            // 空中脚底中心防穿地兜底绕过了斜坡吸附助手.贴地裁决()，
            // 因此需要手动同步斜坡吸附助手内部的地面记忆。
            // 否则上一次站在场景地面后，再跳到废墟地面时，下一帧可能被旧场景地面记忆重新拉回下方场景地面。
            斜坡吸附助手.同步地面吸附记忆(物理碰撞器, 防穿地地面命中);
        }

        // 停下帧锁定保护：只在本帧没有实际水平位移时救回上一帧锁定平台。
        // 移动中不做多点/边角式保留，避免重新出现复杂斜边上的边缘兜底挂边。
        if (Mathf.Abs(安全x移动量) <= EPS)
            平台搭乘_最终保护上一帧锁定平台(ref 当前地面碰撞信息, ref 最终y移动量);

        Collider2D 本帧结束脚下缓存 = null;
        if (是否在地面)
        {
            if (当前地面碰撞信息.collider != null)
                本帧结束脚下缓存 = 当前地面碰撞信息.collider;
            else if (本帧使用上一帧平台缓存)
                本帧结束脚下缓存 = 平台搭乘_上一帧脚下碰撞体;
        }

        平台搭乘_上一帧脚下碰撞体 = 本帧结束脚下缓存;
        平台搭乘_上一帧站在地面 = 本帧结束脚下缓存 != null;

        // 最终脚下地面已经完成裁决后再刷新排序图层偏移。
        // 离地时不恢复，下一次真正落地时再按新地面规则裁决。
        刷新落地排序图层偏移状态(本帧结束脚下缓存);

        本物理帧最终提交位移_调试 = new Vector2(安全x移动量, 最终y移动量);

        if (刚体 != null)
            刚体.MovePosition(刚体.position + 本物理帧最终提交位移_调试);
        else
            transform.position += new Vector3(本物理帧最终提交位移_调试.x, 本物理帧最终提交位移_调试.y, 0f);
    }


    protected virtual float 通用物理_计算二次贴地安全上抬_排除当前支撑地面(float 理想y移动量, float 皮肤宽度参数, out bool 顶头)
    {
        顶头 = false;

        if (理想y移动量 <= 0f)
            return 理想y移动量;

        if (物理碰撞器 == null || !物理碰撞器.enabled || !物理碰撞器.gameObject.activeInHierarchy)
        {
            if (启用与单向墙碰撞 && 墙壁碰撞器 != null)
            {
                return 墙壁碰撞器.计算安全垂直移动(
                    理想y移动量,
                    皮肤宽度参数,
                    out 顶头,
                    default(LayerMask),
                    获取临时忽略地面检测规则(),
                    获取脚下地面检测规则()
                );
            }

            return 理想y移动量;
        }

        LayerMask 上方检测图层 = 通用物理_获取二次贴地上方检测图层();
        if (上方检测图层.value == 0)
            return 理想y移动量;

        ContactFilter2D 过滤 = new ContactFilter2D();
        过滤.useLayerMask = true;
        过滤.layerMask = 上方检测图层;
        过滤.useTriggers = true;

        float 扫掠皮肤 = Mathf.Max(皮肤宽度参数, 0.002f);
        int 命中数量 = 物理碰撞器.Cast(Vector2.up, 过滤, 二次贴地上方扫掠缓存, 理想y移动量 + 扫掠皮肤);

        float 最近阻挡距离 = float.PositiveInfinity;
        for (int i = 0; i < 命中数量 && i < 二次贴地上方扫掠缓存.Length; i++)
        {
            RaycastHit2D hit = 二次贴地上方扫掠缓存[i];
            if (!通用物理_二次贴地上抬命中应阻挡(hit))
                continue;

            if (hit.distance < 最近阻挡距离)
                最近阻挡距离 = hit.distance;
        }

        if (float.IsPositiveInfinity(最近阻挡距离))
            return 理想y移动量;

        顶头 = true;
        return Mathf.Max(0f, 最近阻挡距离 - 扫掠皮肤);
    }

    protected virtual LayerMask 通用物理_获取二次贴地上方检测图层()
    {
        LayerMask 图层 = 0;

        if (夹角向上检测图层.value != 0)
            图层 |= 夹角向上检测图层;

        if (墙壁碰撞器 != null)
            图层 |= 墙壁碰撞器.天花板检测图层;

        return 图层;
    }

    protected virtual bool 通用物理_二次贴地上抬命中应阻挡(RaycastHit2D hit)
    {
        if (hit.collider == null)
            return false;

        if (hit.collider.transform.root == transform.root)
            return false;

        // 二次贴地是在“上一帧锁定平台/当前脚下地面”的最终X位置重新贴回同一支撑面。
        // 当前支撑地面不能同时被当作头顶阻挡，否则水船/电梯上浮或同一Edge上坡时会把水平位移清零。
        if (通用物理_是否当前支撑地面(hit.collider))
            return false;

        return true;
    }

    protected virtual bool 通用物理_是否当前支撑地面(Collider2D 碰撞器)
    {
        if (!是否在地面 || 碰撞器 == null)
            return false;

        if (当前地面碰撞信息.collider != null && 碰撞器 == 当前地面碰撞信息.collider)
            return true;

        if (平台搭乘_上一帧脚下碰撞体 != null && 碰撞器 == 平台搭乘_上一帧脚下碰撞体)
            return true;

        return false;
    }

    protected virtual bool 通用物理_尝试裁剪空中向下穿地(ref float x移动量, ref float y移动量, out RaycastHit2D 地面命中)
    {
        地面命中 = default;

        const float EPS = 1e-5f;

        if (!启用地面吸附)
            return false;

        // 只处理空中向下移动。站地状态继续交给原贴地/平台锁定/二次贴地逻辑，避免改变走坡手感。
        if (是否在地面)
            return false;

        if (y移动量 >= -EPS)
            return false;

        LayerMask 当前地面图层 = 获取当前有效地面图层();
        if (当前地面图层.value == 0)
            return false;

        // 本方法只负责“脚底中心向下穿地”的兜底修正。
        // 不再使用整个碰撞器Cast裁剪x移动量，避免宽体边角扫到斜坡后锁死水平移动。
        if (地面检测点 == null && (物理碰撞器 == null || !物理碰撞器.enabled || !物理碰撞器.gameObject.activeInHierarchy))
            return false;

        float 穿越容差 = Mathf.Max(0.05f, 地面缓冲距离 + 0.02f);

        bool 有脚底中心确认落地 = 通用物理_尝试脚底中心确认空中向下落地(
            x移动量,
            y移动量,
            当前地面图层,
            地面缓冲距离,
            穿越容差,
            out RaycastHit2D 脚底中心地面命中,
            out float 脚底中心贴地Y移动量
        );

        if (!有脚底中心确认落地)
            return false;

        // 脚底中心已经证明本帧会到达/穿过地面；这里只收紧y，不裁剪x。
        y移动量 = 脚底中心贴地Y移动量;
        地面命中 = 脚底中心地面命中;
        return true;
    }

    protected virtual bool 通用物理_尝试脚底中心确认空中向下落地(
        float x移动量,
        float y移动量,
        LayerMask 当前地面图层,
        float 当前地面缓冲距离,
        float 穿越容差,
        out RaycastHit2D 中心地面命中,
        out float 中心贴地Y移动量)
    {
        中心地面命中 = default;
        中心贴地Y移动量 = y移动量;

        const float EPS = 1e-5f;
        if (y移动量 >= -EPS)
            return false;

        if (当前地面图层.value == 0)
            return false;

        Vector2 当前脚底 = 地面检测点 != null
            ? (Vector2)地面检测点.position
            : new Vector2(物理碰撞器.bounds.center.x, 物理碰撞器.bounds.min.y);

        // 用本帧最终水平位置的脚底中心做确认，避免斜向移动时旧X位置误判。
        float 检测X = 当前脚底.x + x移动量;
        float 当前脚底Y = 当前脚底.y;
        float 预测脚底Y = 当前脚底Y + y移动量;

        float 上探容差 = Mathf.Max(当前地面缓冲距离 + 皮肤宽度 + 0.03f, 0.08f);
        Vector2 中心射线起点 = new Vector2(检测X, 当前脚底Y + 上探容差);
        float 检测长度 = 上探容差 + Mathf.Abs(y移动量) + 当前地面缓冲距离 + 穿越容差;

        ContactFilter2D 过滤 = new ContactFilter2D();
        过滤.useLayerMask = true;
        过滤.layerMask = 当前地面图层;
        过滤.useTriggers = true;

        int 命中数 = Physics2D.Raycast(
            中心射线起点,
            Vector2.down,
            过滤,
            空中向下防穿地扫掠缓存,
            检测长度
        );

        地面检测规则文件 当前脚下检测规则 = 获取脚下地面检测规则();
        地面检测规则文件 当前临时忽略检测规则 = 获取临时忽略地面检测规则();

        float 最近距离 = float.PositiveInfinity;
        RaycastHit2D 最近合法命中 = default;
        float 最近目标脚底Y = 0f;

        for (int i = 0; i < 命中数 && i < 空中向下防穿地扫掠缓存.Length; i++)
        {
            RaycastHit2D hit = 空中向下防穿地扫掠缓存[i];
            if (hit.collider == null)
                continue;

            if (hit.collider.transform.root == transform.root)
                continue;

            if (当前临时忽略检测规则 != null && 地面规则缓存.命中符合检测规则(hit, 当前临时忽略检测规则))
                continue;

            if (!地面规则缓存.命中可作为脚下地面(hit, 当前脚下检测规则))
                continue;

            // 只接住可站立的上表面/斜坡；侧面、下表面不作为落地。
            if (hit.normal.y <= 0.05f)
                continue;

            // Edge首尾端点附近不作为稳定落地兜底，避免端点处反复下落/落地。
            if (斜坡吸附助手.边缘兜底命中过近首尾端点(hit))
                continue;

            float 目标脚底Y = hit.point.y + 当前地面缓冲距离;

            // 只确认“脚底中心本帧真正到达/穿越了地面”。
            // 不使用长射线直接吸附远处地面，避免重新引入瞬移式落地。
            bool 起点在地面上方或接近表面 = 当前脚底Y >= 目标脚底Y - 穿越容差;
            bool 终点到达或穿过地面 = 预测脚底Y <= 目标脚底Y + 穿越容差;
            if (!起点在地面上方或接近表面 || !终点到达或穿过地面)
                continue;

            if (hit.distance < 最近距离)
            {
                最近距离 = hit.distance;
                最近合法命中 = hit;
                最近目标脚底Y = 目标脚底Y;
            }
        }

        if (最近合法命中.collider == null)
            return false;

        中心地面命中 = 最近合法命中;
        中心贴地Y移动量 = 最近目标脚底Y - 当前脚底Y;
        return true;
    }

    protected virtual void OnDrawGizmosSelected()
    {
        绘制夹角探测射线_Gizmos();
    }

    protected virtual void 绘制夹角探测射线_Gizmos()
    {
        if (!绘制夹角探测射线)
            return;

        绘制单侧夹角探测射线_Gizmos(右侧夹角探测点, Color.yellow);
        绘制单侧夹角探测射线_Gizmos(左侧夹角探测点, Color.cyan);
    }

    protected virtual void 绘制单侧夹角探测射线_Gizmos(Transform 探测点, Color 颜色)
    {
        if (探测点 == null)
            return;

        Vector3 起点 = 探测点.position;

        Gizmos.color = 颜色;
        Gizmos.DrawLine(起点, 起点 + Vector3.up * Mathf.Max(0f, 夹角向上射线长度));
        Gizmos.DrawLine(起点, 起点 + Vector3.down * Mathf.Max(0f, 夹角向下射线长度));

#if UNITY_EDITOR
        UnityEditor.Handles.color = 颜色;
        UnityEditor.Handles.Label(起点, 探测点.name);
#endif
    }

    // ==========================================
    // I分岔输入源
    // 给 斜坡吸附助手 读取：1=上，-1=下，0=不按
    // ==========================================
    public virtual float 获取垂直输入()
    {
        if (!启用AI分岔输入)
            return 0f;

        if (AI分岔需要水平移动 && Mathf.Abs(移动意图X) < 0.01f)
        {
            AI分岔_离开窗口或无输入时重置();
            return 0f;
        }

        if (!AI分岔_尝试获取当前分岔区域(out Bounds 当前分岔区域))
        {
            AI分岔_离开窗口或无输入时重置();
            return 0f;
        }

        int 当前窗口Key = AI分岔_计算窗口Key(当前分岔区域);

        bool 是新窗口 = !AI分岔在窗口内 || AI分岔当前窗口Key != 当前窗口Key;
        if (是新窗口)
        {
            AI分岔在窗口内 = true;
            AI分岔当前窗口Key = 当前窗口Key;
            AI分岔当前垂直输入 = 0;
            AI分岔已锁定选择 = false;
            AI分岔锁定目标Key = 0;
        }

        if (!尝试获取AI分岔当前索敌目标(out 敌人索敌目标 当前索敌目标))
        {
            AI分岔当前垂直输入 = 0;
            AI分岔已锁定选择 = false;
            AI分岔锁定目标Key = 0;
            return 0f;
        }

        int 当前目标Key = 当前索敌目标.目标Key;

        bool 目标变化 =
            AI分岔已锁定选择 &&
            AI分岔目标变化时重新选择 &&
            AI分岔锁定目标Key != 0 &&
            AI分岔锁定目标Key != 当前目标Key;

        if (目标变化)
        {
            AI分岔当前垂直输入 = 0;
            AI分岔已锁定选择 = false;
            AI分岔锁定目标Key = 0;

            if (AI分岔调试日志)
            {
                Debug.Log(
                    $"[AI分岔] {name} 目标变化，解除分岔锁定，重新选择。旧Key={AI分岔锁定目标Key}, 新Key={当前目标Key}",
                    this
                );
            }
        }

        if (AI分岔进入窗口后锁定选择 && AI分岔已锁定选择)
            return AI分岔当前垂直输入;

        float 目标脚底Y = 当前索敌目标.目标脚底Y;
        float 分岔中心Y = 当前分岔区域.center.y;
        float 阈值 = Mathf.Max(0f, AI分岔Y判定阈值);

        int 选择 = 0;

        if (目标脚底Y > 分岔中心Y + 阈值)
            选择 = 1;
        else if (目标脚底Y < 分岔中心Y - 阈值)
            选择 = -1;

        AI分岔当前垂直输入 = 选择;

        if (选择 != 0)
        {
            AI分岔已锁定选择 = true;
            AI分岔锁定目标Key = 当前目标Key;
        }

        if (AI分岔调试日志)
        {
            Debug.Log(
                $"[AI分岔] 单位={name} 选择={选择} 目标脚底Y={目标脚底Y:F2} 分岔中心Y={分岔中心Y:F2} 目标Key={当前目标Key} 窗口Key={当前窗口Key}",
                this
            );
        }

        return AI分岔当前垂直输入;
    }

    public virtual float 获取水平输入()
    {
        // 斜坡吸附助手会用水平输入判断分岔坡向是否合法。
        // 对敌人来说，移动意图X就是它当前“想往左/右走”的方向。
        return 移动意图X;
    }

    protected virtual bool 尝试获取AI分岔当前索敌目标(out 敌人索敌目标 目标)
    {
        目标 = null;

        if (AI分岔目标提供者缓存 == null)
        {
            AI分岔目标提供者缓存 = GetComponent<I敌人索敌目标提供者>();

            if (AI分岔目标提供者缓存 == null)
                AI分岔目标提供者缓存 = GetComponentInParent<I敌人索敌目标提供者>();

            if (AI分岔目标提供者缓存 == null)
                AI分岔目标提供者缓存 = GetComponentInChildren<I敌人索敌目标提供者>(true);
        }

        if (AI分岔目标提供者缓存 == null)
            return false;

        if (!AI分岔目标提供者缓存.尝试获取当前索敌目标(out 目标))
            return false;

        if (目标 == null)
            return false;

        if (!目标.有效)
            return false;

        return true;
    }

    protected virtual bool AI分岔_尝试获取当前分岔区域(out Bounds 当前分岔区域)
    {
        当前分岔区域 = default;

        自动分岔区域推断器 推断器 = 自动分岔区域推断器.单例;
        if (推断器 == null)
            return false;

        Transform 检测点 = 地面检测点 != null ? 地面检测点 : transform;

        return 推断器.尝试获取所在分岔区域(检测点.position, out 当前分岔区域);
    }

    protected virtual void AI分岔_离开窗口或无输入时重置()
    {
        AI分岔当前垂直输入 = 0;
        AI分岔当前窗口Key = 0;
        AI分岔在窗口内 = false;
        AI分岔已锁定选择 = false;
        AI分岔锁定目标Key = 0;
    }

    protected virtual int AI分岔_计算窗口Key(Bounds b)
    {
        int cx = Mathf.RoundToInt(b.center.x * 10f);
        int cy = Mathf.RoundToInt(b.center.y * 10f);
        int sx = Mathf.RoundToInt(b.size.x * 10f);
        int sy = Mathf.RoundToInt(b.size.y * 10f);

        unchecked
        {
            int h = 17;
            h = h * 31 + cx;
            h = h * 31 + cy;
            h = h * 31 + sx;
            h = h * 31 + sy;
            return h;
        }
    }

    // ==========================================
    // I弹飞目标 / I脚下地面碰撞器
    // ==========================================

    // 注意：脚本里已经有 public bool 字段“是否在地面”，字段不能直接实现接口属性。
    // 所以这里使用显式接口实现，避免改动原字段名。
    bool I脚下地面碰撞器.是否在地面 => 是否在地面;

    public Collider2D 当前脚下地面碰撞器
    {
        get
        {
            if (!是否在地面) return null;
            return 当前地面碰撞信息.collider;
        }
    }

    public virtual bool 是否站在指定地面(Collider2D 地面碰撞器)
    {
        if (地面碰撞器 == null) return false;
        if (!是否在地面) return false;
        if (当前地面碰撞信息.collider == null) return false;

        return 当前地面碰撞信息.collider == 地面碰撞器;
    }

    public virtual void 接收弹飞(Vector2 弹飞速度, Component 来源, bool 只增大垂直速度, bool 覆盖水平速度)
    {
        // 垂直速度：默认只增大，不把已经高速上升的单位拉慢。
        if (只增大垂直速度)
            当前速度.y = Mathf.Max(当前速度.y, 弹飞速度.y);
        else
            当前速度.y = 弹飞速度.y;

        // 水平速度：只有范围弹飞器明确要求覆盖时才改。
        if (覆盖水平速度)
            当前速度.x = 弹飞速度.x;

        // 弹飞后必须离地，否则下一帧可能继续被判定为站在原地面/平台上。
        立即离地();

        // 如果单位处于停顿状态，弹飞仍然应该生效。
        // 这里不强制解除 当前停顿中，因为有些状态机可能需要保持动画停顿；
        // 物理移动基类的重力仍然会继续处理当前速度。
    }

    // ==========================================
    // I平台搭乘者
    // ==========================================
    public float 当前垂直速度 => 当前速度.y;
    public bool 当前是否在地面 => 是否在地面;

    public virtual void 被平台接住(float 缺口)
    {
        transform.position += new Vector3(0f, 缺口, 0f);
        当前速度.y = 0f;
        是否在地面 = true;

        // 被平台强制接住时，脚下地面信息不一定是本帧斜坡吸附得到的，
        // 所以先清空，等下一次正常贴地裁决再刷新。
        当前地面碰撞信息 = default;
    }

    public virtual void 接收平台拖动(Vector2 拖动量)
    {
        if (!启用平台搭乘) return;
        外部平台拖动累计位移 += 拖动量;
    }

    // ==========================================
    // I挤压目标
    // ==========================================
    public virtual BoxCollider2D 挤压_获取主碰撞框() => 物理碰撞器;
    public virtual bool 挤压_当前是否在地面() => 是否在地面;

    public virtual void 挤压_被水平推动(float 推动量)
    {
        if (!启用挤压) return;
        挤压_额外水平位移 += 推动量;
    }

    public virtual void 挤压_被垂直推动(float 推动量)
    {
        if (!启用挤压) return;
        挤压_额外垂直位移 += 推动量;
    }

    public virtual void 挤压_被挤压死亡(Vector2 挤压方向, Component 来源)
    {
        处理被挤压死亡(挤压方向, 来源);
    }

    public virtual bool 挤压_本帧某方向被墙挡(int 方向)
    {
        return 方向 >= 0 ? 挤压_右侧被墙挡 : 挤压_左侧被墙挡;
    }

    /// <summary>
    /// 只计算本单位主动水平位移的推动倍率。子类/BOSS以后可覆写并改用局部代理来源。
    /// </summary>
    protected virtual float 获取水平推动主动速度倍率(float 原始主动位移, float 预测来源水平位移)
    {
        if (!启用水平推动主动减速 || Mathf.Abs(原始主动位移) <= 0.0001f)
        {
            水平推动主动减速_记录诊断("结果=1；基类原因=功能关闭或原始主动位移接近0");
            return 1f;
        }

        // 平台/外力若把整体运动反向，就不应把“反向行走”的主动速度误判成正在推动。
        if (Mathf.Abs(预测来源水平位移) <= 0.0001f || Mathf.Sign(原始主动位移) != Mathf.Sign(预测来源水平位移))
        {
            水平推动主动减速_记录诊断(
                $"结果=1；基类原因=预测整体位移为0或与主动位移反向；主动dx={原始主动位移:F4}；预测来源dx={预测来源水平位移:F4}");
            return 1f;
        }

        if (!水平推动主动减速_已查询根标志)
        {
            水平推动主动减速_根标志 = GetComponent<挤压标志>();
            水平推动主动减速_已查询根标志 = true;
        }

        挤压标志 标志 = 水平推动主动减速_根标志;
        if (标志 == null || !标志.enabled || !标志.gameObject.activeInHierarchy || !标志.水平推动)
        {
            水平推动主动减速_记录诊断("结果=1；基类原因=同节点没有有效挤压标志或水平推动关闭");
            return 1f;
        }

        BoxCollider2D 来源碰撞器 = 标志.挤压参考碰撞器;
        if (来源碰撞器 == null || !来源碰撞器.enabled)
        {
            水平推动主动减速_记录诊断("结果=1；基类原因=挤压参考碰撞器为空或未启用");
            return 1f;
        }

        挤压来源候选 来源 = new 挤压来源候选
        {
            标志 = 标志,
            代理 = null,
            参考碰撞器 = 来源碰撞器,
            参考Bounds = 来源碰撞器.bounds
        };

        string 诊断;
        float 倍率 = 挤压检测助手.计算推动者主动水平速度倍率(
            来源,
            transform.root,
            预测来源水平位移,
            水平推动主动速度倍率,
            启用水平推动主动减速诊断,
            out 诊断);

        水平推动主动减速_记录诊断(
            $"单位={name}；主动dx={原始主动位移:F4}；预测来源dx={预测来源水平位移:F4}；最终倍率={倍率:F2}\n{诊断}");

        return 倍率;
    }

    private void 水平推动主动减速_记录诊断(string 内容)
    {
        if (!启用水平推动主动减速诊断)
            return;

        水平推动主动减速诊断_最后结果 = 内容 ?? string.Empty;

        if (!水平推动主动减速诊断_输出Console)
            return;

        int 间隔 = Mathf.Max(1, 水平推动主动减速诊断_输出间隔帧);
        if (Time.frameCount - 水平推动主动减速诊断_上次输出帧 < 间隔)
            return;

        水平推动主动减速诊断_上次输出帧 = Time.frameCount;
        Debug.Log($"[水平推动主动减速诊断] {水平推动主动减速诊断_最后结果}", this);
    }

    // ==========================================
    // 新挤压辅助
    // ==========================================
    protected virtual void 新挤压_重置本轮水平候选缓存()
    {
        新挤压_本轮水平候选已收集 = false;
        新挤压_水平候选缓存.Clear();
    }

    protected virtual void 新挤压_确保已收集本轮水平候选(float 预测水平位移)
    {
        if (新挤压_本轮水平候选已收集) return;
        if (物理碰撞器 == null) return;

        Bounds 自身 = 物理碰撞器.bounds;

        float 横向扩展 =
            Mathf.Abs(预测水平位移) +
            Mathf.Max(0.5f, 自身.size.x * 0.5f) +
            新挤压_附近收集水平额外余量;

        float 纵向扩展 =
            Mathf.Max(0.25f, 自身.size.y * 0.25f) +
            新挤压_附近收集垂直额外余量;

        挤压检测助手.收集附近有效来源(
            物理碰撞器,
            transform.root,
            新挤压检测图层,
            横向扩展,
            纵向扩展,
            新挤压_水平候选缓存
        );

        新挤压_本轮水平候选已收集 = true;
    }

    protected virtual GameObject 新挤压_获取目标节点()
    {
        if (被推动碰撞器节点 != null) return 被推动碰撞器节点;
        if (物理碰撞器 != null) return 物理碰撞器.gameObject;
        return gameObject;
    }

    protected virtual bool 新挤压_解析头顶纵向约束(
        float 原始想y移动量,
        out float 修正后想y移动量,
        out 挤压标志 阻挡来源,
        out bool 来自顶部阻挡,
        out bool 来自有效下压)
    {
        修正后想y移动量 = 原始想y移动量;
        阻挡来源 = null;
        来自顶部阻挡 = false;
        来自有效下压 = false;

        if (物理碰撞器 == null) return false;

        挤压检测助手.收集头顶候选(
            物理碰撞器,
            transform.root,
            新挤压检测图层,
            新挤压头顶条带高度,
            新挤压头顶射线长度,
            新挤压头顶射线间距,
            新挤压绘制调试,
            新挤压_头顶候选缓存
        );

        if (新挤压_头顶候选缓存.Count == 0)
            return false;

        Bounds 我 = 物理碰撞器.bounds;
        GameObject 目标节点 = 新挤压_获取目标节点();

        bool 命中 = false;
        float 最终建议y = 原始想y移动量;

        for (int i = 0; i < 新挤压_头顶候选缓存.Count; i++)
        {
            挤压来源候选 来源 = 新挤压_头顶候选缓存[i];
            挤压标志 标志 = 来源.标志;
            if (标志 == null) continue;
            if (!标志.enabled || !标志.gameObject.activeInHierarchy) continue;

            Bounds 他 = 来源.参考Bounds;
            if (他.size.sqrMagnitude <= 0.000001f) continue;

            bool 是顶部阻挡 =
                启用顶部阻挡解析 &&
                原始想y移动量 > 0f &&
                挤压检测助手.是否满足顶部阻挡(
                    标志, 我, 他, 目标节点, Mathf.Max(0f, 原始想y移动量));

            bool 是有效下压 =
                启用下压致死判定 &&
                挤压检测助手.是否满足有效下压(
                    标志, 我, 他, 目标节点, Mathf.Max(0f, 原始想y移动量));

            if (!是顶部阻挡 && !是有效下压)
                continue;

            float 候选y = 原始想y移动量;

            if (是顶部阻挡)
            {
                候选y = Mathf.Min(
                    候选y,
                    挤压检测助手.计算向上贴底允许位移(
                        我, 他, Mathf.Max(0f, 原始想y移动量), 标志.纵向接触容差)
                );
            }

            if (是有效下压)
            {
                候选y = Mathf.Min(
                    候选y,
                    挤压检测助手.计算被下压时建议竖直位移(
                        我, 他, 原始想y移动量, 标志.纵向接触容差)
                );
            }

            if (!命中 || 候选y < 最终建议y)
            {
                命中 = true;
                最终建议y = 候选y;
                阻挡来源 = 标志;
                来自顶部阻挡 = 是顶部阻挡 && !是有效下压;
                来自有效下压 = 是有效下压;
            }
        }

        if (!命中)
            return false;

        修正后想y移动量 = 最终建议y;
        return true;
    }

    protected virtual float 新挤压_约束水平主动移动(float 原始dx)
    {
        return 新挤压_约束水平主动移动(原始dx, null);
    }

    protected virtual float 新挤压_约束水平主动移动(float 原始dx, 挤压标志 忽略来源)
    {
        if (物理碰撞器 == null) return 原始dx;
        if (Mathf.Abs(原始dx) <= 0.0001f) return 原始dx;

        Bounds 我 = 物理碰撞器.bounds;
        GameObject 目标节点 = 新挤压_获取目标节点();
        float 当前dx = 原始dx;

        新挤压_确保已收集本轮水平候选(原始dx);

        for (int i = 0; i < 新挤压_水平候选缓存.Count; i++)
        {
            挤压来源候选 来源 = 新挤压_水平候选缓存[i];
            挤压标志 标志 = 来源.标志;
            if (标志 == null) continue;
            if (忽略来源 != null && 标志 == 忽略来源) continue;

            Bounds 他 = 来源.参考Bounds;
            if (他.size.sqrMagnitude <= 0.000001f) continue;

            当前dx = 挤压检测助手.计算水平主动阻挡后位移(
                标志, 我, 他, 目标节点, 当前dx);
        }

        return 当前dx;
    }

    protected virtual bool 新挤压_尝试获取被动推动(out 挤压标志 推动来源, out float 推动位移)
    {
        推动来源 = null;
        推动位移 = 0f;

        if (物理碰撞器 == null) return false;

        Bounds 我 = 物理碰撞器.bounds;
        GameObject 目标节点 = 新挤压_获取目标节点();
        float 最强推动绝对值 = 0f;

        新挤压_确保已收集本轮水平候选(0f);

        for (int i = 0; i < 新挤压_水平候选缓存.Count; i++)
        {
            挤压来源候选 来源 = 新挤压_水平候选缓存[i];
            挤压标志 标志 = 来源.标志;
            if (标志 == null) continue;

            if (!新挤压_允许被该来源推动(标志))
                continue;

            Bounds 他 = 来源.参考Bounds;
            if (他.size.sqrMagnitude <= 0.000001f) continue;

            if (!挤压检测助手.尝试计算被动推动位移(
                标志,
                我,
                他,
                目标节点,
                新挤压推动权重,
                out float 候选推动位移))
                continue;

            float 强度 = Mathf.Abs(候选推动位移);
            if (推动来源 == null || 强度 > 最强推动绝对值)
            {
                推动来源 = 标志;
                推动位移 = 候选推动位移;
                最强推动绝对值 = 强度;
            }
        }

        return 推动来源 != null;
    }

    /// <summary>
    /// 公开方法：将当前节点的 localScale.x 取反。
    /// 适合给动画事件直接调用。
    /// </summary>
    public virtual void 水平翻转()
    {
        Vector3 scale = transform.localScale;

        // 防止 X 恰好是 0，导致取反后还是 0
        if (Mathf.Abs(scale.x) <= 0.0001f)
            scale.x = 1f;
        else
            scale.x = -scale.x;

        transform.localScale = scale;

        水平翻转后();
    }

    /// <summary>
    /// 动画事件专用入口。
    /// 如果你更喜欢在动画事件里选这个名字，就调用这个。
    /// </summary>
    public virtual void 动画事件_水平翻转()
    {
        水平翻转();
    }

    /// <summary>
    /// 给子类覆写：在真正翻转完缩放后，做朝向缓存/方向标志刷新。
    /// </summary>
    protected virtual void 水平翻转后()
    {
    }

    // ==========================================
    // 可给子类直接读的公共属性
    // ==========================================
    public Vector2 当前速度值 => 当前速度;
    public bool 当前是否在地面值 => 是否在地面;
    public bool 当前是否停顿 => 当前停顿中;
    public bool 当前是否趴下 => 当前趴下姿态;
}
