using UnityEngine;

/// <summary>
/// 给运行时生成的 EdgeCollider2D 移动地面使用。
/// 默认通过位置差记录地面每个物理帧的实际位移；也支持由载具移动脚本直接提交本物理帧最终位移，
/// 并合并该地面节点自身的局部/动画位移，让搭乘者在同一个物理帧读取，避免 Rigidbody2D.MovePosition 造成的一帧采样延迟。
/// 注意：循环复位/瞬移产生的大位移会被过滤掉，避免把玩家/单位一起瞬移到另一端。
/// </summary>
[DefaultExecutionOrder(-200)]
[DisallowMultipleComponent]
public class 可搭乘Edge地面位移源 : MonoBehaviour
{
    [Header("位移跟踪")]
    [Tooltip("优先读取这个刚体的位置；不填则读取跟踪目标/自身Transform。")]
    public Rigidbody2D 跟踪刚体;

    [Tooltip("不填则默认跟踪自己。")]
    public Transform 跟踪目标;

    [Header("位移来源模式")]
    [Tooltip("关闭：通过跟踪目标的位置差自动采样，兼容旧移动地面。\n开启：由载具移动脚本调用 提交本物理帧位移()，搭乘者可在同一物理帧读取，避免MovePosition导致的一帧延迟。\n直接提交者的FixedUpdate执行顺序必须早于本脚本的-200。")]
    public bool 使用外部直接提交位移 = false;

    [Header("可搭乘碰撞器")]
    [Tooltip("不填则自动获取本物体上的 Collider2D。通常就是运行时生成地面的 EdgeCollider2D。")]
    public Collider2D 可搭乘碰撞器;

    [Header("过滤")]
    [Tooltip("开启后只把水平位移传给搭乘者。旧移动地面可保持开启；需要上下移动/电梯式Edge地面时请关闭。")]
    public bool 只传递水平位移 = false;

    [Tooltip("单帧位移超过该值时视为循环复位/瞬移，不传给搭乘者。设为0或负数表示不过滤。")]
    public float 最大可传递单帧位移 = 8f;

    [Header("脚下平台锁定")]
    [Tooltip("开启后，上一帧站在该Edge地面上的单位会优先验证并保持该Edge地面，避免电梯抖动/水船下沉时被其它地面抢走。普通分岔路或不需要保持的平台可关闭。")]
    public bool 启用脚下平台锁定 = true;

    [Header("2D物理同步")]
    [Tooltip("默认开启。检测到跟踪目标被动画或脚本直接改变Transform位置后，在搭乘者进行物理查询前同步Physics2D。\n静止平台不会调用；无论同时有多少个平台移动，同一物理帧全局最多同步一次。\n不需要通过动画事件调用。")]
    public bool 位移后同步2D物理变换 = true;

    [Header("调试")]
    [SerializeField, Tooltip("运行时只读：本物理帧传递给搭乘者的位移。循环复位/瞬移会被过滤为0。")]
    private Vector2 本帧位移增量_调试 = Vector2.zero;

    public Vector2 本帧位移增量 => 本帧位移增量_调试;

    private Vector2 上一帧位置;
    private bool 已初始化 = false;

    // Physics2D.SyncTransforms()是全局同步。多个位移源在同一物理帧检测到位移时只执行一次，
    // 避免平台数量增加后重复产生相同的同步开销。
    private static int 上次同步所在渲染帧 = -1;
    private static float 上次同步所在物理时间 = float.NegativeInfinity;

    // 外部提交保存“未过滤的真实位移”用于同步自动采样基准，避免退出外部模式后重复采样一次。
    private Vector2 外部提交原始位移 = Vector2.zero;
    private bool 外部提交待消费 = false;

    private void Reset()
    {
        自动补引用();
    }

    private void Awake()
    {
        自动补引用();
    }

    private void OnEnable()
    {
        自动补引用();
        上一帧位置 = 获取当前位置();
        本帧位移增量_调试 = Vector2.zero;
        外部提交原始位移 = Vector2.zero;
        外部提交待消费 = false;
        已初始化 = true;
    }

    private void OnDisable()
    {
        本帧位移增量_调试 = Vector2.zero;
        外部提交原始位移 = Vector2.zero;
        外部提交待消费 = false;
        已初始化 = false;
    }

    private void FixedUpdate()
    {
        Vector2 当前 = 获取当前位置();

        if (!已初始化)
        {
            上一帧位置 = 当前;
            本帧位移增量_调试 = Vector2.zero;
            外部提交原始位移 = Vector2.zero;
            外部提交待消费 = false;
            已初始化 = true;
            return;
        }

        if (使用外部直接提交位移)
        {
            if (外部提交待消费)
            {
                // 外部提交的是载具根节点经过碰撞裁剪后的最终位移。
                // 当前位置与上一帧预计位置之间的差值，则代表该地面节点自身额外产生的局部/动画位移。
                // 两者合并后再发布，可支持运输车/BOSS身上多个相对运动的可站立部位。
                Vector2 地面节点额外位移 = 当前 - 上一帧位置;
                尝试同步2D物理变换(地面节点额外位移);
                Vector2 合并后位移 = 外部提交原始位移 + 地面节点额外位移;
                本帧位移增量_调试 = 过滤可传递位移(合并后位移);

                // 把自动采样基准推进到根节点本次MovePosition完成后的预计位置。
                // 下一帧物理模拟真正完成后，不会再把同一段根节点位移重复采样一次。
                上一帧位置 = 当前 + 外部提交原始位移;
            }
            else
            {
                // 本物理帧没有生产者提交，必须发布0，避免搭乘者继续沿用上一帧位移。
                本帧位移增量_调试 = Vector2.zero;
                上一帧位置 = 当前;
            }

            外部提交原始位移 = Vector2.zero;
            外部提交待消费 = false;
            return;
        }

        Vector2 delta = 当前 - 上一帧位置;
        尝试同步2D物理变换(delta);
        上一帧位置 = 当前;
        本帧位移增量_调试 = 过滤可传递位移(delta);
    }

    /// <summary>
    /// 启用或关闭外部直接提交模式。切换模式时会重新同步位置基准并清空旧位移。
    /// </summary>
    public void 设置外部直接提交模式(bool 启用)
    {
        if (使用外部直接提交位移 == 启用 && 已初始化)
            return;

        使用外部直接提交位移 = 启用;
        自动补引用();
        上一帧位置 = 获取当前位置();
        本帧位移增量_调试 = Vector2.zero;
        外部提交原始位移 = Vector2.zero;
        外部提交待消费 = false;
        已初始化 = true;
    }

    /// <summary>
    /// 由载具移动脚本提交“本物理帧经过全部碰撞裁剪后的最终位移”。
    /// 调用后会自动启用外部直接提交模式，并立即发布给本物理帧稍后执行的搭乘者读取。
    /// </summary>
    public void 提交本物理帧位移(Vector2 最终位移)
    {
        if (!使用外部直接提交位移)
            设置外部直接提交模式(true);

        外部提交原始位移 = 最终位移;
        外部提交待消费 = true;
        本帧位移增量_调试 = 过滤可传递位移(最终位移);
    }

    /// <summary>
    /// 清空当前发布位移。用于载具停用、回池或瞬移前，避免搭乘者沿用旧数据。
    /// </summary>
    public void 清空本帧位移()
    {
        本帧位移增量_调试 = Vector2.zero;
        外部提交原始位移 = Vector2.zero;
        外部提交待消费 = false;
        上一帧位置 = 获取当前位置();
        已初始化 = true;
    }

    public bool 是否可搭乘碰撞器(Collider2D col)
    {
        if (col == null) return false;
        if (可搭乘碰撞器 == null) 自动补引用();

        if (可搭乘碰撞器 != null)
            return col == 可搭乘碰撞器;

        return col.transform == transform || col.transform.IsChildOf(transform);
    }

    private Vector2 过滤可传递位移(Vector2 delta)
    {
        if (最大可传递单帧位移 > 0f && delta.magnitude > 最大可传递单帧位移)
            return Vector2.zero;

        if (只传递水平位移)
            delta.y = 0f;

        return delta;
    }

    private void 尝试同步2D物理变换(Vector2 实际采样位移)
    {
        if (!位移后同步2D物理变换 || 实际采样位移.sqrMagnitude <= 0.0000000001f)
            return;

        int 当前渲染帧 = Time.frameCount;
        float 当前物理时间 = Time.fixedTime;

        if (上次同步所在渲染帧 == 当前渲染帧 && 上次同步所在物理时间 == 当前物理时间)
            return;

        Physics2D.SyncTransforms();
        上次同步所在渲染帧 = 当前渲染帧;
        上次同步所在物理时间 = 当前物理时间;
    }

    private void 自动补引用()
    {
        if (跟踪刚体 == null) 跟踪刚体 = GetComponent<Rigidbody2D>();
        if (跟踪目标 == null) 跟踪目标 = transform;
        if (可搭乘碰撞器 == null) 可搭乘碰撞器 = GetComponent<Collider2D>();
    }

    private Vector2 获取当前位置()
    {
        if (跟踪刚体 != null) return 跟踪刚体.position;
        if (跟踪目标 != null) return 跟踪目标.position;
        return transform.position;
    }
}
