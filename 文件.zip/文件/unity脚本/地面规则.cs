using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

public enum 地面规则类型
{
    我方地面 = 0,
    敌方地面 = 1,
    天花板 = 2,
    水面 = 3
}

public enum 水面规则类型
{
    非水面 = 0,
    浅水 = 1,
    深水 = 2
}

public enum 地面归属类型
{
    我方地面 = 0,
    敌方地面 = 1,
    双方地面 = 2,
    不可站 = 3
}

public enum 地面来源类型
{
    普通地面 = 0,
    废墟地面 = 1
}

[DisallowMultipleComponent]
[RequireComponent(typeof(Collider2D))]
public class 地面规则 : MonoBehaviour
{
    [Header("=== 地面身份 ===")]
    [Tooltip("地形大类。水面请选 水面；阵营/谁能站由下方 地面归属 决定。")]
    public 地面规则类型 地面类型 = 地面规则类型.我方地面;

    [Tooltip("站立归属：我方单位只能站 我方地面/双方地面；敌方单位可以站 我方地面/敌方地面/双方地面。深水/纯触发面可设为 不可站。")]
    public 地面归属类型 地面归属 = 地面归属类型.我方地面;

    public 水面规则类型 水面类型 = 水面规则类型.非水面;

    [Tooltip("用于区分地图普通地面和单位死亡后留下的废墟地面。废墟地面可站，但不会参与分岔推断；吸附裁决中普通地面优先于废墟地面。")]
    public 地面来源类型 地面来源 = 地面来源类型.普通地面;

    [Header("=== 站立 / 头顶阻挡 ===")]
    public bool 可作为脚下地面 = true;
    public bool 只允许从上方站立 = false;
    public bool 阻挡单位向上穿过 = false;

    [Header("=== 子弹规则 ===")]
    [Tooltip("新版方向阻挡：阻挡从世界上方往下飞来的子弹。当前先用于小米子弹new。")]
    public bool 阻挡上方子弹 = false;
    [Tooltip("新版方向阻挡：阻挡从世界下方往上飞来的子弹。当前先用于小米子弹new。")]
    public bool 阻挡下方子弹 = false;
    [Tooltip("新版方向阻挡：阻挡水平/近似水平飞来的侧向子弹。当前先用于小米子弹new。")]
    public bool 阻挡侧向子弹 = false;

    [Tooltip("新版内外阻挡：开启后，子弹朝本地内侧参考点飞来时才阻挡；从内侧往外飞时不阻挡。优先级高于上/下/侧向阻挡。")]
    public bool 阻挡外侧射入子弹 = false;

    [Tooltip("新版内外阻挡：用于判断哪里算地面内侧。坐标为本节点本地坐标，运行时会用 transform.TransformPoint 转成世界坐标。")]
    public Vector2 子弹内侧参考点本地偏移 = Vector2.zero;

    [Tooltip("新版内外阻挡：子弹方向与“命中点指向内侧参考点”的点积大于该值时，视为从外侧射入。")]
    public float 外侧射入判定阈值 = 0.05f;

    [Header("=== 子弹内侧参考点显示 ===")]
    [Tooltip("在 Scene 视图绘制子弹内侧参考点。仅在 阻挡外侧射入子弹=true 时绘制，避免普通地面刷屏；未选中本物体时也会显示。")]
    public bool 显示子弹内侧参考点 = true;

    [Tooltip("子弹内侧参考点十字线颜色。")]
    public Color 子弹内侧参考点颜色 = Color.cyan;

    [Min(0.01f), Tooltip("子弹内侧参考点十字线半径，单位为世界坐标。")]
    public float 子弹内侧参考点十字大小 = 0.25f;

    [Min(1f), Tooltip("子弹内侧参考点十字线粗细，仅在 Unity 编辑器 Scene 视图中生效。")]
    public float 子弹内侧参考点线宽 = 2f;

    [Tooltip("旧版总开关：暂时保留给尚未接入方向阻挡的旧子弹使用。")]

    public bool 阻挡子弹飞行 = true;//注意:这个参数不再使用,以后所有子弹/碎片或什么东西都不要检测这个参数了,已经不再使用了!!!
    public bool 阻挡子弹出生安全检测 = true;

    [Header("=== 水面特效规则 ===")]
    [Tooltip("水面视觉高度修正。用于水波/水花生成位置，水面身份统一由本脚本决定。")]
    public float 水面特效高度偏移 = 0f;
    public 水波特效大小 单位站立水波大小 = 水波特效大小.小;
    public 落水水花大小 单位落水水花大小 = 落水水花大小.不生成;
    public 落水水花大小 子弹命中水花大小 = 落水水花大小.不生成;

    [Header("=== 调试 ===")]
    public bool 输出调试日志 = false;

    private Collider2D[] 已注册碰撞器;

    public bool 是水面 => 地面类型 == 地面规则类型.水面 && 水面类型 != 水面规则类型.非水面;
    public bool 是浅水 => 地面类型 == 地面规则类型.水面 && 水面类型 == 水面规则类型.浅水;
    public bool 是深水 => 地面类型 == 地面规则类型.水面 && 水面类型 == 水面规则类型.深水;
    public bool 是废墟地面 => 地面来源 == 地面来源类型.废墟地面;
    public bool 是普通地面 => 地面来源 == 地面来源类型.普通地面;

    public bool 允许我方单位站立 => 可作为脚下地面 && (地面归属 == 地面归属类型.我方地面 || 地面归属 == 地面归属类型.双方地面);

    public bool 允许敌方单位站立 => 可作为脚下地面 && (地面归属 == 地面归属类型.我方地面 || 地面归属 == 地面归属类型.敌方地面 || 地面归属 == 地面归属类型.双方地面);

    public Vector2 获取子弹内侧参考点世界位置()
    {
        return transform.TransformPoint(子弹内侧参考点本地偏移);
    }

#if UNITY_EDITOR
    private void OnDrawGizmos()
    {
        绘制子弹内侧参考点十字线();
    }

    private void 绘制子弹内侧参考点十字线()
    {
        if (!显示子弹内侧参考点)
            return;

        if (!阻挡外侧射入子弹)
            return;

        float 半径 = Mathf.Max(0.01f, 子弹内侧参考点十字大小);
        float 线宽 = Mathf.Max(1f, 子弹内侧参考点线宽);
        Vector3 中心 = 获取子弹内侧参考点世界位置();

        Vector3 左 = 中心 + Vector3.left * 半径;
        Vector3 右 = 中心 + Vector3.right * 半径;
        Vector3 下 = 中心 + Vector3.down * 半径;
        Vector3 上 = 中心 + Vector3.up * 半径;

        Handles.color = 子弹内侧参考点颜色;
        Handles.DrawAAPolyLine(线宽, 左, 右);
        Handles.DrawAAPolyLine(线宽, 下, 上);
    }
#endif

    private void OnEnable()
    {
        注册本节点碰撞器();
    }

    private void OnDisable()
    {
        注销本节点碰撞器();
    }

    private void OnDestroy()
    {
        注销本节点碰撞器();
    }

    private void 注册本节点碰撞器()
    {
        注销本节点碰撞器();

        已注册碰撞器 = GetComponents<Collider2D>();
        if (已注册碰撞器 == null || 已注册碰撞器.Length == 0)
            return;

        for (int i = 0; i < 已注册碰撞器.Length; i++)
        {
            Collider2D col = 已注册碰撞器[i];
            if (col == null) continue;
            地面规则缓存.注册(col, this);
        }
    }

    private void 注销本节点碰撞器()
    {
        if (已注册碰撞器 == null)
            return;

        for (int i = 0; i < 已注册碰撞器.Length; i++)
        {
            Collider2D col = 已注册碰撞器[i];
            if (col == null) continue;
            地面规则缓存.注销(col, this);
        }

        已注册碰撞器 = null;
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        if (!Application.isPlaying)
            return;

        注册本节点碰撞器();
    }
#endif

    [ContextMenu("应用当前类型推荐默认值")]
    public void 应用当前类型推荐默认值()
    {
        switch (地面类型)
        {
            case 地面规则类型.我方地面:
                地面归属 = 地面归属类型.我方地面;
                水面类型 = 水面规则类型.非水面;
                可作为脚下地面 = true;
                阻挡单位向上穿过 = false;
                if (只允许从上方站立)
                {
                    阻挡上方子弹 = false;
                    阻挡下方子弹 = false;
                    阻挡侧向子弹 = false;
                    阻挡外侧射入子弹 = false;
                    子弹内侧参考点本地偏移 = Vector2.zero;
                    外侧射入判定阈值 = 0.05f;
                    阻挡子弹飞行 = false;
                    阻挡子弹出生安全检测 = false;
                }
                else
                {
                    阻挡上方子弹 = true;
                    阻挡下方子弹 = true;
                    阻挡侧向子弹 = false;
                    阻挡外侧射入子弹 = false;
                    子弹内侧参考点本地偏移 = Vector2.zero;
                    外侧射入判定阈值 = 0.05f;
                    阻挡子弹飞行 = true;
                    阻挡子弹出生安全检测 = true;
                }
                单位站立水波大小 = 水波特效大小.不生成;
                单位落水水花大小 = 落水水花大小.不生成;
                子弹命中水花大小 = 落水水花大小.不生成;
                break;

            case 地面规则类型.敌方地面:
                地面归属 = 地面归属类型.敌方地面;
                水面类型 = 水面规则类型.非水面;
                可作为脚下地面 = true;
                阻挡单位向上穿过 = false;
                if (只允许从上方站立)
                {
                    阻挡上方子弹 = false;
                    阻挡下方子弹 = false;
                    阻挡侧向子弹 = false;
                    阻挡外侧射入子弹 = false;
                    子弹内侧参考点本地偏移 = Vector2.zero;
                    外侧射入判定阈值 = 0.05f;
                    阻挡子弹飞行 = false;
                    阻挡子弹出生安全检测 = false;
                }
                else
                {
                    阻挡上方子弹 = true;
                    阻挡下方子弹 = true;
                    阻挡侧向子弹 = false;
                    阻挡外侧射入子弹 = false;
                    子弹内侧参考点本地偏移 = Vector2.zero;
                    外侧射入判定阈值 = 0.05f;
                    阻挡子弹飞行 = true;
                    阻挡子弹出生安全检测 = true;
                }
                单位站立水波大小 = 水波特效大小.不生成;
                单位落水水花大小 = 落水水花大小.不生成;
                子弹命中水花大小 = 落水水花大小.不生成;
                break;

            case 地面规则类型.天花板:
                地面归属 = 地面归属类型.不可站;
                水面类型 = 水面规则类型.非水面;
                可作为脚下地面 = false;
                只允许从上方站立 = false;
                阻挡单位向上穿过 = true;
                阻挡上方子弹 = true;
                阻挡下方子弹 = true;
                阻挡侧向子弹 = false;
                阻挡外侧射入子弹 = false;
                子弹内侧参考点本地偏移 = Vector2.zero;
                外侧射入判定阈值 = 0.05f;
                阻挡子弹飞行 = true;
                阻挡子弹出生安全检测 = true;
                单位站立水波大小 = 水波特效大小.不生成;
                单位落水水花大小 = 落水水花大小.不生成;
                子弹命中水花大小 = 落水水花大小.不生成;
                break;

            case 地面规则类型.水面:
                if (水面类型 == 水面规则类型.非水面)
                    水面类型 = 水面规则类型.浅水;

                if (水面类型 == 水面规则类型.深水)
                {
                    地面归属 = 地面归属类型.不可站;
                    可作为脚下地面 = false;
                    单位站立水波大小 = 水波特效大小.小;
                    单位落水水花大小 = 落水水花大小.中;
                }
                else
                {
                    if (地面归属 == 地面归属类型.不可站)
                        地面归属 = 地面归属类型.我方地面;
                    可作为脚下地面 = true;
                    // 地面只负责“不禁用单位水波”；实际大小可由单位自身覆盖。
                    单位站立水波大小 = 水波特效大小.小;
                    单位落水水花大小 = 落水水花大小.不生成;
                }

                只允许从上方站立 = false;
                阻挡单位向上穿过 = false;
                阻挡上方子弹 = false;
                阻挡下方子弹 = false;
                阻挡侧向子弹 = false;
                阻挡外侧射入子弹 = false;
                子弹内侧参考点本地偏移 = Vector2.zero;
                外侧射入判定阈值 = 0.05f;
                阻挡子弹飞行 = false;
                阻挡子弹出生安全检测 = false;
                break;
        }
    }
}
