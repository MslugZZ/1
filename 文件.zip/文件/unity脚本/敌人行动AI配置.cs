using System.Collections.Generic;
using UnityEngine;

public enum 敌人行动模式
{
    未激活待机,
    调位,
    战斗观察,
    左右游走,
    远程攻击,
    近战追击,
    近战攻击,

    后撤,
    跳跃,
    防御,

    专属1,
    专属2,
    专属3
}

[System.Serializable]
public class 敌人行动切换条目
{
    [Tooltip("自动同步显示用。修改 目标模式 后会自动变成目标模式名字。")]
    public string 名称 = "调位";

    public bool 启用 = true;

    [Tooltip("当前行动模式自然结束后，有概率切换到的目标模式。")]
    public 敌人行动模式 目标模式 = 敌人行动模式.调位;

    [Min(0f)]
    [Tooltip("不是百分比，而是权重。所有可用条目的权重相加后，按权重随机。")]
    public float 权重 = 1f;

    [Tooltip("调试用。勾选后，只要本条目启用且权重大于0，就优先选择它。多个强制项同时存在时，选列表里第一个。")]
    public bool 强制选择 = false;

    [Tooltip("勾选后，本条目被选中时输出日志。")]
    public bool 调试输出 = false;
}

[System.Serializable]
public class 敌人行动模式配置
{
    [Tooltip("自动同步显示用。修改 当前模式 后会自动变成当前模式名字。")]
    public string 名称 = "调位";

    public 敌人行动模式 当前模式 = 敌人行动模式.调位;

    public bool 启用 = true;

    [Tooltip("当前模式自然结束后，才会从这里选择下一个模式。不会在模式执行中途随机切换。")]
    public List<敌人行动切换条目> 切换模式列表 = new List<敌人行动切换条目>();

    [Tooltip("如果没有任何可用切换条目，就切到这个兜底模式，避免AI卡住。")]
    public 敌人行动模式 无可用切换时兜底模式 = 敌人行动模式.调位;

    public bool 输出切换调试日志 = false;
}

[System.Serializable]
public class 敌人行动AI配置
{
    [Tooltip("找不到对应模式配置时使用的全局兜底。")]
    public 敌人行动模式 全局兜底模式 = 敌人行动模式.调位;

    public bool 输出调试日志 = false;

    public List<敌人行动模式配置> 模式配置列表 = new List<敌人行动模式配置>();

    public 敌人行动模式配置 获取模式配置(敌人行动模式 模式)
    {
        if (模式配置列表 == null)
            return null;

        for (int i = 0; i < 模式配置列表.Count; i++)
        {
            敌人行动模式配置 配置 = 模式配置列表[i];
            if (配置 == null)
                continue;

            if (配置.当前模式 == 模式)
                return 配置;
        }

        return null;
    }
}