﻿using UnityEngine;

/// <summary>
/// 被击框规则与当前攻击配置组合后的查询结果。
/// 查询本身不会写入攻击来源或攻击属性；只有确认实际命中后才记录。
/// </summary>
public struct 被击框判定结果
{
    public Collider2D 碰撞体;
    public 被击框规则 规则;
    public 接收攻击数据接口 接收接口;
    public 受击反馈类型 受击反馈;
    public MonoBehaviour 被击音效类型覆盖;
    public 子弹命中响应 子弹响应;
    public bool 应当受伤;
    public bool 按规则应当阻挡;
}

/// <summary>
/// 所有移动子弹、范围攻击、近身攻击和索敌系统共用的被击框查询入口。
/// 命中热路径只查询全局缓存，不执行 GetComponent。
/// </summary>
public static class 被击框判定工具
{
    private const string 旧可刀被击框标签 = "可刀被击框";
    private const string 旧不可刀被击框标签 = "不可刀被击框";

    /// <summary>
    /// 迁移期兼容：普通攻击图层Collider没有规则时静默忽略；
    /// 只有仍使用旧被击框Tag的Collider缺少规则时才报告错误。
    /// 使用字符串比较而不是 CompareTag，避免旧Tag从Tag Manager删除后引发异常。
    /// </summary>
    private static bool 是否旧被击框标签(Collider2D 碰撞体)
    {
        if (碰撞体 == null)
            return false;

        string 标签 = 碰撞体.gameObject.tag;
        return 标签 == 旧可刀被击框标签 || 标签 == 旧不可刀被击框标签;
    }

    private static void 按旧标签报告缺失规则(Collider2D 碰撞体)
    {
        if (是否旧被击框标签(碰撞体))
            被击框规则日志.报告缺失规则一次(碰撞体);
    }

    /// <summary>
    /// Physics2D 查询结果可能在处理过程中变旧：例如同一次范围攻击的第一个部位
    /// 令敌人死亡并关闭整个被击框节点后，结果数组里仍然保存着其余 Collider2D 引用。
    /// 这种 Collider 并不是“缺少被击框规则”，只是已经不再参与当前物理/攻击判定，
    /// 因此必须在查询缓存之前静默忽略，避免产生误导性的缺失规则日志。
    /// </summary>
    private static bool 碰撞体当前参与规则判定(Collider2D 碰撞体)
    {
        if (碰撞体 == null)
            return false;

        if (!碰撞体.enabled)
            return false;

        if (!碰撞体.gameObject.activeInHierarchy)
            return false;

        return true;
    }

    public static bool 碰撞体位于攻击图层(Collider2D 碰撞体, LayerMask 攻击图层)
    {
        if (碰撞体 == null)
            return false;

        int layerBit = 1 << 碰撞体.gameObject.layer;
        return (攻击图层.value & layerBit) != 0;
    }

    /// <summary>
    /// 完整攻击判定入口：检查攻击数据中的攻击图层后，再读取被击框规则。
    /// 适合直接收到任意 Collider2D、尚未经过 Physics2D LayerMask 粗筛的调用者。
    /// </summary>
    public static bool 尝试判定(
        Collider2D 碰撞体,
        子弹数据 攻击数据文件,
        out 被击框判定结果 结果)
    {
        结果 = default(被击框判定结果);

        if (碰撞体 == null || 攻击数据文件 == null)
            return false;

        if (!碰撞体位于攻击图层(碰撞体, 攻击数据文件.攻击图层))
            return false;

        return 尝试判定已通过图层筛选(碰撞体, 攻击数据文件, out 结果);
    }

    /// <summary>
    /// 已完成图层粗筛后的攻击判定入口。
    /// 范围攻击、近身检测以及使用动态阵营图层的敌人攻击应调用本方法，
    /// 避免再次使用 子弹数据.攻击图层 覆盖调用者已经确定的实际攻击图层。
    /// </summary>
    public static bool 尝试判定已通过图层筛选(
        Collider2D 碰撞体,
        子弹数据 攻击数据文件,
        out 被击框判定结果 结果,
        bool 忽略近身响应要求 = false)
    {
        结果 = default(被击框判定结果);

        if (碰撞体 == null || 攻击数据文件 == null)
            return false;

        // 允许调用者传入“检测时有效、处理到这里时已经失效”的旧 Collider 引用。
        // 例如范围攻击第一个部位令敌人死亡并关闭被击框节点后，同一结果数组中的其余部位。
        if (!碰撞体当前参与规则判定(碰撞体))
            return false;

        被击框规则 规则;
        接收攻击数据接口 接收接口;
        if (!被击框规则缓存.尝试获取有效规则(碰撞体, out 规则, out 接收接口))
        {
            按旧标签报告缺失规则(碰撞体);
            return false;
        }

        if (!忽略近身响应要求 && 攻击数据文件.要求响应近身检测 && !规则.响应近身检测)
            return false;

        if (规则.子弹响应 == 子弹命中响应.完全忽略)
            return false;

        bool 应当受伤 =
            规则.子弹响应 == 子弹命中响应.穿透并受伤 ||
            规则.子弹响应 == 子弹命中响应.阻挡并受伤;

        bool 按规则应当阻挡 =
            规则.子弹响应 == 子弹命中响应.阻挡并受伤 ||
            规则.子弹响应 == 子弹命中响应.阻挡不受伤;

        结果 = new 被击框判定结果
        {
            碰撞体 = 碰撞体,
            规则 = 规则,
            接收接口 = 接收接口,
            受击反馈 = 规则.受击反馈脚本,
            被击音效类型覆盖 = 规则.被击音效类型覆盖脚本,
            子弹响应 = 规则.子弹响应,
            应当受伤 = 应当受伤,
            按规则应当阻挡 = 按规则应当阻挡
        };

        return true;
    }

    /// <summary>
    /// 给索敌或其他非攻击扫描使用。只读取有效规则，不读取子弹数据。
    /// </summary>
    public static bool 尝试获取有效规则(
        Collider2D 碰撞体,
        out 被击框规则 规则,
        bool 缺失时报告错误 = true)
    {
        规则 = null;

        // 索敌/预检测也可能持有上一物理步留下的 Collider 引用。
        // 已禁用或所在节点已关闭时属于正常失效，不应报告“规则缺失”。
        if (!碰撞体当前参与规则判定(碰撞体))
            return false;

        接收攻击数据接口 接收接口;
        if (被击框规则缓存.尝试获取有效规则(碰撞体, out 规则, out 接收接口))
            return true;

        if (缺失时报告错误)
            按旧标签报告缺失规则(碰撞体);

        return false;
    }

    /// <summary>
    /// 给敌人索敌系统使用：目标必须存在有效规则，并且允许作为索敌目标。
    /// 只查询全局缓存，不执行 GetComponent。
    /// </summary>
    public static bool 尝试获取可索敌规则(
        Collider2D 碰撞体,
        out 被击框规则 规则,
        bool 缺失时报告错误 = true)
    {
        if (!尝试获取有效规则(碰撞体, out 规则, 缺失时报告错误))
            return false;

        if (!规则.允许作为索敌目标)
        {
            规则 = null;
            return false;
        }

        return true;
    }

    /// <summary>
    /// 当前攻击是否应按被击框规则决定穿透和阻挡。
    /// 未开启时，具体攻击脚本继续保持自己的原有阻挡行为。
    /// </summary>
    public static bool 应使用规则控制穿透(
        子弹数据 攻击数据文件,
        被击框判定结果 结果)
    {
        if (攻击数据文件 == null)
            return false;

        return 攻击数据文件.使用被击框响应控制穿透;
    }

    /// <summary>
    /// 仅在已经确认实际命中后调用。
    /// 阻挡不受伤也属于实际命中，会记录来源和属性；完全忽略不会产生判定结果。
    /// </summary>
    public static void 记录实际命中(
        被击框判定结果 结果,
        攻击数据集 攻击数据)
    {
        if (结果.规则 == null)
            return;

        结果.规则.记录实际命中信息(攻击数据);
    }
}
