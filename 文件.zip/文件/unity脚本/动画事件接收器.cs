using UnityEngine;

public class 动画事件接收器 : MonoBehaviour
{
    public bool 动画已结束 { get; private set; }
    private Animator anim;

    // 监听目标（用 shortNameHash 匹配，够用；若你有同名状态在不同子状态机里，再告诉我我给你升级 fullPath 方案）
    private int 目标短名Hash;
    private bool 正在监听;
    private int 开始监听帧;

    void Awake()
    {
        anim = GetComponent<Animator>();
    }

    // 由 玩家控制器.播放动画() 调用：每次播放前重置并开始监听
    public void 准备监听(string 状态名)
    {
        动画已结束 = false;
        正在监听 = true;
        目标短名Hash = Animator.StringToHash(状态名);
        开始监听帧 = Time.frameCount;
    }

    public void 重置()
    {
        动画已结束 = false;
        正在监听 = false;
    }

    void LateUpdate()
    {
        if (!正在监听 || 动画已结束 || anim == null) return;
        if (anim.IsInTransition(0)) return;

        var info = anim.GetCurrentAnimatorStateInfo(0);

        // 只对“我们准备监听的那个状态”生效，避免误判
        if (info.shortNameHash != 目标短名Hash) return;

        // 兜底：非循环动画播放到末尾，强制判定结束
        // 加一帧延迟，避免刚Play就立刻判结束
        if (!info.loop && Time.frameCount > 开始监听帧 && info.normalizedTime >= 0.999f)
        {
            动画已结束 = true;
        }
    }

    // AnimationEvent 调用：仍然保留（它能更早触发结束）
    public void 触发动画结束()
    {
        if (anim != null)
        {
            var state = anim.GetCurrentAnimatorStateInfo(0);

            // 可选：不是当前监听目标就不认
            if (正在监听 && state.shortNameHash != 目标短名Hash) return;

            if (state.normalizedTime < 0.5f) return;
        }

        动画已结束 = true;
    }

    public void 直接触发动画结束()
    {
        动画已结束 = true;
    }
}