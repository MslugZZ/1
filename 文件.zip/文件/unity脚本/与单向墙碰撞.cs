using System.Collections.Generic;
using UnityEngine;

// 垂直：单向世界2D 线段扫掠 + 天花板BoxCast物理防穿透
// 水平：双射线 + 贴墙外移（改进版：仅主动撞击时触发单向墙推挤）
// 叠加：穿透墙点扫掠

[DisallowMultipleComponent]
[AddComponentMenu("合金弹头碰撞/与单向墙碰撞（终极修正版）")]
public class 与单向墙碰撞 : MonoBehaviour
{
    static readonly RaycastHit2D[] 天花板规则BoxCast缓存 = new RaycastHit2D[16];

    // Physics2D.SyncTransforms() 是全局操作。平台限定墙的重叠查询在同一个物理帧内
    // 只同步一次，避免玩家、坐骑和敌人数量较多时重复同步。
    static float 平台限定墙壁_上次同步物理时间 = float.NegativeInfinity;

    [Header("引用")]
    public Rigidbody2D 刚体;
    public BoxCollider2D 角色盒;

    [Header("角色体型")]
    public bool 使用盒碰撞器推断高度 = true;
    [Min(0.1f)] public float 角色身高 = 1.5f;
    public Vector2 脚点相对刚体偏移 = Vector2.zero;

    [Tooltip("可选：指定后，垂直扫掠/站在平台判定的脚底基准将优先使用这个点。\n建议拖入与你主控制器里的“地面检测点”同一个节点。留空则保持旧逻辑（碰撞器底边中心）。")]
    public Transform 脚底参考点;

    [Header("垂直（线段扫掠 + 天花板兜底）")]
    public int 最大迭代 = 4;
    public float 地面法线阈值 = 0.5f;
    public float 内部皮肤偏移 = 0.0001f;

    [Tooltip("向上跳跃时，额外检测天花板的物理图层（防止穿透细线）。请勾选'墙壁'或'地面'层")]
    public LayerMask 天花板检测图层;
    [Tooltip("新地面规则天花板过滤。为空时只要求 地面规则.阻挡单位向上穿过。")]
    public 地面检测规则文件 天花板地面检测规则;
    [Tooltip("天花板检测的额外距离（米），类似于皮肤厚度")]
    public float 天花板检测皮肤 = 0.02f;

    [Header("水平-墙壁（双射线 + 外移）")]
    [Tooltip("相邻两条水平射线之间的最大距离。越小射线越密，防漏判能力越强（推荐0.3~0.5）")]
    [Min(0.1f)] public float 最大水平射线间距 = 0.4f;
    [Tooltip("水平射线命中的图层（只勾'墙壁Layer'，不要勾地面/穿透墙）")]
    public LayerMask 水平射线图层;

    [Header("水平-平台限定墙壁")]
    [Tooltip("只在目标站在指定平台/地面上时才参与水平阻挡的墙壁图层。默认使用项目里的'平台限定墙壁'图层；如果以后改图层名或复用其它图层，可在面板里修改。")]
    public LayerMask 平台限定墙壁检测图层 = 0;

    [Tooltip("开启后，平台限定墙壁 Collider 必须挂 平台限定水平阻挡 组件；否则该 Collider 会被忽略，避免误把普通墙当成平台限定墙。")]
    public bool 平台限定墙壁_缺少组件时忽略 = true;

    [Tooltip("若'墙壁代理'是触发器，需勾上")]
    public bool 水平射线命中触发器 = false;

    [Tooltip("水平前向皮肤（米）：前向提前量 + 贴墙探针长度；贴墙时将外移至至少该距离")]
    [Min(0f)] public float 水平前向皮肤 = 0.03f;

    [Header("水平性能优化")]
    [Tooltip("勾选后，当传入的原始x移动量接近0时，直接跳过水平墙检测。\n适合大量普通敌人。玩家/坐骑如果没有把外部推动合并进原始x移动量，请保持关闭。")]
    public bool 零水平位移时跳过水平检测 = false;

    [Tooltip("勾选后保留旧版贴墙外移/卡墙推出探针。\n关闭后仍保留有水平移动时的防穿墙检测，但不会在静止或无对应方向位移时用水平前向皮肤反复探测。适合大量普通敌人。")]
    public bool 启用贴墙外移 = true;

    [Tooltip("小于等于这个绝对值时，视为没有水平位移。")]
    [Min(0f)] public float 水平零位移阈值 = 0.00001f;

    [Tooltip("贴墙外移关闭时，是否只在有实际位移的一侧使用水平前向皮肤。建议普通敌人开启；玩家/坐骑保持默认也不会改变旧行为。")]
    public bool 贴墙外移关闭时仅移动方向使用皮肤 = true;

    [Tooltip("为避免起点恰好贴在墙面上，射线起点沿反向微回退（米）")]
    [Min(0f)] public float 射线起点微回退 = 0.002f;

    [Tooltip("是否增加胸口第三条射线（提高台阶/边角稳定性）")]
    public bool 启用胸口射线 = false;
    [Range(0f, 1f)] public float 胸口高度比例 = 0.5f;

    [Tooltip("为左右水平射线整体在世界坐标中的Y轴偏移（米）。正值上移，负值下移。")]
    public float 水平射线Y轴偏移 = 0f;

    [Header("水平-穿透墙（用脚/头两点扫掠参与水平阻挡）")]
    [Tooltip("是否让'标记为穿透墙'的线段参与水平阻挡（子弹可穿）")]
    public bool 穿透墙参与水平阻挡 = true;

    [Header("屏幕边界过滤（垂直方向开关）")]
    [Tooltip("哪些Layer视为'屏幕边界'（一般勾'屏幕边界'层）")]
    public LayerMask 屏幕边界图层 = 0;

    [Tooltip("勾选后：垂直向上时若命中'屏幕边界层'的上边界，则忽略阻挡，允许继续上升（但真实墙壁仍会阻挡）")]
    public bool 忽略上方屏幕阻挡 = false;

    [Tooltip("勾选后：垂直向下时若命中'屏幕边界层'的下边界，则忽略阻挡，允许继续下落")]
    public bool 忽略下方屏幕阻挡 = false;

    [Header("单位屏幕边界内缩（虚拟提前阻挡）")]
    [Tooltip("上方屏幕边界提前多少米挡住本单位。0=使用真实上边界。仅当“不忽略上方屏幕阻挡”时生效。")]
    [Min(0f)] public float 上边界内缩距离 = 0f;

    [Tooltip("下方屏幕边界提前多少米挡住本单位。0=使用真实下边界。仅当“不忽略下方屏幕阻挡”时生效。")]
    [Min(0f)] public float 下边界内缩距离 = 0f;

    [Tooltip("左侧屏幕边界提前多少米挡住本单位。0=使用真实左边界。")]
    [Min(0f)] public float 左边界内缩距离 = 0f;

    [Tooltip("右侧屏幕边界提前多少米挡住本单位。0=使用真实右边界。")]
    [Min(0f)] public float 右边界内缩距离 = 0f;

    [Header("调试")]
    public bool 画水平射线 = true;
    public Color 贴墙探针色 = new Color(0.2f, 0.8f, 1f, 1f);

    [Header("动态底部水平射线")]
    [Tooltip("是否启用由外部脚本动态写入的底部水平射线上移")]
    public bool 启用底部射线动态抬高 = true;
    [Tooltip("外部写入的底部水平射线额外Y上移（米）")]
    [Min(0f)] public float 底部水平射线_动态额外Y抬高 = 0f;
    [Tooltip("保护上限：底部水平射线动态抬高不超过此值（米）")]
    [Min(0f)] public float 底部射线抬高上限 = 0.45f;

    [Header("水平夹紧挤死")]
    public bool 启用水平夹紧挤死 = true;
    [Min(0f)] public float 夹紧最小缩小量 = 0.001f;

    // 记录本帧射线的实际检测终点
    float _本帧左侧射线终点X;
    float _本帧右侧射线终点X;

    bool _本帧左侧墙命中;
    bool _本帧右侧墙命中;
    float _本帧左侧墙命中X;
    float _本帧右侧墙命中X;
    Transform _本帧左侧墙命中根;
    Transform _本帧右侧墙命中根;

    bool _本帧左侧穿透墙命中;
    bool _本帧右侧穿透墙命中;
    float _本帧左侧穿透墙命中X;
    float _本帧右侧穿透墙命中X;
    Transform _本帧左侧穿透墙命中根;
    Transform _本帧右侧穿透墙命中根;

    bool _夹紧_上帧有效;
    float _夹紧_上帧跨度;

    I脚下地面碰撞器 _平台限定墙壁_脚下地面提供者缓存;
    bool _平台限定墙壁_已查找脚下地面提供者;
    float _平台限定墙壁_本次预测Y偏移 = 0f;
    int _平台限定墙壁_本次屏幕边界内推方向 = 0;
    bool _平台限定墙壁_本次存在内部重叠 = false;
    float _平台限定墙壁_本次重叠分离X = 0f;
    float _平台限定墙壁_本次水平判定意图Dx = float.NaN;
    readonly List<Collider2D> _平台限定墙壁_本次内部脱出忽略碰撞体 = new List<Collider2D>(8);
    readonly List<平台限定水平阻挡> _平台限定墙壁_本次内部脱出忽略组件 = new List<平台限定水平阻挡>(8);

    readonly List<挤压来源候选> _夹紧候选缓存 = new List<挤压来源候选>(32);
    readonly List<Collider2D> _屏幕边界代理缓存 = new List<Collider2D>(8);

    public void 设置底部射线抬高(float 值)
    {
        if (!启用底部射线动态抬高) { 底部水平射线_动态额外Y抬高 = 0f; return; }
        底部水平射线_动态额外Y抬高 = Mathf.Clamp(值, 0f, 底部射线抬高上限);
    }

    void Reset()
    {
        刚体 = GetComponent<Rigidbody2D>();
        角色盒 = GetComponent<BoxCollider2D>();
        确保默认平台限定墙壁检测图层();
    }

    void OnValidate()
    {
        确保默认平台限定墙壁检测图层();
        _平台限定墙壁_已查找脚下地面提供者 = false;
        _平台限定墙壁_脚下地面提供者缓存 = null;
    }

    // —— 垂直 ——
    public float 计算安全垂直移动(float 理想y移动量, float 皮肤宽度, out bool isStandingOnPlatform)
    {
        return 计算安全垂直移动(理想y移动量, 皮肤宽度, out isStandingOnPlatform, default, null, null);
    }

    public float 计算安全垂直移动(float 理想y移动量, float 皮肤宽度, out bool isStandingOnPlatform, LayerMask 忽略线段图层)
    {
        return 计算安全垂直移动(理想y移动量, 皮肤宽度, out isStandingOnPlatform, 忽略线段图层, null, null);
    }

    public float 计算安全垂直移动(
        float 理想y移动量,
        float 皮肤宽度,
        out bool isStandingOnPlatform,
        LayerMask 忽略线段图层,
        地面检测规则文件 忽略线段地面检测规则,
        地面检测规则文件 地面线段检测规则)
    {
        if (!this.enabled || !this.gameObject.activeInHierarchy)
        {
            isStandingOnPlatform = false;
            return 理想y移动量;
        }

        isStandingOnPlatform = false;

        Vector2 脚 = 获取脚点世界();
        float 身高 = 获取身高();

        var 选项 = new 剪裁选项
        {
            最大迭代 = Mathf.Max(1, 最大迭代),
            皮肤 = Mathf.Max(皮肤宽度, 内部皮肤偏移),
            地面法线阈值 = 地面法线阈值,
            忽略线段图层 = 忽略线段图层,
            忽略线段地面检测规则 = 忽略线段地面检测规则,
            地面线段检测规则 = 地面线段检测规则
        };

        Vector2 位移 = new Vector2(0f, 理想y移动量);
        var 安全 = 单向世界2D.剪裁位移_两点(脚, 身高, 位移, 选项, out var 报告);
        float 最终Y = 安全.y;

        // 【核心修正：规避隐患二】向上飞且忽略上方屏幕阻挡时，强行覆盖数学阻挡结果，交由BoxCast兜底找真实墙壁
        if (忽略上方屏幕阻挡 && 理想y移动量 > 0f)
        {
            最终Y = 理想y移动量;
        }

        // 天花板物理防穿透（BoxCast兜底真实墙壁）
        if (理想y移动量 > 0 && 角色盒 != null && 天花板检测图层.value != 0)
        {
            // 【核心修正：规避隐患一】动态剥离屏幕边界，防止物理 BoxCast 的“双重拦截”
            LayerMask 实际天花板图层 = 天花板检测图层;
            if (忽略上方屏幕阻挡) 实际天花板图层 &= ~屏幕边界图层;

            float 检测距离 = 最终Y + 天花板检测皮肤;
            if (检测距离 > 0)
            {
                Vector2 盒中心 = 角色盒.bounds.center;
                Vector2 盒尺寸 = 角色盒.bounds.size;
                盒尺寸.x *= 0.9f;

                RaycastHit2D hit;
                if (尝试获取最近有效天花板阻挡命中(盒中心, 盒尺寸, 检测距离, 实际天花板图层, out hit))
                {
                    float 允许距离 = Mathf.Max(0f, hit.distance - 天花板检测皮肤);

                    if (允许距离 < 最终Y)
                        最终Y = 允许距离;
                }
            }
        }

        // 落地与平台判定
        if (报告.是否落地 && 报告.地面线段
            && 报告.地面线段.标记用途 == 代理用途.标记为地面
            && 报告.地方法线.y > 地面法线阈值)
        {
            isStandingOnPlatform = true;
        }

        // 下方屏幕边界过滤
        if (忽略下方屏幕阻挡 && 理想y移动量 < 0f && 报告.是否落地 && 报告.地面线段 != null)
        {
            var 段 = 报告.地面线段;
            int layer = 段.gameObject.layer;
            bool 是屏幕边界层 = (屏幕边界图层.value & (1 << layer)) != 0;

            if (是屏幕边界层 && 报告.地方法线.y > 0f)
            {
                isStandingOnPlatform = false;
                return 理想y移动量; // 允许穿透下边界
            }
        }

        最终Y = 应用屏幕边界内缩_垂直(最终Y, 理想y移动量, 皮肤宽度);

        return 最终Y;
    }

    private bool 尝试获取最近有效天花板阻挡命中(
        Vector2 盒中心,
        Vector2 盒尺寸,
        float 检测距离,
        LayerMask 图层,
        out RaycastHit2D 命中)
    {
        命中 = default;
        int 数量 = Physics2D.BoxCastNonAlloc(盒中心, 盒尺寸, 0f, Vector2.up, 天花板规则BoxCast缓存, 检测距离, 图层);
        float 最近 = float.PositiveInfinity;

        for (int i = 0; i < 数量 && i < 天花板规则BoxCast缓存.Length; i++)
        {
            RaycastHit2D hit = 天花板规则BoxCast缓存[i];
            if (!是否有效天花板阻挡命中(hit))
                continue;

            if (hit.distance < 最近)
            {
                最近 = hit.distance;
                命中 = hit;
            }
        }

        return 命中.collider != null;
    }

    private bool 是否有效天花板阻挡命中(RaycastHit2D hit)
    {
        if (hit.collider == null)
            return false;

        // 排除自己身上的碰撞器
        if (hit.collider.transform.root == transform.root)
            return false;

        // 新地面规则：直接挂在 EdgeCollider2D 同节点上的 地面规则 可以作为天花板。
        if (地面规则缓存.碰撞器阻挡单位向上穿过(hit.collider, 天花板地面检测规则))
            return true;

        // 旧墙壁/屏幕边界代理仍然保留，避免破坏现有墙壁系统。
        单向线段代理标记 tag = hit.collider.GetComponent<单向线段代理标记>();

        if (tag == null || tag.段 == null)
            return false;

        // 垂直线段是侧墙，不应该挡住向上跳跃 / 上升速度。
        if (tag.段.方向类型 != 线段方向.水平)
            return false;

        if (tag.是否双侧)
            return true;

        if (tag.阻挡法线.y <= -0.5f)
            return true;

        return false;
    }

    // —— 水平（保持原状，不受垂直开关影响） ——
    /// <summary>
    /// 仅用于“水平挤死关闭”的被动推动：把当前目标本次推动量裁到实际启用的屏幕边界。
    /// 只返回当前目标自己的修正结果，不修改挤压来源，也不处理普通墙壁。
    /// </summary>
    public float 裁剪被动水平推动到屏幕边界(float 原始推动位移, float 预测y偏移 = 0f)
    {
        if (!this.enabled || !this.gameObject.activeInHierarchy)
            return 原始推动位移;

        if (角色盒 == null)
            return 原始推动位移;

        float 零位移阈值 = Mathf.Max(0f, 水平零位移阈值);
        if (Mathf.Abs(原始推动位移) <= 零位移阈值)
            return 原始推动位移;

        Bounds 目标Bounds = 角色盒.bounds;
        目标Bounds.center += new Vector3(0f, 预测y偏移, 0f);

        if (原始推动位移 > 0f)
        {
            if (!尝试获取被动推动屏幕边界X(true, 目标Bounds, out float 右阻挡面X))
                return 原始推动位移;

            float 单位内缩 = Mathf.Max(0f, 右边界内缩距离);
            float 有效右边界X = 右阻挡面X - 单位内缩;
            float 剩余距离 = 有效右边界X - 目标Bounds.max.x;
            float 接触容差 = 获取被动推动屏幕边界接触容差(单位内缩);

            // 已贴边或已经轻微越界时，只停止继续向外推动，不把目标反向拉回。
            if (剩余距离 <= 接触容差)
                return 0f;

            return Mathf.Min(原始推动位移, 剩余距离);
        }
        else
        {
            if (!尝试获取被动推动屏幕边界X(false, 目标Bounds, out float 左阻挡面X))
                return 原始推动位移;

            float 单位内缩 = Mathf.Max(0f, 左边界内缩距离);
            float 有效左边界X = 左阻挡面X + 单位内缩;
            float 剩余距离 = 目标Bounds.min.x - 有效左边界X;
            float 接触容差 = 获取被动推动屏幕边界接触容差(单位内缩);

            // 已贴边或已经轻微越界时，只停止继续向外推动，不把目标反向拉回。
            if (剩余距离 <= 接触容差)
                return 0f;

            return -Mathf.Min(-原始推动位移, 剩余距离);
        }
    }

    /// <summary>
    /// 判断 计算安全水平移动 后新增的位移，是否来自当前启用的屏幕边界向屏内补推。
    /// 返回：+1=左边界向右补推，-1=右边界向左补推，0=不是屏幕边界补推。
    /// </summary>
    public int 获取本帧屏幕边界向内补推方向(
        float 原始尝试x移动量,
        float 墙后x移动量,
        float 预测y偏移 = 0f)
    {
        if (!this.enabled || !this.gameObject.activeInHierarchy)
            return 0;

        if (角色盒 == null)
            return 0;

        float eps = Mathf.Max(0.0001f, 水平零位移阈值);
        Bounds 目标Bounds = 角色盒.bounds;
        目标Bounds.center += new Vector3(0f, 预测y偏移, 0f);

        // 墙后结果比原始意图更向右，且玩家已贴住/越过左屏幕边界：
        // 这是左边界为了把玩家留在屏内而产生的向右补推。
        if (墙后x移动量 > 原始尝试x移动量 + eps)
        {
            if (尝试获取被动推动屏幕边界X(false, 目标Bounds, out float 左阻挡面X))
            {
                float 单位内缩 = Mathf.Max(0f, 左边界内缩距离);
                float 有效左边界X = 左阻挡面X + 单位内缩;
                float 当前间距 = 目标Bounds.min.x - 有效左边界X;
                float 接触容差 = 获取被动推动屏幕边界接触容差(单位内缩);

                if (当前间距 <= 接触容差)
                    return 1;
            }
        }

        // 墙后结果比原始意图更向左，且玩家已贴住/越过右屏幕边界：
        // 这是右边界为了把玩家留在屏内而产生的向左补推。
        if (墙后x移动量 < 原始尝试x移动量 - eps)
        {
            if (尝试获取被动推动屏幕边界X(true, 目标Bounds, out float 右阻挡面X))
            {
                float 单位内缩 = Mathf.Max(0f, 右边界内缩距离);
                float 有效右边界X = 右阻挡面X - 单位内缩;
                float 当前间距 = 有效右边界X - 目标Bounds.max.x;
                float 接触容差 = 获取被动推动屏幕边界接触容差(单位内缩);

                if (当前间距 <= 接触容差)
                    return -1;
            }
        }

        return 0;
    }

    public float 计算安全水平移动(float 原始x移动量, float 皮肤宽度, float 预测y偏移 = 0f, float 平台限定水平判定意图Dx = float.NaN)
    {
        重置本帧水平检测记录();

        if (!this.enabled || !this.gameObject.activeInHierarchy) return 原始x移动量;

        float dx = 原始x移动量;
        _平台限定墙壁_本次水平判定意图Dx = float.IsNaN(平台限定水平判定意图Dx) ? 原始x移动量 : 平台限定水平判定意图Dx;
        float 零位移阈值 = Mathf.Max(0f, 水平零位移阈值);

        // 性能优化：大量普通敌人静止时，不再因为 水平前向皮肤 每帧做左右贴墙探针。
        // 注意：默认关闭，不影响玩家/坐骑旧行为。
        // 即使世界位移为0，移动中的平台限定墙仍可能已经扫入目标，
        // 因此只在没有启用平台限定墙图层时才能完全跳过水平检测。
        if (零水平位移时跳过水平检测 &&
            Mathf.Abs(dx) <= 零位移阈值 &&
            平台限定墙壁检测图层.value == 0)
            return 原始x移动量;

        Vector2 脚 = 获取脚点世界() + Vector2.up * 预测y偏移;
        float 身高 = 获取身高();

        Vector2 yOffGlobal = new Vector2(0f, 水平射线Y轴偏移);
        float bottomDyn = (启用底部射线动态抬高 ? Mathf.Clamp(底部水平射线_动态额外Y抬高, 0f, 底部射线抬高上限) : 0f);

        Vector2 基础原点 = 脚 + yOffGlobal;

        _平台限定墙壁_本次预测Y偏移 = 预测y偏移;
        _平台限定墙壁_本次屏幕边界内推方向 = 平台限定墙壁_计算当前屏幕边界内推方向(预测y偏移);

        // 移动平台的阻挡框可能在本单位计算水平位移之前已经扫入角色。
        // 先处理这种“当前已重叠”的情况：朝墙方向/无相对位移时推出角色，
        // 朝外移动时才允许脱出。这里的判定意图必须是相对平台的主动意图，
        // 不能直接使用已叠加平台拖动后的世界位移。
        _平台限定墙壁_本次存在内部重叠 = 平台限定墙壁_刷新本次内部重叠状态(
            预测y偏移,
            _平台限定墙壁_本次水平判定意图Dx,
            皮肤宽度);

        float 右想走 = Mathf.Max(0f, dx);
        float 左想走 = Mathf.Max(0f, -dx);

        float 右许_墙 = 计算某侧允许距离_墙壁(基础原点, bottomDyn, 身高, Vector2.right, 右想走);
        float 左许_墙 = 计算某侧允许距离_墙壁(基础原点, bottomDyn, 身高, Vector2.left, 左想走);

        float 射线起点X = 基础原点.x;
        float 左射线长度 = 左想走 + 获取本次水平前向皮肤(左想走);
        float 右射线长度 = 右想走 + 获取本次水平前向皮肤(右想走);
        _本帧左侧射线终点X = 射线起点X - 左射线长度;
        _本帧右侧射线终点X = 射线起点X + 右射线长度;

        float 右许_穿 = 穿透墙参与水平阻挡 ? 计算某侧允许距离_穿透墙(基础原点, bottomDyn, 身高, Vector2.right, 右想走) : 右想走;
        float 左许_穿 = 穿透墙参与水平阻挡 ? 计算某侧允许距离_穿透墙(基础原点, bottomDyn, 身高, Vector2.left, 左想走) : 左想走;

        float 右允许 = Mathf.Min(右许_墙, 右许_穿);
        float 左允许 = Mathf.Min(左许_墙, 左许_穿);

        float dxClamped = Mathf.Clamp(dx, -左允许, 右允许);

        if (_平台限定墙壁_本次存在内部重叠)
        {
            // 已被移动阻挡框推入时，直接使用分离位移，不能把原始世界位移再叠加
            // 回去，否则会出现“平台向左推入 + 玩家向右输入”时仍继续向墙内走。
            return 应用屏幕边界内缩_水平(_平台限定墙壁_本次重叠分离X, 预测y偏移);
        }

        // 大量普通敌人可以关闭贴墙外移，只保留“有水平位移时防穿墙”。
        // 玩家/坐骑默认保持开启，旧行为不变。
        if (!启用贴墙外移)
            return 应用屏幕边界内缩_水平(dxClamped, 预测y偏移);

        float rightGap = 计算某侧贴墙缺口_墙壁(基础原点, bottomDyn, 身高, Vector2.right, dx);
        float leftGap = 计算某侧贴墙缺口_墙壁(基础原点, bottomDyn, 身高, Vector2.left, dx);
        float dxPushDesired = (leftGap - rightGap);

        float pushRightMax = 计算某侧自由空间_墙壁(基础原点, bottomDyn, 身高, Vector2.right, 水平前向皮肤);
        float pushLeftMax = 计算某侧自由空间_墙壁(基础原点, bottomDyn, 身高, Vector2.left, 水平前向皮肤);
        float dxPush = Mathf.Clamp(dxPushDesired, -pushLeftMax, pushRightMax);

        return 应用屏幕边界内缩_水平(dxClamped + dxPush, 预测y偏移);
    }

    void 重置本帧水平检测记录()
    {
        _本帧左侧墙命中 = false;
        _本帧右侧墙命中 = false;
        _本帧左侧墙命中X = float.NegativeInfinity;
        _本帧右侧墙命中X = float.PositiveInfinity;
        _本帧左侧墙命中根 = null;
        _本帧右侧墙命中根 = null;

        _本帧左侧穿透墙命中 = false;
        _本帧右侧穿透墙命中 = false;
        _本帧左侧穿透墙命中X = float.NegativeInfinity;
        _本帧右侧穿透墙命中X = float.PositiveInfinity;
        _本帧左侧穿透墙命中根 = null;
        _本帧右侧穿透墙命中根 = null;

        _本帧左侧射线终点X = float.NegativeInfinity;
        _本帧右侧射线终点X = float.PositiveInfinity;

        _平台限定墙壁_本次存在内部重叠 = false;
        _平台限定墙壁_本次重叠分离X = 0f;
        _平台限定墙壁_本次水平判定意图Dx = float.NaN;
    }

    float 获取本次水平前向皮肤(float 想走距离)
    {
        float skin = Mathf.Max(0f, 水平前向皮肤);
        if (skin <= 0f) return 0f;

        float 零位移阈值 = Mathf.Max(0f, 水平零位移阈值);
        if (Mathf.Abs(想走距离) > 零位移阈值)
            return skin;

        // 旧行为：贴墙外移开启时，即使本侧没有移动，也使用 skin 做贴墙/零距离探针。
        if (启用贴墙外移)
            return skin;

        // 优化行为：贴墙外移关闭时，没有实际位移的一侧不再使用 skin 反复探测。
        if (贴墙外移关闭时仅移动方向使用皮肤)
            return 0f;

        return skin;
    }

    float 计算某侧允许距离_墙壁(Vector2 基础原点, float 抬高量, float 身高, Vector2 方向, float 想走距离)
    {
        float 本侧皮肤 = 获取本次水平前向皮肤(想走距离);
        float 长度 = 想走距离 + 本侧皮肤;
        if (长度 <= 1e-6f) return 0f;
        float 最近 = float.PositiveInfinity;

        Vector2 脚_偏 = 基础原点 + new Vector2(0f, 抬高量);
        float 本侧移动意图 = 方向.x * Mathf.Max(0f, 想走距离);
        最近 = Mathf.Min(最近, 水平打一根(脚_偏, 方向, 长度, false, false, 本侧移动意图));

        int 段数 = Mathf.CeilToInt(身高 / 最大水平射线间距);
        if (段数 < 1) 段数 = 1;
        float 实际间距 = 身高 / 段数;

        for (int i = 1; i <= 段数; i++)
        {
            Vector2 检测点 = 基础原点 + Vector2.up * (实际间距 * i);
            最近 = Mathf.Min(最近, 水平打一根(检测点, 方向, 长度, false, false, 本侧移动意图));
        }

        if (float.IsPositiveInfinity(最近)) return 想走距离;
        float 允许 = Mathf.Max(0f, 最近 - 本侧皮肤);
        return Mathf.Min(允许, 想走距离);
    }

    float 计算某侧允许距离_穿透墙(Vector2 基础原点, float 抬高量, float 身高, Vector2 方向, float 想走距离)
    {
        float 本侧皮肤 = 获取本次水平前向皮肤(想走距离);
        float 长度 = 想走距离 + 本侧皮肤;
        if (长度 <= 1e-6f) return 0f;

        float 最早t = float.PositiveInfinity;
        命中信息 最近命中 = default;
        bool 命 = false;

        System.Predicate<单向线段2D> 过滤 = seg => {
            if (!seg || !seg.isActiveAndEnabled || !seg.启用) return false;
            return seg.标记用途 == 代理用途.标记为穿透墙;
        };

        Vector2 脚_偏 = 基础原点 + new Vector2(0f, 抬高量);
        if (单向世界2D.扫掠点(脚_偏, 脚_偏 + 方向 * 长度, out var hf, 过滤))
        {
            if (hf.t < 最早t) { 最早t = hf.t; 最近命中 = hf; }
            命 = true;
        }

        int 段数 = Mathf.CeilToInt(身高 / 最大水平射线间距);
        if (段数 < 1) 段数 = 1;
        float 实际间距 = 身高 / 段数;

        for (int i = 1; i <= 段数; i++)
        {
            Vector2 检测点 = 基础原点 + Vector2.up * (实际间距 * i);
            if (单向世界2D.扫掠点(检测点, 检测点 + 方向 * 长度, out var hh, 过滤))
            {
                if (hh.t < 最早t) { 最早t = hh.t; 最近命中 = hh; }
                命 = true;
            }
        }

        if (!命) return 想走距离;

        if (方向.x < 0f)
        {
            _本帧左侧穿透墙命中 = true;
            float hitX = 最近命中.点.x;
            if (hitX > _本帧左侧穿透墙命中X)
            {
                _本帧左侧穿透墙命中X = hitX;
                _本帧左侧穿透墙命中根 = 最近命中.线段 ? 最近命中.线段.transform.root : null;
            }
        }
        else
        {
            _本帧右侧穿透墙命中 = true;
            float hitX = 最近命中.点.x;
            if (hitX < _本帧右侧穿透墙命中X)
            {
                _本帧右侧穿透墙命中X = hitX;
                _本帧右侧穿透墙命中根 = 最近命中.线段 ? 最近命中.线段.transform.root : null;
            }
        }

        float 命中距离 = 最早t * 长度;
        float 允许 = Mathf.Max(0f, 命中距离 - 本侧皮肤);
        return Mathf.Min(允许, 想走距离);
    }

    float 计算某侧贴墙缺口_墙壁(Vector2 基础原点, float 抬高量, float 身高, Vector2 方向, float Dx)
    {
        float 长度 = Mathf.Max(0f, 水平前向皮肤);
        if (长度 <= 1e-6f) return 0f;
        float 最近 = float.PositiveInfinity;

        Vector2 脚_偏 = 基础原点 + new Vector2(0f, 抬高量);
        最近 = Mathf.Min(最近, 水平打一根(脚_偏, 方向, 长度, true, true, Dx));

        int 段数 = Mathf.CeilToInt(身高 / 最大水平射线间距);
        if (段数 < 1) 段数 = 1;
        float 实际间距 = 身高 / 段数;

        for (int i = 1; i <= 段数; i++)
        {
            Vector2 检测点 = 基础原点 + Vector2.up * (实际间距 * i);
            最近 = Mathf.Min(最近, 水平打一根(检测点, 方向, 长度, true, true, Dx));
        }

        if (float.IsPositiveInfinity(最近)) return 0f;
        if (最近 >= 水平前向皮肤) return 0f;
        return Mathf.Max(0f, 水平前向皮肤 - 最近);
    }

    float 计算某侧自由空间_墙壁(Vector2 基础原点, float 抬高量, float 身高, Vector2 方向, float 检测长度)
    {
        float 长度 = Mathf.Max(0f, 检测长度);
        if (长度 <= 1e-6f) return 0f;
        float 最近 = float.PositiveInfinity;

        Vector2 脚_偏 = 基础原点 + new Vector2(0f, 抬高量);
        // 自由空间只用于贴墙外移可用距离，不应让平台限定墙壁参与。
        // 普通单向墙在 drawAsProbe=false 时不依赖移动意图；平台限定墙壁会在移动意图为0时被忽略。
        float 本侧移动意图 = 0f;
        最近 = Mathf.Min(最近, 水平打一根(脚_偏, 方向, 长度, false, false, 本侧移动意图));

        int 段数 = Mathf.CeilToInt(身高 / 最大水平射线间距);
        if (段数 < 1) 段数 = 1;
        float 实际间距 = 身高 / 段数;

        for (int i = 1; i <= 段数; i++)
        {
            Vector2 检测点 = 基础原点 + Vector2.up * (实际间距 * i);
            最近 = Mathf.Min(最近, 水平打一根(检测点, 方向, 长度, false, false, 本侧移动意图));
        }

        if (float.IsPositiveInfinity(最近)) return 长度;
        return Mathf.Max(0f, 最近);
    }

    int 获取实际水平射线图层()
    {
        return 水平射线图层.value | 平台限定墙壁检测图层.value;
    }

    void 确保默认平台限定墙壁检测图层()
    {
        if (平台限定墙壁检测图层.value != 0) return;
        int layer = LayerMask.NameToLayer("平台限定墙壁");
        if (layer >= 0)
            平台限定墙壁检测图层 = 1 << layer;
    }

    bool 是平台限定水平墙图层(Collider2D 候选)
    {
        if (候选 == null) return false;
        return 图层在Mask内(平台限定墙壁检测图层.value, 候选.gameObject.layer);
    }

    平台限定水平阻挡 获取平台限定水平阻挡(Collider2D 候选)
    {
        if (候选 == null) return null;
        平台限定水平阻挡 限定 = 候选.GetComponent<平台限定水平阻挡>();
        if (限定 == null)
            限定 = 候选.GetComponentInParent<平台限定水平阻挡>();
        return 限定;
    }

    I脚下地面碰撞器 获取平台限定墙壁脚下地面提供者()
    {
        if (_平台限定墙壁_已查找脚下地面提供者)
            return _平台限定墙壁_脚下地面提供者缓存;

        _平台限定墙壁_已查找脚下地面提供者 = true;
        _平台限定墙壁_脚下地面提供者缓存 = GetComponent<I脚下地面碰撞器>();

        if (_平台限定墙壁_脚下地面提供者缓存 == null)
            _平台限定墙壁_脚下地面提供者缓存 = GetComponentInParent<I脚下地面碰撞器>();

        if (_平台限定墙壁_脚下地面提供者缓存 == null)
            _平台限定墙壁_脚下地面提供者缓存 = GetComponentInChildren<I脚下地面碰撞器>();

        return _平台限定墙壁_脚下地面提供者缓存;
    }

    public bool 平台限定水平阻挡_允许作为水平墙(Collider2D 候选, Vector2 水平方向, float 水平移动意图Dx)
    {
        if (候选 == null) return false;
        if (!是平台限定水平墙图层(候选)) return true;

        平台限定水平阻挡 限定 = 获取平台限定水平阻挡(候选);
        if (限定 == null)
            return !平台限定墙壁_缺少组件时忽略;

        I脚下地面碰撞器 脚下地面提供者 = 获取平台限定墙壁脚下地面提供者();
        if (!限定.目标脚下满足(脚下地面提供者))
            return false;

        float 判定方向 = 平台限定墙壁_获取水平判定方向(水平方向, 水平移动意图Dx);
        float eps = Mathf.Max(0.000001f, 水平零位移阈值);

        // 关键：平台限定墙壁只在“当前水平射线方向”和“本帧水平移动意图”一致时参与阻挡。
        // 已经嵌入阻挡体但朝外移动时，朝外方向的射线不会命中阻挡体；即使其它贴墙探针命中，也会因为方向不一致或无意图而被忽略。
        if (Mathf.Abs(判定方向) <= eps)
            return false;

        if (Mathf.Sign(判定方向) != Mathf.Sign(水平方向.x))
            return false;

        // 摄像机/屏幕边界向屏内推回时优先级最高，平台限定墙壁不能把单位挡在屏幕外。
        if (_平台限定墙壁_本次屏幕边界内推方向 != 0 &&
            Mathf.Sign(判定方向) == _平台限定墙壁_本次屏幕边界内推方向)
            return false;

        return true;
    }

    public bool 平台限定水平阻挡_当前目标已在内部(Collider2D 候选)
    {
        // 平台限定墙壁不再使用目标自身碰撞器 Bounds 做“已在内部”判断。
        // 是否阻挡完全交给水平射线命中决定，避免身体重叠但射线朝外时仍被误拦。
        return false;
    }

    float 平台限定墙壁_获取水平判定方向(Vector2 水平方向, float 水平移动意图Dx)
    {
        float eps = Mathf.Max(0.000001f, 水平零位移阈值);
        if (!float.IsNaN(_平台限定墙壁_本次水平判定意图Dx) && Mathf.Abs(_平台限定墙壁_本次水平判定意图Dx) > eps)
            return _平台限定墙壁_本次水平判定意图Dx;
        if (Mathf.Abs(水平移动意图Dx) > eps)
            return 水平移动意图Dx;
        // 没有主动/相对水平意图时，不让平台拖动本身触发平台限定墙的射线阻挡；
        // 移动阻挡框扫入目标的情况由 Bounds 重叠分离逻辑处理。
        return 0f;
    }

    bool 平台限定墙壁_尝试获取目标Bounds(out Bounds 目标Bounds)
    {
        BoxCollider2D 盒 = 角色盒;
        if (盒 == null)
            盒 = GetComponent<BoxCollider2D>();
        if (盒 == null)
            盒 = GetComponentInParent<BoxCollider2D>();
        if (盒 == null)
            盒 = GetComponentInChildren<BoxCollider2D>();

        if (盒 == null || !盒.enabled || !盒.gameObject.activeInHierarchy)
        {
            目标Bounds = default;
            return false;
        }

        目标Bounds = 盒.bounds;
        if (Mathf.Abs(_平台限定墙壁_本次预测Y偏移) > 0.000001f)
            目标Bounds.center += new Vector3(0f, _平台限定墙壁_本次预测Y偏移, 0f);
        return true;
    }

    void 平台限定墙壁_清空本次内部脱出忽略列表()
    {
        _平台限定墙壁_本次内部脱出忽略碰撞体.Clear();
        _平台限定墙壁_本次内部脱出忽略组件.Clear();
    }

    bool 平台限定墙壁_本次应忽略内部脱出墙(Collider2D 候选)
    {
        if (候选 == null) return false;

        for (int i = 0; i < _平台限定墙壁_本次内部脱出忽略碰撞体.Count; i++)
        {
            if (_平台限定墙壁_本次内部脱出忽略碰撞体[i] == 候选)
                return true;
        }

        平台限定水平阻挡 限定 = 获取平台限定水平阻挡(候选);
        if (限定 == null) return false;

        for (int i = 0; i < _平台限定墙壁_本次内部脱出忽略组件.Count; i++)
        {
            if (_平台限定墙壁_本次内部脱出忽略组件[i] == 限定)
                return true;
        }

        return false;
    }

    void 平台限定墙壁_记录本次内部脱出忽略(Collider2D 碰撞体, 平台限定水平阻挡 限定)
    {
        if (碰撞体 != null && !_平台限定墙壁_本次内部脱出忽略碰撞体.Contains(碰撞体))
            _平台限定墙壁_本次内部脱出忽略碰撞体.Add(碰撞体);

        if (限定 != null && !_平台限定墙壁_本次内部脱出忽略组件.Contains(限定))
            _平台限定墙壁_本次内部脱出忽略组件.Add(限定);
    }

    bool 平台限定墙壁_刷新本次内部重叠状态(float 预测y偏移, float 水平判定Dx, float 皮肤宽度)
    {
        平台限定墙壁_清空本次内部脱出忽略列表();
        _平台限定墙壁_本次重叠分离X = 0f;

        if (平台限定墙壁检测图层.value == 0)
            return false;

        float 旧预测 = _平台限定墙壁_本次预测Y偏移;
        _平台限定墙壁_本次预测Y偏移 = 预测y偏移;

        bool 有目标Bounds = 平台限定墙壁_尝试获取目标Bounds(out Bounds 目标Bounds);
        _平台限定墙壁_本次预测Y偏移 = 旧预测;

        if (!有目标Bounds)
            return false;

        平台限定墙壁_同步2D物理变换();
        Collider2D[] 命中 = Physics2D.OverlapBoxAll(目标Bounds.center, 目标Bounds.size, 0f, 平台限定墙壁检测图层);
        if (命中 == null || 命中.Length == 0)
            return false;

        I脚下地面碰撞器 脚下地面提供者 = 获取平台限定墙壁脚下地面提供者();
        float eps = Mathf.Max(0.000001f, 水平零位移阈值);
        float 判定Dx = float.IsNaN(水平判定Dx) ? 0f : 水平判定Dx;
        float 分离皮肤 = Mathf.Max(0f, Mathf.Max(皮肤宽度, 内部皮肤偏移));
        float 左侧最大分离 = 0f;
        float 右侧最大分离 = 0f;

        for (int i = 0; i < 命中.Length; i++)
        {
            Collider2D col = 命中[i];
            if (col == null || !col.enabled || !col.gameObject.activeInHierarchy) continue;
            if (!是平台限定水平墙图层(col)) continue;
            if (col.transform.root == transform.root) continue;

            平台限定水平阻挡 限定 = 获取平台限定水平阻挡(col);
            if (限定 == null)
            {
                if (平台限定墙壁_缺少组件时忽略)
                    continue;
            }
            else if (!限定.目标脚下满足(脚下地面提供者))
            {
                continue;
            }

            Bounds 阻挡Bounds = col.bounds;
            if (!目标Bounds.Intersects(阻挡Bounds))
                continue;

            // 已经嵌入平台限定墙时，只有朝墙外的相对位移才允许脱出。
            // 无相对位移不能被当作“脱出”，因为这正是移动阻挡框扫入目标的情况。
            if (限定 != null && 限定.当前重叠时允许水平脱出(目标Bounds, 阻挡Bounds, 判定Dx))
            {
                平台限定墙壁_记录本次内部脱出忽略(col, 限定);
                continue;
            }

            float 中心差 = 目标Bounds.center.x - 阻挡Bounds.center.x;
            bool 目标在阻挡左侧 = 中心差 < -eps || (Mathf.Abs(中心差) <= eps && 判定Dx >= 0f);

            if (目标在阻挡左侧)
            {
                // 目标在墙左侧，向左推出到墙的左表面外；结果为负值。
                float 分离量 = 阻挡Bounds.min.x - 目标Bounds.max.x - 分离皮肤;
                if (分离量 < 左侧最大分离)
                    左侧最大分离 = 分离量;
            }
            else
            {
                // 目标在墙右侧，向右推出到墙的右表面外；结果为正值。
                float 分离量 = 阻挡Bounds.max.x - 目标Bounds.min.x + 分离皮肤;
                if (分离量 > 右侧最大分离)
                    右侧最大分离 = 分离量;
            }
        }

        bool 有左侧分离 = 左侧最大分离 < -eps;
        bool 有右侧分离 = 右侧最大分离 > eps;

        if (有左侧分离 && 有右侧分离)
        {
            // 两侧同时夹住时，优先沿本帧相对移动方向处理；没有方向时选较小的分离量，
            // 避免把目标一次性推出更远的一侧。
            if (判定Dx > eps)
                _平台限定墙壁_本次重叠分离X = 左侧最大分离;
            else if (判定Dx < -eps)
                _平台限定墙壁_本次重叠分离X = 右侧最大分离;
            else
                _平台限定墙壁_本次重叠分离X =
                    Mathf.Abs(左侧最大分离) <= Mathf.Abs(右侧最大分离)
                        ? 左侧最大分离
                        : 右侧最大分离;
        }
        else if (有左侧分离)
        {
            _平台限定墙壁_本次重叠分离X = 左侧最大分离;
        }
        else if (有右侧分离)
        {
            _平台限定墙壁_本次重叠分离X = 右侧最大分离;
        }

        return Mathf.Abs(_平台限定墙壁_本次重叠分离X) > eps;
    }

    static void 平台限定墙壁_同步2D物理变换()
    {
        if (平台限定墙壁_上次同步物理时间 == Time.fixedTime)
            return;

        Physics2D.SyncTransforms();
        平台限定墙壁_上次同步物理时间 = Time.fixedTime;
    }

    bool 平台限定墙壁_当前存在有效内部重叠(float 预测y偏移)
    {
        if (平台限定墙壁检测图层.value == 0)
            return false;

        float 旧预测 = _平台限定墙壁_本次预测Y偏移;
        _平台限定墙壁_本次预测Y偏移 = 预测y偏移;

        bool 有目标Bounds = 平台限定墙壁_尝试获取目标Bounds(out Bounds 目标Bounds);
        _平台限定墙壁_本次预测Y偏移 = 旧预测;

        if (!有目标Bounds)
            return false;

        Collider2D[] 命中 = Physics2D.OverlapBoxAll(目标Bounds.center, 目标Bounds.size, 0f, 平台限定墙壁检测图层);
        if (命中 == null || 命中.Length == 0)
            return false;

        I脚下地面碰撞器 脚下地面提供者 = 获取平台限定墙壁脚下地面提供者();
        for (int i = 0; i < 命中.Length; i++)
        {
            Collider2D col = 命中[i];
            if (col == null || !col.enabled || !col.gameObject.activeInHierarchy) continue;
            if (!是平台限定水平墙图层(col)) continue;

            平台限定水平阻挡 限定 = 获取平台限定水平阻挡(col);
            if (限定 == null)
            {
                if (平台限定墙壁_缺少组件时忽略)
                    continue;
            }
            else if (!限定.目标脚下满足(脚下地面提供者))
            {
                continue;
            }

            if (目标Bounds.Intersects(col.bounds))
                return true;
        }

        return false;
    }

    int 平台限定墙壁_计算当前屏幕边界内推方向(float 预测y偏移)
    {
        if (!平台限定墙壁_尝试获取目标Bounds(out Bounds 目标Bounds))
            return 0;

        bool 左侧需要内推 = false;
        bool 右侧需要内推 = false;

        if (尝试获取被动推动屏幕边界X(false, 目标Bounds, out float 左阻挡面X))
        {
            float 单位内缩 = Mathf.Max(0f, 左边界内缩距离);
            float 有效左边界X = 左阻挡面X + 单位内缩;
            float 当前间距 = 目标Bounds.min.x - 有效左边界X;
            float 接触容差 = 获取被动推动屏幕边界接触容差(单位内缩);
            左侧需要内推 = 当前间距 <= 接触容差;
        }

        if (尝试获取被动推动屏幕边界X(true, 目标Bounds, out float 右阻挡面X))
        {
            float 单位内缩 = Mathf.Max(0f, 右边界内缩距离);
            float 有效右边界X = 右阻挡面X - 单位内缩;
            float 当前间距 = 有效右边界X - 目标Bounds.max.x;
            float 接触容差 = 获取被动推动屏幕边界接触容差(单位内缩);
            右侧需要内推 = 当前间距 <= 接触容差;
        }

        if (左侧需要内推 && !右侧需要内推) return 1;
        if (右侧需要内推 && !左侧需要内推) return -1;
        return 0;
    }

    float 水平打一根(Vector2 起点, Vector2 方向, float 长度, bool drawAsProbe, bool acceptZero, float 移动意图Dx)
    {
        Vector2 s = 起点 - 方向 * 射线起点微回退;
        var hits = Physics2D.RaycastAll(s, 方向, 长度, 获取实际水平射线图层());
        float best = float.PositiveInfinity;
        Vector2 bestPoint = Vector2.zero;
        Transform bestRoot = null;

        foreach (var h in hits)
        {
            if (h.collider == null) continue;

            bool 屏幕边界 = 是屏幕边界(h.collider);
            bool 平台限定墙壁 = 是平台限定水平墙图层(h.collider);

            // 贴墙外移/贴墙缺口探针不应该让平台限定墙壁参与。
            // 平台限定墙壁只在真正的水平移动射线命中时阻挡。
            if (平台限定墙壁 && drawAsProbe) continue;

            if (!水平射线命中触发器 && h.collider.isTrigger && !屏幕边界) continue;
            if (!平台限定水平阻挡_允许作为水平墙(h.collider, 方向, 移动意图Dx)) continue;
            if (平台限定墙壁 && 平台限定墙壁_本次应忽略内部脱出墙(h.collider)) continue;
            // 平台限定墙壁不接受零距离命中：零距离通常表示射线起点已贴入/重叠，不能用来裁掉朝外脱出的位移。
            if (!(acceptZero || 屏幕边界) && h.distance <= 1e-6f) continue;

            var tag = h.collider.GetComponent<单向线段代理标记>();
            bool 使用普通单向墙规则 = tag != null && tag.段 != null;

            if (!使用普通单向墙规则 && !平台限定墙壁) continue;

            if (使用普通单向墙规则)
            {
                if (!是否阻挡(tag, s, 方向)) continue;

                if (!tag.是否双侧 && drawAsProbe && !屏幕边界)
                {
                    bool 正在主动撞墙 =
                        (Mathf.Abs(移动意图Dx) > 1e-6f) &&
                        (Mathf.Sign(方向.x) == Mathf.Sign(移动意图Dx));

                    if (!正在主动撞墙) continue;
                }
            }

            if (h.distance < best)
            {
                best = h.distance;
                bestPoint = h.point;
                bestRoot = 使用普通单向墙规则 && tag.段 ? tag.段.transform.root : h.collider.transform.root;
            }
        }

        if (!drawAsProbe && best < float.PositiveInfinity)
        {
            if (方向.x < 0f)
            {
                _本帧左侧墙命中 = true;
                if (bestPoint.x > _本帧左侧墙命中X)
                {
                    _本帧左侧墙命中X = bestPoint.x;
                    _本帧左侧墙命中根 = bestRoot;
                }
            }
            else
            {
                _本帧右侧墙命中 = true;
                if (bestPoint.x < _本帧右侧墙命中X)
                {
                    _本帧右侧墙命中X = bestPoint.x;
                    _本帧右侧墙命中根 = bestRoot;
                }
            }
        }

        if (画水平射线)
        {
            var col = best < float.PositiveInfinity
                ? (drawAsProbe ? 贴墙探针色 : Color.red)
                : (drawAsProbe ? new Color(0.4f, 0.9f, 1f, 1f) : Color.green);
            Debug.DrawRay(s, 方向 * 长度, col, 0.02f);
        }

        return best;
    }

    bool 是否阻挡(单向线段代理标记 tag, Vector2 s, Vector2 dir)
    {
        if (tag.是否双侧) return true;
        Vector2 n = tag.阻挡法线.normalized;
        if (Vector2.Dot(dir, n) >= 0f) return false;
        Vector2 A = tag.段.世界A;
        float d0 = Vector2.Dot(s - A, n);
        if (d0 <= 0f) return false;
        return true;
    }

    float 应用屏幕边界内缩_垂直(float 当前Y移动量, float 理想Y移动量, float 皮肤宽度)
    {
        if (角色盒 == null)
            return 当前Y移动量;

        if (理想Y移动量 > 0f)
        {
            float 内缩 = Mathf.Max(0f, 上边界内缩距离);
            if (内缩 > 0f && !忽略上方屏幕阻挡 &&
                尝试获取最近屏幕边界Y(true, 角色盒.bounds, out float 上边界Y))
            {
                float 允许Y = Mathf.Max(0f, 上边界Y - 内缩 - 角色盒.bounds.max.y - Mathf.Max(0f, 皮肤宽度));
                if (当前Y移动量 > 允许Y)
                    当前Y移动量 = 允许Y;
            }
        }
        else if (理想Y移动量 < 0f)
        {
            float 内缩 = Mathf.Max(0f, 下边界内缩距离);
            if (内缩 > 0f && !忽略下方屏幕阻挡 &&
                尝试获取最近屏幕边界Y(false, 角色盒.bounds, out float 下边界Y))
            {
                float 允许Y = Mathf.Min(0f, 下边界Y + 内缩 - 角色盒.bounds.min.y + Mathf.Max(0f, 皮肤宽度));
                if (当前Y移动量 < 允许Y)
                    当前Y移动量 = 允许Y;
            }
        }

        return 当前Y移动量;
    }

    float 应用屏幕边界内缩_水平(float 当前X移动量, float 预测y偏移)
    {
        if (角色盒 == null)
            return 当前X移动量;

        Bounds 预测Bounds = 角色盒.bounds;
        预测Bounds.center += new Vector3(0f, 预测y偏移, 0f);

        if (当前X移动量 > 0f)
        {
            float 内缩 = Mathf.Max(0f, 右边界内缩距离);
            if (内缩 > 0f && 尝试获取最近屏幕边界X(true, 预测Bounds, out float 右边界X))
            {
                float 允许X = Mathf.Max(0f, 右边界X - 内缩 - 预测Bounds.max.x);
                if (当前X移动量 > 允许X)
                    当前X移动量 = 允许X;
            }
        }
        else if (当前X移动量 < 0f)
        {
            float 内缩 = Mathf.Max(0f, 左边界内缩距离);
            if (内缩 > 0f && 尝试获取最近屏幕边界X(false, 预测Bounds, out float 左边界X))
            {
                float 允许X = Mathf.Min(0f, 左边界X + 内缩 - 预测Bounds.min.x);
                if (当前X移动量 < 允许X)
                    当前X移动量 = 允许X;
            }
        }

        return 当前X移动量;
    }

    bool 尝试获取最近屏幕边界Y(bool 查找上方, Bounds 当前Bounds, out float 边界Y)
    {
        边界Y = 查找上方 ? float.PositiveInfinity : float.NegativeInfinity;
        bool found = false;

        foreach (var seg in 单向世界2D.所有线段)
        {
            if (!seg || !seg.isActiveAndEnabled || !seg.启用) continue;
            if (seg.方向类型 != 线段方向.水平) continue;
            if (!线段属于屏幕边界(seg)) continue;
            if (!屏幕水平线段可阻挡方向(seg, 查找上方)) continue;

            Vector2 a = seg.世界A;
            Vector2 b = seg.世界B;

            float minX = Mathf.Min(a.x, b.x);
            float maxX = Mathf.Max(a.x, b.x);
            if (!范围重叠(当前Bounds.min.x, 当前Bounds.max.x, minX, maxX))
                continue;

            float y = (a.y + b.y) * 0.5f;

            if (查找上方)
            {
                if (y < 当前Bounds.max.y - 1e-4f) continue;
                if (y < 边界Y)
                {
                    边界Y = y;
                    found = true;
                }
            }
            else
            {
                if (y > 当前Bounds.min.y + 1e-4f) continue;
                if (y > 边界Y)
                {
                    边界Y = y;
                    found = true;
                }
            }
        }

        return found;
    }

    float 获取被动推动屏幕边界接触容差(float 单位内缩)
    {
        const float 浮点容差 = 0.001f;

        // 单位额外内缩是虚拟边界，不使用墙壁探针皮肤，避免比配置值更早停止。
        if (单位内缩 > 浮点容差)
            return 浮点容差;

        // 实体屏幕边界的水平射线会保留前向皮肤；把该距离视为已经贴边，
        // 这样玩家向屏内脱离时不会继续受到一小段反向挤压。
        return Mathf.Max(
            浮点容差,
            Mathf.Max(0f, 水平前向皮肤) + Mathf.Max(0f, 射线起点微回退)
        );
    }

    bool 尝试获取被动推动屏幕边界X(bool 查找右侧, Bounds 当前Bounds, out float 阻挡面X)
    {
        阻挡面X = 0f;
        bool found = false;
        bool 已找到目标方向一侧 = false;
        float 最近距离 = float.PositiveInfinity;

        foreach (var seg in 单向世界2D.所有线段)
        {
            if (!seg || !seg.isActiveAndEnabled || !seg.启用) continue;
            if (seg.方向类型 != 线段方向.垂直) continue;
            if (!线段属于屏幕边界(seg)) continue;
            if (!屏幕垂直线段可阻挡方向(seg, 查找右侧)) continue;

            Vector2 a = seg.世界A;
            Vector2 b = seg.世界B;
            float minY = Mathf.Min(a.y, b.y);
            float maxY = Mathf.Max(a.y, b.y);
            if (!范围重叠(当前Bounds.min.y, 当前Bounds.max.y, minY, maxY))
                continue;

            float 当前阻挡面X = (a.x + b.x) * 0.5f;
            bool 找到有效代理面 = false;

            _屏幕边界代理缓存.Clear();
            seg.GetComponentsInChildren<Collider2D>(true, _屏幕边界代理缓存);
            for (int i = 0; i < _屏幕边界代理缓存.Count; i++)
            {
                Collider2D col = _屏幕边界代理缓存[i];
                if (col == null || !col.enabled || !col.gameObject.activeInHierarchy) continue;

                单向线段代理标记 tag = col.GetComponent<单向线段代理标记>();
                if (tag == null || tag.段 != seg) continue;

                Bounds 代理Bounds = col.bounds;
                if (!范围重叠(当前Bounds.min.y, 当前Bounds.max.y, 代理Bounds.min.y, 代理Bounds.max.y))
                    continue;

                // 右边界朝左阻挡，使用代理左表面；左边界朝右阻挡，使用代理右表面。
                float 代理阻挡面X = 查找右侧 ? 代理Bounds.min.x : 代理Bounds.max.x;

                if (!找到有效代理面)
                {
                    当前阻挡面X = 代理阻挡面X;
                    找到有效代理面 = true;
                }
                else if (查找右侧)
                {
                    当前阻挡面X = Mathf.Min(当前阻挡面X, 代理阻挡面X);
                }
                else
                {
                    当前阻挡面X = Mathf.Max(当前阻挡面X, 代理阻挡面X);
                }
            }

            float 目标侧X = 查找右侧 ? 当前Bounds.max.x : 当前Bounds.min.x;
            float 距离 = Mathf.Abs(当前阻挡面X - 目标侧X);
            bool 在目标方向一侧 = 查找右侧
                ? 当前阻挡面X >= 当前Bounds.center.x
                : 当前阻挡面X <= 当前Bounds.center.x;

            // 正常情况下优先取目标推动方向一侧的边界。
            // 若目标已经越过边界，两侧候选都不在预期方向，再回退到距离最近者。
            if (在目标方向一侧)
            {
                if (!已找到目标方向一侧 || 距离 < 最近距离)
                {
                    已找到目标方向一侧 = true;
                    最近距离 = 距离;
                    阻挡面X = 当前阻挡面X;
                    found = true;
                }
            }
            else if (!已找到目标方向一侧 && 距离 < 最近距离)
            {
                最近距离 = 距离;
                阻挡面X = 当前阻挡面X;
                found = true;
            }
        }

        return found;
    }

    bool 尝试获取最近屏幕边界X(bool 查找右侧, Bounds 当前Bounds, out float 边界X)
    {
        边界X = 查找右侧 ? float.PositiveInfinity : float.NegativeInfinity;
        bool found = false;

        foreach (var seg in 单向世界2D.所有线段)
        {
            if (!seg || !seg.isActiveAndEnabled || !seg.启用) continue;
            if (seg.方向类型 != 线段方向.垂直) continue;
            if (!线段属于屏幕边界(seg)) continue;
            if (!屏幕垂直线段可阻挡方向(seg, 查找右侧)) continue;

            Vector2 a = seg.世界A;
            Vector2 b = seg.世界B;

            float minY = Mathf.Min(a.y, b.y);
            float maxY = Mathf.Max(a.y, b.y);
            if (!范围重叠(当前Bounds.min.y, 当前Bounds.max.y, minY, maxY))
                continue;

            float x = (a.x + b.x) * 0.5f;

            if (查找右侧)
            {
                if (x < 当前Bounds.max.x - 1e-4f) continue;
                if (x < 边界X)
                {
                    边界X = x;
                    found = true;
                }
            }
            else
            {
                if (x > 当前Bounds.min.x + 1e-4f) continue;
                if (x > 边界X)
                {
                    边界X = x;
                    found = true;
                }
            }
        }

        return found;
    }

    bool 屏幕水平线段可阻挡方向(单向线段2D seg, bool 阻挡向上)
    {
        if (seg.是否双侧) return true;

        Vector2 n = seg.阻挡法线.normalized;
        return 阻挡向上 ? n.y <= -0.5f : n.y >= 0.5f;
    }

    bool 屏幕垂直线段可阻挡方向(单向线段2D seg, bool 阻挡向右)
    {
        if (seg.是否双侧) return true;

        Vector2 n = seg.阻挡法线.normalized;
        return 阻挡向右 ? n.x <= -0.5f : n.x >= 0.5f;
    }

    bool 范围重叠(float aMin, float aMax, float bMin, float bMax)
    {
        const float 容差 = 0.01f;
        return aMax >= bMin - 容差 && bMax >= aMin - 容差;
    }

    bool 线段属于屏幕边界(单向线段2D seg)
    {
        if (!seg) return false;

        int mask = 获取屏幕边界Mask();
        if (mask == 0) return false;

        if (图层在Mask内(mask, seg.gameObject.layer))
            return true;

        int 地面代理图层 = seg.代理使用本物体Layer ? seg.gameObject.layer : seg.自定义地面图层;
        if (图层在Mask内(mask, 地面代理图层))
            return true;

        int 墙壁代理图层 = seg.代理使用本物体Layer ? seg.gameObject.layer : seg.自定义墙壁图层;
        if (图层在Mask内(mask, 墙壁代理图层))
            return true;

        Collider2D[] 代理碰撞器们 = seg.GetComponentsInChildren<Collider2D>(true);
        for (int i = 0; i < 代理碰撞器们.Length; i++)
        {
            Collider2D col = 代理碰撞器们[i];
            if (col == null) continue;
            if (!图层在Mask内(mask, col.gameObject.layer)) continue;

            单向线段代理标记 tag = col.GetComponent<单向线段代理标记>();
            if (tag != null && tag.段 == seg)
                return true;
        }

        return false;
    }

    int 获取屏幕边界Mask()
    {
        if (屏幕边界图层.value != 0)
            return 屏幕边界图层.value;

        int 屏幕层 = LayerMask.NameToLayer("屏幕边界");
        return 屏幕层 >= 0 ? (1 << 屏幕层) : 0;
    }

    bool 图层在Mask内(int mask, int layer)
    {
        if (mask == 0) return false;
        if (layer < 0 || layer > 31) return false;
        return (mask & (1 << layer)) != 0;
    }

    Vector2 获取脚点世界()
    {
        // ==========================================
        // 新逻辑：
        // 若显式指定了“脚底参考点”，则优先使用它。
        // 这样可以把 与单向墙碰撞 的“脚底基准”
        // 与主控制器里的“地面检测点”统一起来。
        //
        // 不指定时，完全回退旧逻辑：
        // 仍使用碰撞器底边中心 / 刚体偏移，不破坏旧角色。
        // ==========================================
        if (脚底参考点 != null)
        {
            return 脚底参考点.position;
        }

        if (使用盒碰撞器推断高度 && 角色盒)
        {
            Transform t = 角色盒.transform;
            Vector2 worldCenter = t.TransformPoint(角色盒.offset);
            float height = Mathf.Abs(角色盒.size.y * t.lossyScale.y);
            float half = 0.5f * Mathf.Max(0.1f, height);
            return worldCenter + Vector2.down * half;
        }
        else
        {
            var p = 刚体 ? 刚体.position : (Vector2)transform.position;
            return p + 脚点相对刚体偏移;
        }
    }

    float 获取身高()
    {
        if (使用盒碰撞器推断高度 && 角色盒)
        {
            Transform t = 角色盒.transform;
            return Mathf.Max(0.1f, Mathf.Abs(角色盒.size.y * t.lossyScale.y));
        }
        return Mathf.Max(0.1f, 角色身高);
    }

    void FixedUpdate()
    {
        if (!Application.isPlaying) return;
        if (!启用水平夹紧挤死) return;
        if (!角色盒) return;

        Bounds 我 = 角色盒.bounds;
        bool 左侧有挤压体 = false;
        bool 右侧有挤压体 = false;
        float 左侧挤压体X = float.NegativeInfinity;
        float 右侧挤压体X = float.PositiveInfinity;
        Transform 左侧挤压体根 = null;
        Transform 右侧挤压体根 = null;

        I挤压目标 当前目标 = GetComponentInParent<I挤压目标>();
        MonoBehaviour 当前目标脚本 = 当前目标 as MonoBehaviour;
        GameObject 目标节点 = 角色盒 != null ? 角色盒.gameObject : gameObject;

        挤压检测助手.收集所有有效来源(transform.root, _夹紧候选缓存);

        for (int i = 0; i < _夹紧候选缓存.Count; i++)
        {
            挤压来源候选 来源 = _夹紧候选缓存[i];
            挤压标志 标志 = 来源.标志;
            if (标志 == null || !标志.enabled || !标志.gameObject.activeInHierarchy) continue;

            // 这里沿用旧“只有允许水平挤死的来源，才参与夹紧致死”规则
            if (!标志.水平挤死) continue;

            if (!标志.目标允许(目标节点)) continue;

            MonoBehaviour 来源脚本 = 标志 as MonoBehaviour;
            if (当前目标脚本 != null && 来源脚本 != null && 来源脚本.transform.root == 当前目标脚本.transform.root)
                continue;

            Bounds 敌 = 来源.参考Bounds;
            float 重叠Y = Mathf.Min(我.max.y, 敌.max.y) - Mathf.Max(我.min.y, 敌.min.y);
            if (重叠Y <= 0.01f) continue;

            if (敌.center.x < 我.center.x)
            {
                if (敌.max.x >= _本帧左侧射线终点X)
                {
                    float surfaceX = 敌.max.x;
                    if (surfaceX > 左侧挤压体X)
                    {
                        左侧有挤压体 = true;
                        左侧挤压体X = surfaceX;
                        左侧挤压体根 = 来源脚本 != null ? 来源脚本.transform.root : null;
                    }
                }
            }
            else
            {
                if (敌.min.x <= _本帧右侧射线终点X)
                {
                    float surfaceX = 敌.min.x;
                    if (surfaceX < 右侧挤压体X)
                    {
                        右侧有挤压体 = true;
                        右侧挤压体X = surfaceX;
                        右侧挤压体根 = 来源脚本 != null ? 来源脚本.transform.root : null;
                    }
                }
            }
        }

        bool 左侧命中 = _本帧左侧墙命中 || _本帧左侧穿透墙命中 || 左侧有挤压体;
        bool 右侧命中 = _本帧右侧墙命中 || _本帧右侧穿透墙命中 || 右侧有挤压体;

        float 左侧命中X = float.NegativeInfinity;
        Transform 左侧命中根 = null;

        if (_本帧左侧墙命中 && _本帧左侧墙命中X > 左侧命中X)
        {
            左侧命中X = _本帧左侧墙命中X;
            左侧命中根 = _本帧左侧墙命中根;
        }
        if (_本帧左侧穿透墙命中 && _本帧左侧穿透墙命中X > 左侧命中X)
        {
            左侧命中X = _本帧左侧穿透墙命中X;
            左侧命中根 = _本帧左侧穿透墙命中根;
        }
        if (左侧有挤压体 && 左侧挤压体X > 左侧命中X)
        {
            左侧命中X = 左侧挤压体X;
            左侧命中根 = 左侧挤压体根;
        }

        float 右侧命中X = float.PositiveInfinity;
        Transform 右侧命中根 = null;

        if (_本帧右侧墙命中 && _本帧右侧墙命中X < 右侧命中X)
        {
            右侧命中X = _本帧右侧墙命中X;
            右侧命中根 = _本帧右侧墙命中根;
        }
        if (_本帧右侧穿透墙命中 && _本帧右侧穿透墙命中X < 右侧命中X)
        {
            右侧命中X = _本帧右侧穿透墙命中X;
            右侧命中根 = _本帧右侧穿透墙命中根;
        }
        if (右侧有挤压体 && 右侧挤压体X < 右侧命中X)
        {
            右侧命中X = 右侧挤压体X;
            右侧命中根 = 右侧挤压体根;
        }

        if (!左侧命中 || !右侧命中) { _夹紧_上帧有效 = false; return; }
        if (左侧命中根 && 右侧命中根 && 左侧命中根 == 右侧命中根) { _夹紧_上帧有效 = false; return; }

        float span = 右侧命中X - 左侧命中X;
        if (span <= 0.001f) { _夹紧_上帧有效 = false; return; }

        if (!_夹紧_上帧有效)
        {
            _夹紧_上帧有效 = true;
            _夹紧_上帧跨度 = span;
            return;
        }

        float eps = Mathf.Max(1e-5f, 夹紧最小缩小量);
        if (span < _夹紧_上帧跨度 - eps)
        {
            var 目标 = GetComponentInParent<I挤压目标>();
            if (目标 != null)
            {
                Vector2 挤压方向 = Vector2.right;
                目标.挤压_被挤压死亡(挤压方向, null);
            }
            _夹紧_上帧有效 = false;
            return;
        }
        _夹紧_上帧跨度 = span;
    }

    bool 是屏幕边界(Collider2D col)
    {
        if (!col) return false;
        int layer = col.gameObject.layer;

        if (屏幕边界图层.value != 0)
            return (屏幕边界图层.value & (1 << layer)) != 0;

        int 屏幕层 = LayerMask.NameToLayer("屏幕边界");
        return 屏幕层 >= 0 && layer == 屏幕层;
    }
}
