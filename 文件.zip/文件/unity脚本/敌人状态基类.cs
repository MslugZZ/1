using UnityEngine;

/// <summary>
/// 所有敌人状态的最底层基类。
/// 这里只放“所有敌人都可能会用到”的通用标签和入口。
/// </summary>
public abstract class 敌人状态基类
{
    protected MonoBehaviour 状态机脚本;

    /// <summary>是否属于停顿状态。停顿状态下，底层物理通常不再主动水平移动。</summary>
    public virtual bool 是停顿状态 => false;

    /// <summary>是否属于趴下姿态。当前小螃蟹用不到，但先留在通用基类里。</summary>
    public virtual bool 是趴下姿态 => false;

    public virtual void 初始化(MonoBehaviour 控制器)
    {
        状态机脚本 = 控制器;
    }

    public virtual void 进入() { }
    public virtual void 逻辑更新() { }
    public virtual void 退出() { }

    /// <summary>
    /// 返回 null = 不切状态
    /// 返回具体状态实例 = 切换到对应状态
    /// </summary>
    public virtual 敌人状态基类 检查过渡条件()
    {
        return null;
    }
}