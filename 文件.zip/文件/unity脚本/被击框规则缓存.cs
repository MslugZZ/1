using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// 被击框 Collider2D 到 被击框规则 的全局缓存。
/// 命中热路径只按 Collider2D InstanceID 查询，不执行 GetComponent。
/// 缓存不设置最大数量，只保存当前已启用并成功注册的被击框。
/// </summary>
public static class 被击框规则缓存
{
    private struct 缓存项
    {
        public Collider2D 碰撞体;
        public 被击框规则 规则;
        public 接收攻击数据接口 接收接口;
    }

    private static readonly Dictionary<int, 缓存项> 缓存 =
        new Dictionary<int, 缓存项>();

    private static readonly List<int> 待移除键 = new List<int>(128);
    private static readonly HashSet<int> 已报告重复注册 = new HashSet<int>();

    private static bool 已绑定场景事件;

    public static int 当前注册数量
    {
        get { return 缓存.Count; }
    }

    static 被击框规则缓存()
    {
        确保绑定场景事件();
    }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    private static void 重置静态状态()
    {
        SceneManager.sceneUnloaded -= 处理场景卸载;

        缓存.Clear();
        待移除键.Clear();
        已报告重复注册.Clear();
        已绑定场景事件 = false;

        被击框规则日志.重置静态状态();
        确保绑定场景事件();
    }

    public static void 注册(被击框规则 规则)
    {
        确保绑定场景事件();

        if (规则 == null || 规则.绑定碰撞体 == null)
            return;

        Collider2D 碰撞体 = 规则.绑定碰撞体;
        int id = 碰撞体.GetInstanceID();

        缓存项 已有项;
        if (缓存.TryGetValue(id, out 已有项))
        {
            if (已有项.碰撞体 == 碰撞体 && 已有项.规则 == 规则)
            {
                已报告重复注册.Remove(id);
                被击框规则日志.清除缺失规则记录(碰撞体);
                return;
            }

            if (已报告重复注册.Add(id))
            {
                被击框规则日志.报告重复注册(
                    碰撞体,
                    已有项.规则,
                    规则
                );
            }

            // 不静默覆盖，保留先注册的有效规则。
            return;
        }

        缓存[id] = new 缓存项
        {
            碰撞体 = 碰撞体,
            规则 = 规则,
            接收接口 = 规则.接收攻击接口
        };

        已报告重复注册.Remove(id);
        被击框规则日志.清除缺失规则记录(碰撞体);
    }

    public static void 注销(被击框规则 规则)
    {
        if (规则 == null || 规则.绑定碰撞体 == null)
            return;

        Collider2D 碰撞体 = 规则.绑定碰撞体;
        int id = 碰撞体.GetInstanceID();

        缓存项 已有项;
        if (缓存.TryGetValue(id, out 已有项))
        {
            if (已有项.碰撞体 == 碰撞体 && 已有项.规则 == 规则)
                缓存.Remove(id);
        }

        已报告重复注册.Remove(id);
        被击框规则日志.清除缺失规则记录(碰撞体);
    }

    public static bool 尝试获取(
        Collider2D 碰撞体,
        out 被击框规则 规则,
        out 接收攻击数据接口 接收接口)
    {
        规则 = null;
        接收接口 = null;

        if (碰撞体 == null)
            return false;

        int id = 碰撞体.GetInstanceID();
        缓存项 项;

        if (!缓存.TryGetValue(id, out 项))
            return false;

        // 同时校验引用，避免异常残留或极端情况下 InstanceID 被复用。
        if (项.碰撞体 != 碰撞体 || 项.规则 == null)
        {
            缓存.Remove(id);
            已报告重复注册.Remove(id);
            return false;
        }

        if (项.规则.绑定碰撞体 != 碰撞体)
        {
            缓存.Remove(id);
            已报告重复注册.Remove(id);
            return false;
        }

        规则 = 项.规则;
        接收接口 = 项.接收接口;
        return true;
    }

    public static bool 尝试获取有效规则(
        Collider2D 碰撞体,
        out 被击框规则 规则,
        out 接收攻击数据接口 接收接口)
    {
        if (!尝试获取(碰撞体, out 规则, out 接收接口))
            return false;

        if (!规则.当前可用)
        {
            规则 = null;
            接收接口 = null;
            return false;
        }

        return true;
    }

    public static void 清理无效项()
    {
        待移除键.Clear();

        foreach (KeyValuePair<int, 缓存项> kv in 缓存)
        {
            缓存项 项 = kv.Value;
            if (项.碰撞体 == null || 项.规则 == null || 项.规则.绑定碰撞体 != 项.碰撞体)
                待移除键.Add(kv.Key);
        }

        for (int i = 0; i < 待移除键.Count; i++)
        {
            int id = 待移除键[i];
            缓存.Remove(id);
            已报告重复注册.Remove(id);
        }

        待移除键.Clear();
    }

    private static void 确保绑定场景事件()
    {
        if (已绑定场景事件)
            return;

        SceneManager.sceneUnloaded -= 处理场景卸载;
        SceneManager.sceneUnloaded += 处理场景卸载;
        已绑定场景事件 = true;
    }

    private static void 处理场景卸载(Scene 已卸载场景)
    {
        待移除键.Clear();

        foreach (KeyValuePair<int, 缓存项> kv in 缓存)
        {
            缓存项 项 = kv.Value;

            if (项.碰撞体 == null || 项.规则 == null)
            {
                待移除键.Add(kv.Key);
                continue;
            }

            // 实时读取当前所属场景。若对象已被移动到 DontDestroyOnLoad 场景，
            // 不会因为原场景卸载而被误删。
            if (项.碰撞体.gameObject.scene.handle == 已卸载场景.handle)
                待移除键.Add(kv.Key);
        }

        for (int i = 0; i < 待移除键.Count; i++)
        {
            int id = 待移除键[i];
            缓存.Remove(id);
            已报告重复注册.Remove(id);
        }

        待移除键.Clear();
        被击框规则日志.清理场景记录(已卸载场景.handle);
    }
}
