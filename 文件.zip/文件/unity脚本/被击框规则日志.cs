using System.Collections.Generic;
using System.Text;
using UnityEngine;

/// <summary>
/// 被击框规则相关错误日志。
/// 缺失规则按 Collider2D 实例只报告一次，避免 OnTriggerStay2D 或每帧扫描刷屏。
/// </summary>
public static class 被击框规则日志
{
    private static readonly Dictionary<int, int> 已报告缺失规则场景 =
        new Dictionary<int, int>();

    private static readonly List<int> 待移除键 = new List<int>(64);
    private static readonly StringBuilder 路径构建器 = new StringBuilder(256);

    public static void 重置静态状态()
    {
        已报告缺失规则场景.Clear();
        待移除键.Clear();
        路径构建器.Length = 0;
    }

    public static void 报告缺失规则一次(Collider2D 碰撞体)
    {
        if (碰撞体 == null)
            return;

        int id = 碰撞体.GetInstanceID();
        if (已报告缺失规则场景.ContainsKey(id))
            return;

        int 场景句柄 = 碰撞体.gameObject.scene.handle;
        已报告缺失规则场景[id] = 场景句柄;

        string 完整路径 = 获取完整层级路径(碰撞体.transform);
        string 场景名称 = 碰撞体.gameObject.scene.IsValid()
            ? 碰撞体.gameObject.scene.name
            : "无有效场景";
        string 图层名称 = LayerMask.LayerToName(碰撞体.gameObject.layer);
        if (string.IsNullOrEmpty(图层名称))
            图层名称 = 碰撞体.gameObject.layer.ToString();

        Debug.LogError(
            "[被击框规则缺失] 完整层级路径：" + 完整路径 + "\n" +
            "场景名称：" + 场景名称 + "\n" +
            "Layer名称：" + 图层名称 + "\n" +
            "Collider类型：" + 碰撞体.GetType().Name + "\n" +
            "该碰撞体位于本次攻击的检测图层，但没有注册被击框规则，已忽略。",
            碰撞体
        );
    }

    public static void 报告规则配置错误(被击框规则 规则, string 原因)
    {
        if (规则 == null)
            return;

        string 完整路径 = 获取完整层级路径(规则.transform);
        string 场景名称 = 规则.gameObject.scene.IsValid()
            ? 规则.gameObject.scene.name
            : "无有效场景";
        string 图层名称 = LayerMask.LayerToName(规则.gameObject.layer);
        if (string.IsNullOrEmpty(图层名称))
            图层名称 = 规则.gameObject.layer.ToString();

        string Collider类型 = 规则.绑定碰撞体 != null
            ? 规则.绑定碰撞体.GetType().Name
            : "未绑定";

        Debug.LogError(
            "[被击框规则配置错误] 完整层级路径：" + 完整路径 + "\n" +
            "场景名称：" + 场景名称 + "\n" +
            "Layer名称：" + 图层名称 + "\n" +
            "Collider类型：" + Collider类型 + "\n" +
            "原因：" + 原因,
            规则
        );
    }

    public static void 报告重复注册(
        Collider2D 碰撞体,
        被击框规则 已注册规则,
        被击框规则 新规则)
    {
        if (碰撞体 == null)
            return;

        string 完整路径 = 获取完整层级路径(碰撞体.transform);
        string 场景名称 = 碰撞体.gameObject.scene.IsValid()
            ? 碰撞体.gameObject.scene.name
            : "无有效场景";
        string 图层名称 = LayerMask.LayerToName(碰撞体.gameObject.layer);
        if (string.IsNullOrEmpty(图层名称))
            图层名称 = 碰撞体.gameObject.layer.ToString();

        Debug.LogError(
            "[被击框规则重复注册] 完整层级路径：" + 完整路径 + "\n" +
            "场景名称：" + 场景名称 + "\n" +
            "Layer名称：" + 图层名称 + "\n" +
            "Collider类型：" + 碰撞体.GetType().Name + "\n" +
            "已注册规则：" + 获取对象名称(已注册规则) + "\n" +
            "冲突规则：" + 获取对象名称(新规则) + "\n" +
            "已保留先注册的规则，没有执行覆盖。",
            碰撞体
        );
    }

    public static void 清除缺失规则记录(Collider2D 碰撞体)
    {
        if (碰撞体 == null)
            return;

        已报告缺失规则场景.Remove(碰撞体.GetInstanceID());
    }

    public static void 清理场景记录(int 场景句柄)
    {
        待移除键.Clear();

        foreach (KeyValuePair<int, int> kv in 已报告缺失规则场景)
        {
            if (kv.Value == 场景句柄)
                待移除键.Add(kv.Key);
        }

        for (int i = 0; i < 待移除键.Count; i++)
            已报告缺失规则场景.Remove(待移除键[i]);

        待移除键.Clear();
    }

    public static string 获取完整层级路径(Transform 节点)
    {
        if (节点 == null)
            return "空节点";

        路径构建器.Length = 0;
        追加节点路径(节点);
        return 路径构建器.ToString();
    }

    private static void 追加节点路径(Transform 节点)
    {
        if (节点.parent != null)
        {
            追加节点路径(节点.parent);
            路径构建器.Append('/');
        }

        路径构建器.Append(节点.name);
    }

    private static string 获取对象名称(Object 对象)
    {
        return 对象 != null ? 对象.name : "空引用";
    }
}
