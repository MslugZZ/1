using System.Collections.Generic;
using UnityEngine;

public enum 敌人索敌筛选模式
{
    跟随阵营默认,
    自定义
}


public abstract class 敌人数据基类 : MonoBehaviour, 接收攻击数据接口
{
    [显示在面板]
    [Header("=== 生命值 ===")]
    [SerializeField]
    public float 最大生命值 = 100f;

    [SerializeField]
    protected float 生命值;

    [显示在面板]
    [Header("=== 双人生命值倍率 ===")]
    [Tooltip("勾选后，敌人生成时如果P1和P2都在场，生命值会乘以双人生命倍率。只在生成时计算一次。")]
    public bool 启用双人生命倍率 = true;

    [显示在面板]
    [Tooltip("双人都在场时的生命值倍率。1.5 = 增加50%。")]
    public float 双人生命倍率 = 1.5f;

    [Tooltip("运行时实际最大生命值。单人时等于最大生命值，双人时等于最大生命值 × 双人生命倍率。")]
    [SerializeField]
    protected float 运行时最大生命值;

    [Tooltip("运行时只读：该敌人生成时是否检测到双人都在场。")]
    [SerializeField]
    protected bool 生成时双人都在场 = false;

    [SerializeField]
    protected bool 是否已死亡 = false;

    [Header("=== 被击闪烁 ===")]
    public bool 启用被击闪烁 = true;

    [Tooltip("闪烁总时间。")]
    public float 被击闪烁时间 = 0.125f;

    [Tooltip("闪烁切换间隔，不是每秒次数。越小闪得越快。")]
    public float 被击闪烁频率 = 0.05f;

    [Tooltip("传给 载具高级渲染控制器.实时同步闪烁 的类型。1=普通被击闪烁。")]
    public int 被击闪烁类型 = 1;

    [Tooltip("死亡这一击是否也闪烁。一般关闭，避免死亡动画还在闪。")]
    public bool 死亡这一击也闪烁 = false;

    [Tooltip("列表为空时，Awake 自动从子节点查找。大型敌人/BOSS可手动拖多个渲染控制器。")]
    public bool 自动查找被击闪烁控制器 = true;

    [Tooltip("被击闪烁控制器列表。小敌人一般拖渲染节点上的 载具高级渲染控制器；BOSS可以拖多个部位。")]
    public List<载具高级渲染控制器> 被击闪烁控制器列表 = new List<载具高级渲染控制器>();

    [Tooltip("合金弹头颜色代码调色板应用列表。列表为空且开启自动查找时，会从子节点自动查找。用于 Python 导出图集素材的颜色代码调色/被击闪烁。")]
    public List<合金弹头调色板应用> 合金弹头被击闪烁控制器列表 = new List<合金弹头调色板应用>();

    [Header("=== 死亡时关闭被击框 ===")]
    [Tooltip("单位确认死亡后，是否关闭被击框。大型BOSS可以拖多个被击框。")]
    public bool 死亡时关闭被击框 = true;

    [Tooltip("死亡时关闭的被击框列表。只拖真正用于受击/挡子弹的Collider，不建议拖主物理检测框。")]
    public List<Collider2D> 死亡时关闭的被击框列表 = new List<Collider2D>();

    [Header("=== 死亡时禁用挤压来源 ===")]
    [Tooltip("单位确认死亡后，是否禁用挤压标志。禁用后不会再阻挡/推动/挤死其他单位。")]
    public bool 死亡时禁用挤压标志 = true;

    [Tooltip("死亡时禁用的挤压标志列表。大型BOSS有多个挤压部位时，全部拖进来。")]
    public List<挤压标志> 死亡时禁用的挤压标志列表 = new List<挤压标志>();

    [Header("=== 死亡时禁用踩踏弹飞 ===")]
    [Tooltip("单位确认死亡后，是否禁用踩踏弹飞器。默认关闭，避免改变已有敌人的死亡行为；需要的敌人自行勾选。")]
    public bool 死亡时禁用踩踏弹飞器 = false;

    [Tooltip("开启后，死亡清理时会从本单位及子节点自动查找 踩踏弹飞器，并加入死亡禁用列表。")]
    public bool 自动查找死亡禁用踩踏弹飞器 = true;

    [Tooltip("死亡时禁用的踩踏弹飞器列表。可手动拖入；开启自动查找后也会自动补齐子节点中的踩踏弹飞器。")]
    public List<踩踏弹飞器> 死亡时禁用的踩踏弹飞器列表 = new List<踩踏弹飞器>();

    [Header("=== 友军时禁用挤压来源 ===")]
    [Tooltip("开启后，是否友军=true 时会自动禁用本单位子节点里的 挤压标志。用于避免友军小怪阻挡/推动/水平挤死玩家或坐骑。大型友军如果仍要挤压玩家，可以关闭。")]
    public bool 友军时自动禁用挤压标志 = true;

    [Tooltip("开启后，从本单位子节点自动查找 挤压标志。不会要求你手动拖引用。")]
    public bool 自动查找友军禁用挤压标志 = true;

    [Tooltip("是否友军=true 时要禁用的挤压标志列表。为空时会自动从子节点查找。")]
    public List<挤压标志> 友军时禁用的挤压标志列表 = new List<挤压标志>();

    [Header("=== 友军时禁用踩踏弹飞 ===")]
    [Tooltip("开启后，是否友军=true 时会自动禁用本单位子节点里的 踩踏弹飞器。用于避免友军敌兵把玩家/坐骑踩头弹飞。")]
    public bool 友军时自动禁用踩踏弹飞器 = true;

    [Tooltip("开启后，从本单位子节点自动查找 踩踏弹飞器。不会要求你手动拖引用。")]
    public bool 自动查找友军禁用踩踏弹飞器 = true;

    [Tooltip("是否友军=true 时要禁用的踩踏弹飞器列表。为空时会自动从子节点查找。")]
    public List<踩踏弹飞器> 友军时禁用的踩踏弹飞器列表 = new List<踩踏弹飞器>();


    [Header("=== 阵营 / 索敌默认筛选 ===")]
    [Tooltip("false=敌军，默认索敌玩家/坐骑；true=友军，默认索敌敌方单位。")]
    public bool 是否友军 = false;

    [Tooltip("跟随阵营默认：是否友军=false 时使用 我方单位+坐骑；是否友军=true 时使用 敌方单位。自定义：使用下面的自定义图层/标签。")]
    public 敌人索敌筛选模式 索敌筛选模式 = 敌人索敌筛选模式.跟随阵营默认;

    [Tooltip("只有 索敌筛选模式=自定义 时使用。")]
    public LayerMask 自定义索敌图层;

    [Tooltip("旧版兼容字段。新索敌系统只使用图层 + 被击框规则，不再读取此标签列表。")]
    public List<string> 自定义索敌标签 = new List<string> { "可刀被击框", "不可刀被击框" };

    [Header("=== 索敌被击框注册 ===")]
    [Tooltip("开启后，初始化时从子节点查找允许作为索敌目标的 被击框规则，并把其绑定Collider注册到全局索敌表。")]
    public bool 自动注册索敌被击框 = true;

    [Tooltip("旧版兼容字段。新索敌被击框收集不再读取标签，暂时保留避免旧预制体丢失序列化数据。")]
    public List<string> 自动注册被击框标签 = new List<string> { "可刀被击框", "不可刀被击框" };

    [Tooltip("运行时自动找到的索敌被击框。通常不用手动填。")]
    [SerializeField] protected List<Collider2D> 索敌被击框列表 = new List<Collider2D>();

    [Header("=== 自身被击框阵营图层 ===")]
    [Tooltip("开启后，会在 Awake/OnEnable/Start 和 设置是否友军 时，把本单位自动注册到索敌表的被击框节点切到对应阵营图层。这样友军不会继续停留在 敌方单位 图层上被玩家子弹打中。")]
    public bool 自动设置自身被击框图层 = true;

    [Tooltip("是否友军=false 时，本单位被击框使用的图层名。")]
    public string 敌军自身被击框图层名 = "敌方单位";

    [Tooltip("是否友军=true 时，本单位被击框使用的图层名。")]
    public string 友军自身被击框图层名 = "我方单位";

    [Header("=== 调试 ===")]
    public bool 输出敌人受击日志 = false;
    public bool 输出死亡清理日志 = false;
    public bool 输出被击闪烁日志 = false;

    private bool 已执行死亡交互清理 = false;
    private bool 已通知死亡掉落 = false;
    private bool 已按被击框规则初始化索敌列表 = false;


    private static readonly string[] 默认索敌标签数组 = { "可刀被击框", "不可刀被击框" };

    public float 当前生命值_只读 => 生命值;
    public bool 是否已死亡_只读 => 是否已死亡;

    public LayerMask 当前索敌图层
    {
        get
        {
            if (索敌筛选模式 == 敌人索敌筛选模式.自定义)
                return 自定义索敌图层;

            if (是否友军)
                return LayerMask.GetMask("敌方单位");

            return LayerMask.GetMask("我方单位", "坐骑");
        }
    }

    public IReadOnlyList<string> 当前索敌标签
    {
        get
        {
            if (索敌筛选模式 == 敌人索敌筛选模式.自定义)
                return 自定义索敌标签;

            return 默认索敌标签数组;
        }
    }

    public int 当前自身被击框Layer
    {
        get
        {
            string 图层名 = 是否友军 ? 友军自身被击框图层名 : 敌军自身被击框图层名;
            if (string.IsNullOrEmpty(图层名))
                return -1;

            return LayerMask.NameToLayer(图层名);
        }
    }

    public LayerMask 当前自身被击框图层
    {
        get
        {
            int layer = 当前自身被击框Layer;
            if (layer < 0)
                return default(LayerMask);

            return 1 << layer;
        }
    }

    public event System.Action<攻击数据集> 死亡事件;

    protected virtual void 触发死亡事件(攻击数据集 攻击数据)
    {
        死亡事件?.Invoke(攻击数据);
    }

    protected virtual void Awake()
    {
        初始化生命值();
        初始化被击闪烁控制器();
        初始化索敌被击框列表();
        应用自身被击框阵营图层();
        初始化友军禁用挤压标志列表();
        应用友军挤压标志状态();
        初始化友军禁用踩踏弹飞器列表();
        应用友军踩踏弹飞器状态();
    }

    protected virtual void OnEnable()
    {
        初始化索敌被击框列表();
        应用自身被击框阵营图层();
        初始化友军禁用挤压标志列表();
        应用友军挤压标志状态();
        初始化友军禁用踩踏弹飞器列表();
        应用友军踩踏弹飞器状态();
        注册索敌被击框列表();
    }

    protected virtual void Start()
    {
        // 场景加载/活动场景切换清表后，Start 再兜底注册一次。
        初始化索敌被击框列表();
        应用自身被击框阵营图层();
        初始化友军禁用挤压标志列表();
        应用友军挤压标志状态();
        初始化友军禁用踩踏弹飞器列表();
        应用友军踩踏弹飞器状态();
        注册索敌被击框列表();
    }

    protected virtual void OnDisable()
    {
        注销索敌被击框列表();
    }

    protected virtual void OnDestroy()
    {
        注销索敌被击框列表();
    }

    /// <summary>
    /// 运行时切换友军/敌军时请调用这个方法，避免被击框仍留在旧阵营列表。
    /// </summary>
    public virtual void 设置是否友军(bool 新是否友军)
    {
        if (是否友军 == 新是否友军)
            return;

        注销索敌被击框列表();
        是否友军 = 新是否友军;
        应用自身被击框阵营图层();
        初始化友军禁用挤压标志列表();
        应用友军挤压标志状态();
        初始化友军禁用踩踏弹飞器列表();
        应用友军踩踏弹飞器状态();
        注册索敌被击框列表();
    }

    protected virtual void 初始化生命值()
    {
        生成时双人都在场 = 判断当前是否双人都在场();

        float 倍率 = 1f;

        if (启用双人生命倍率 && 生成时双人都在场)
            倍率 = Mathf.Max(0.01f, 双人生命倍率);

        运行时最大生命值 = Mathf.Max(0f, 最大生命值) * 倍率;
        生命值 = 运行时最大生命值;

        是否已死亡 = false;
        已执行死亡交互清理 = false;
        已通知死亡掉落 = false;
    }

    /// <summary>
    /// 战役/关卡保存字段恢复完成后调用。
    /// 用当前已经写入的最大生命值、双人生命倍率等配置，重新计算出生时的运行时最大生命值和当前生命值。
    /// </summary>
    public virtual void 按当前配置重新初始化生命值()
    {
        初始化生命值();
    }

    protected virtual bool 判断当前是否双人都在场()
    {
        return 玩家数据.玩家数据P1 != null && 玩家数据.玩家数据P2 != null;
    }

    protected virtual void 初始化被击闪烁控制器()
    {
        if (被击闪烁控制器列表 == null)
            被击闪烁控制器列表 = new List<载具高级渲染控制器>();

        if (合金弹头被击闪烁控制器列表 == null)
            合金弹头被击闪烁控制器列表 = new List<合金弹头调色板应用>();

        清理空的被击闪烁控制器引用();
        清理空的合金弹头被击闪烁控制器引用();

        if (!自动查找被击闪烁控制器)
            return;

        // 保留旧的 载具高级渲染控制器 自动查找，兼容非 Python 图集素材。
        if (被击闪烁控制器列表.Count == 0)
        {
            载具高级渲染控制器[] 控制器数组 = GetComponentsInChildren<载具高级渲染控制器>(true);
            if (控制器数组 != null)
            {
                for (int i = 0; i < 控制器数组.Length; i++)
                {
                    if (控制器数组[i] != null && !被击闪烁控制器列表.Contains(控制器数组[i]))
                        被击闪烁控制器列表.Add(控制器数组[i]);
                }
            }
        }

        // 新增：自动查找合金弹头颜色代码调色板应用。
        if (合金弹头被击闪烁控制器列表.Count == 0)
        {
            合金弹头调色板应用[] 调色板数组 = GetComponentsInChildren<合金弹头调色板应用>(true);
            if (调色板数组 != null)
            {
                for (int i = 0; i < 调色板数组.Length; i++)
                {
                    if (调色板数组[i] != null && !合金弹头被击闪烁控制器列表.Contains(调色板数组[i]))
                        合金弹头被击闪烁控制器列表.Add(调色板数组[i]);
                }
            }
        }
    }

    protected virtual void 清理空的被击闪烁控制器引用()
    {
        if (被击闪烁控制器列表 == null)
            return;

        for (int i = 被击闪烁控制器列表.Count - 1; i >= 0; i--)
        {
            if (被击闪烁控制器列表[i] == null)
                被击闪烁控制器列表.RemoveAt(i);
        }
    }

    protected virtual void 清理空的合金弹头被击闪烁控制器引用()
    {
        if (合金弹头被击闪烁控制器列表 == null)
            return;

        for (int i = 合金弹头被击闪烁控制器列表.Count - 1; i >= 0; i--)
        {
            if (合金弹头被击闪烁控制器列表[i] == null)
                合金弹头被击闪烁控制器列表.RemoveAt(i);
        }
    }


    protected virtual void 初始化索敌被击框列表()
    {
        if (索敌被击框列表 == null)
            索敌被击框列表 = new List<Collider2D>();

        清理空的索敌被击框引用();

        if (!自动注册索敌被击框)
            return;

        if (已按被击框规则初始化索敌列表)
            return;

        索敌被击框列表.Clear();

        // 初始化阶段允许执行一次组件收集；索敌热路径只读注册表和规则缓存。
        被击框规则[] 规则数组 = GetComponentsInChildren<被击框规则>(true);
        if (规则数组 != null)
        {
            for (int i = 0; i < 规则数组.Length; i++)
            {
                被击框规则 规则 = 规则数组[i];
                if (规则 == null || !规则.允许作为索敌目标)
                    continue;

                Collider2D col = 规则.绑定碰撞体;
                if (col == null)
                    continue;

                if (!索敌被击框列表.Contains(col))
                    索敌被击框列表.Add(col);
            }
        }

        已按被击框规则初始化索敌列表 = true;
    }

    protected virtual void 注册索敌被击框列表()
    {
        if (索敌被击框列表 == null)
            索敌被击框列表 = new List<Collider2D>();

        // 自动注册开关只控制“是否自动查找”；不阻止已经手动填进列表的被击框注册。
        if (自动注册索敌被击框 && 索敌被击框列表.Count == 0)
            初始化索敌被击框列表();

        应用自身被击框阵营图层();

        if (索敌被击框列表 == null)
            return;

        for (int i = 0; i < 索敌被击框列表.Count; i++)
        {
            Collider2D col = 索敌被击框列表[i];
            if (col == null)
                continue;

            敌人被击框注册表.注册(this, col);
        }
    }

    protected virtual void 注销索敌被击框列表()
    {
        敌人被击框注册表.注销敌人全部(this);
    }

    /// <summary>
    /// 旧版兼容方法。新系统不再用标签收集索敌被击框。
    /// </summary>
    protected virtual bool 碰撞器标签属于自动注册被击框(Collider2D col)
    {
        if (col == null)
            return false;

        被击框规则 规则;
        接收攻击数据接口 接收接口;
        if (!被击框规则缓存.尝试获取(col, out 规则, out 接收接口))
            return false;

        return 规则 != null && 规则.允许作为索敌目标;
    }

    protected virtual void 应用自身被击框阵营图层()
    {
        if (!自动设置自身被击框图层)
            return;

        if (索敌被击框列表 == null)
            return;

        int layer = 当前自身被击框Layer;
        if (layer < 0)
        {
            if (输出死亡清理日志)
            {
                string 图层名 = 是否友军 ? 友军自身被击框图层名 : 敌军自身被击框图层名;
                Debug.LogWarning($"[敌人阵营图层] {name} 找不到图层：{图层名}，不会自动设置自身被击框图层。", this);
            }
            return;
        }

        for (int i = 0; i < 索敌被击框列表.Count; i++)
        {
            Collider2D col = 索敌被击框列表[i];
            if (col == null)
                continue;

            col.gameObject.layer = layer;
        }
    }

    protected virtual void 初始化友军禁用挤压标志列表()
    {
        if (友军时禁用的挤压标志列表 == null)
            友军时禁用的挤压标志列表 = new List<挤压标志>();

        清理空的友军禁用挤压标志引用();

        if (!自动查找友军禁用挤压标志)
            return;

        挤压标志[] 标志数组 = GetComponentsInChildren<挤压标志>(true);
        if (标志数组 == null || 标志数组.Length == 0)
            return;

        for (int i = 0; i < 标志数组.Length; i++)
        {
            挤压标志 标志 = 标志数组[i];
            if (标志 == null)
                continue;

            if (!友军时禁用的挤压标志列表.Contains(标志))
                友军时禁用的挤压标志列表.Add(标志);
        }
    }

    protected virtual void 应用友军挤压标志状态()
    {
        if (!友军时自动禁用挤压标志)
            return;

        if (!是否友军)
            return;

        if (友军时禁用的挤压标志列表 == null || 友军时禁用的挤压标志列表.Count == 0)
            初始化友军禁用挤压标志列表();

        if (友军时禁用的挤压标志列表 == null)
            return;

        for (int i = 0; i < 友军时禁用的挤压标志列表.Count; i++)
        {
            挤压标志 标志 = 友军时禁用的挤压标志列表[i];
            if (标志 == null)
                continue;

            标志.enabled = false;
        }
    }

    protected virtual void 清理空的友军禁用挤压标志引用()
    {
        if (友军时禁用的挤压标志列表 == null)
            return;

        for (int i = 友军时禁用的挤压标志列表.Count - 1; i >= 0; i--)
        {
            if (友军时禁用的挤压标志列表[i] == null)
                友军时禁用的挤压标志列表.RemoveAt(i);
        }
    }

    protected virtual void 初始化友军禁用踩踏弹飞器列表()
    {
        if (友军时禁用的踩踏弹飞器列表 == null)
            友军时禁用的踩踏弹飞器列表 = new List<踩踏弹飞器>();

        清理空的友军禁用踩踏弹飞器引用();

        if (!自动查找友军禁用踩踏弹飞器)
            return;

        踩踏弹飞器[] 弹飞器数组 = GetComponentsInChildren<踩踏弹飞器>(true);
        if (弹飞器数组 == null || 弹飞器数组.Length == 0)
            return;

        for (int i = 0; i < 弹飞器数组.Length; i++)
        {
            踩踏弹飞器 弹飞器 = 弹飞器数组[i];
            if (弹飞器 == null)
                continue;

            if (!友军时禁用的踩踏弹飞器列表.Contains(弹飞器))
                友军时禁用的踩踏弹飞器列表.Add(弹飞器);
        }
    }

    protected virtual void 应用友军踩踏弹飞器状态()
    {
        if (!友军时自动禁用踩踏弹飞器)
            return;

        if (!是否友军)
            return;

        if (友军时禁用的踩踏弹飞器列表 == null || 友军时禁用的踩踏弹飞器列表.Count == 0)
            初始化友军禁用踩踏弹飞器列表();

        if (友军时禁用的踩踏弹飞器列表 == null)
            return;

        for (int i = 0; i < 友军时禁用的踩踏弹飞器列表.Count; i++)
        {
            踩踏弹飞器 弹飞器 = 友军时禁用的踩踏弹飞器列表[i];
            if (弹飞器 == null)
                continue;

            弹飞器.enabled = false;
        }
    }

    protected virtual void 清理空的友军禁用踩踏弹飞器引用()
    {
        if (友军时禁用的踩踏弹飞器列表 == null)
            return;

        for (int i = 友军时禁用的踩踏弹飞器列表.Count - 1; i >= 0; i--)
        {
            if (友军时禁用的踩踏弹飞器列表[i] == null)
                友军时禁用的踩踏弹飞器列表.RemoveAt(i);
        }
    }

    protected virtual void 清理空的索敌被击框引用()
    {
        if (索敌被击框列表 == null)
            return;

        for (int i = 索敌被击框列表.Count - 1; i >= 0; i--)
        {
            if (索敌被击框列表[i] == null)
                索敌被击框列表.RemoveAt(i);
        }
    }

    public virtual void 接收攻击数据函数(攻击数据集 攻击数据)
    {
        if (是否已死亡)
            return;

        // 默认规则：打中就加分，不要求击杀。
        尝试给攻击来源玩家加分(攻击数据);

        float 伤害 = Mathf.Max(0f, 攻击数据.基础伤害);

        if (输出敌人受击日志)
        {
            Debug.Log(
                $"[敌人受击] {name} 伤害={伤害}, 当前生命={生命值}, 加分={攻击数据.分数}",
                this
            );
        }

        修改血量(伤害, 攻击数据);
    }

    public virtual void 修改血量(float 伤害值)
    {
        修改血量(伤害值, default);
    }

    public virtual void 修改血量(float 伤害值, 攻击数据集 攻击数据)
    {
        if (是否已死亡)
            return;

        if (伤害值 <= 0f)
            return;

        生命值 -= 伤害值;

        bool 这次会死亡 = 生命值 <= 0f;

        if (!这次会死亡 || 死亡这一击也闪烁)
            播放被击闪烁();

        if (这次会死亡)
        {
            确认死亡并执行通用清理();

            // 关键：同一帧通知死亡动画节点。
            触发死亡事件(攻击数据);

            死亡();
        }
    }

    protected virtual void 播放被击闪烁()
    {
        if (!启用被击闪烁)
            return;

        if (被击闪烁时间 <= 0f)
            return;

        bool 旧控制器为空 = 被击闪烁控制器列表 == null || 被击闪烁控制器列表.Count == 0;
        bool 新控制器为空 = 合金弹头被击闪烁控制器列表 == null || 合金弹头被击闪烁控制器列表.Count == 0;

        if ((旧控制器为空 || 新控制器为空) && 自动查找被击闪烁控制器)
            初始化被击闪烁控制器();

        旧控制器为空 = 被击闪烁控制器列表 == null || 被击闪烁控制器列表.Count == 0;
        新控制器为空 = 合金弹头被击闪烁控制器列表 == null || 合金弹头被击闪烁控制器列表.Count == 0;

        if (旧控制器为空 && 新控制器为空)
            return;

        float 时间 = Mathf.Max(0.001f, 被击闪烁时间);
        float 频率 = Mathf.Max(0.01f, 被击闪烁频率);

        if (!旧控制器为空)
        {
            for (int i = 0; i < 被击闪烁控制器列表.Count; i++)
            {
                载具高级渲染控制器 控制器 = 被击闪烁控制器列表[i];
                if (控制器 == null)
                    continue;

                控制器.实时同步闪烁(被击闪烁类型, 时间, 频率);
            }
        }

        if (!新控制器为空)
        {
            for (int i = 0; i < 合金弹头被击闪烁控制器列表.Count; i++)
            {
                合金弹头调色板应用 控制器 = 合金弹头被击闪烁控制器列表[i];
                if (控制器 == null)
                    continue;

                控制器.播放被击闪烁(时间, 频率);
            }
        }

        if (输出被击闪烁日志)
        {
            Debug.Log(
                $"[敌人被击闪烁] {name} 时间={时间}, 频率={频率}, 控制器数量={统计有效闪烁控制器数量()}",
                this
            );
        }
    }

    protected virtual void 停止被击闪烁()
    {
        if (被击闪烁控制器列表 != null)
        {
            for (int i = 0; i < 被击闪烁控制器列表.Count; i++)
            {
                载具高级渲染控制器 控制器 = 被击闪烁控制器列表[i];
                if (控制器 == null)
                    continue;

                控制器.停止闪烁();
            }
        }

        if (合金弹头被击闪烁控制器列表 != null)
        {
            for (int i = 0; i < 合金弹头被击闪烁控制器列表.Count; i++)
            {
                合金弹头调色板应用 控制器 = 合金弹头被击闪烁控制器列表[i];
                if (控制器 == null)
                    continue;

                控制器.停止闪烁();
            }
        }
    }

    protected virtual void 确认死亡并执行通用清理()
    {
        是否已死亡 = true;

        if (!死亡这一击也闪烁)
            停止被击闪烁();

        执行死亡交互清理();
        通知死亡掉落系统();
    }

    protected virtual void 通知死亡掉落系统()
    {
        if (已通知死亡掉落)
            return;

        已通知死亡掉落 = true;

        物品掉落容器 掉落容器 = 获取死亡掉落容器();
        if (掉落容器 == null)
            return;

        掉落容器.死亡通知_执行掉落();
    }

    protected virtual 物品掉落容器 获取死亡掉落容器()
    {
        物品掉落容器 掉落容器 = GetComponent<物品掉落容器>();
        if (掉落容器 != null)
            return 掉落容器;

        掉落容器 = GetComponentInParent<物品掉落容器>();
        if (掉落容器 != null)
            return 掉落容器;

        Transform 根节点 = transform.root;
        if (根节点 != null)
        {
            掉落容器 = 根节点.GetComponent<物品掉落容器>();
            if (掉落容器 != null)
                return 掉落容器;
        }

        掉落容器 = GetComponentInChildren<物品掉落容器>(true);
        return 掉落容器;
    }

    protected virtual void 执行死亡交互清理()
    {
        if (已执行死亡交互清理)
            return;

        已执行死亡交互清理 = true;

        if (死亡时关闭被击框)
            设置碰撞器列表启用(死亡时关闭的被击框列表, false);

        if (死亡时禁用挤压标志)
            设置挤压标志列表启用(死亡时禁用的挤压标志列表, false);

        if (死亡时禁用踩踏弹飞器)
        {
            初始化死亡禁用踩踏弹飞器列表();
            设置踩踏弹飞器列表启用(死亡时禁用的踩踏弹飞器列表, false);
        }

        if (输出死亡清理日志)
        {
            Debug.Log(
                $"[敌人死亡清理] {name} 已关闭被击框数量={统计有效碰撞器数量(死亡时关闭的被击框列表)}, 禁用挤压标志数量={统计有效挤压标志数量(死亡时禁用的挤压标志列表)}, 禁用踩踏弹飞器数量={统计有效踩踏弹飞器数量(死亡时禁用的踩踏弹飞器列表)}",
                this
            );
        }
    }

    protected virtual void 设置碰撞器列表启用(List<Collider2D> 列表, bool 启用)
    {
        if (列表 == null)
            return;

        for (int i = 0; i < 列表.Count; i++)
        {
            Collider2D col = 列表[i];
            if (col == null)
                continue;

            col.enabled = 启用;
        }
    }

    protected virtual void 设置挤压标志列表启用(List<挤压标志> 列表, bool 启用)
    {
        if (列表 == null)
            return;

        for (int i = 0; i < 列表.Count; i++)
        {
            挤压标志 标志 = 列表[i];
            if (标志 == null)
                continue;

            标志.enabled = 启用;
        }
    }

    protected virtual void 初始化死亡禁用踩踏弹飞器列表()
    {
        if (死亡时禁用的踩踏弹飞器列表 == null)
            死亡时禁用的踩踏弹飞器列表 = new List<踩踏弹飞器>();

        清理空的死亡禁用踩踏弹飞器引用();

        if (!自动查找死亡禁用踩踏弹飞器)
            return;

        踩踏弹飞器[] 弹飞器数组 = GetComponentsInChildren<踩踏弹飞器>(true);
        if (弹飞器数组 == null || 弹飞器数组.Length == 0)
            return;

        for (int i = 0; i < 弹飞器数组.Length; i++)
        {
            踩踏弹飞器 弹飞器 = 弹飞器数组[i];
            if (弹飞器 == null)
                continue;

            if (!死亡时禁用的踩踏弹飞器列表.Contains(弹飞器))
                死亡时禁用的踩踏弹飞器列表.Add(弹飞器);
        }
    }

    protected virtual void 清理空的死亡禁用踩踏弹飞器引用()
    {
        if (死亡时禁用的踩踏弹飞器列表 == null)
            return;

        for (int i = 死亡时禁用的踩踏弹飞器列表.Count - 1; i >= 0; i--)
        {
            if (死亡时禁用的踩踏弹飞器列表[i] == null)
                死亡时禁用的踩踏弹飞器列表.RemoveAt(i);
        }
    }

    protected virtual void 设置踩踏弹飞器列表启用(List<踩踏弹飞器> 列表, bool 启用)
    {
        if (列表 == null)
            return;

        for (int i = 0; i < 列表.Count; i++)
        {
            踩踏弹飞器 弹飞器 = 列表[i];
            if (弹飞器 == null)
                continue;

            弹飞器.enabled = 启用;
        }
    }

    protected virtual void 尝试给攻击来源玩家加分(攻击数据集 攻击数据)
    {
        if (攻击数据.分数 == 0)
            return;

        if (攻击数据.攻击来源 == null)
            return;

        玩家数据 玩家 = 攻击数据.攻击来源.GetComponentInParent<玩家数据>();

        if (玩家 == null)
            玩家 = 攻击数据.攻击来源.GetComponentInChildren<玩家数据>();

        if (玩家 == null)
            return;

        玩家.分数 += 攻击数据.分数;
    }

    private int 统计有效碰撞器数量(List<Collider2D> 列表)
    {
        if (列表 == null)
            return 0;

        int 数量 = 0;

        for (int i = 0; i < 列表.Count; i++)
        {
            if (列表[i] != null)
                数量++;
        }

        return 数量;
    }

    private int 统计有效挤压标志数量(List<挤压标志> 列表)
    {
        if (列表 == null)
            return 0;

        int 数量 = 0;

        for (int i = 0; i < 列表.Count; i++)
        {
            if (列表[i] != null)
                数量++;
        }

        return 数量;
    }

    private int 统计有效踩踏弹飞器数量(List<踩踏弹飞器> 列表)
    {
        if (列表 == null)
            return 0;

        int 数量 = 0;

        for (int i = 0; i < 列表.Count; i++)
        {
            if (列表[i] != null)
                数量++;
        }

        return 数量;
    }

    private int 统计有效闪烁控制器数量()
    {
        int 数量 = 0;

        if (被击闪烁控制器列表 != null)
        {
            for (int i = 0; i < 被击闪烁控制器列表.Count; i++)
            {
                if (被击闪烁控制器列表[i] != null)
                    数量++;
            }
        }

        if (合金弹头被击闪烁控制器列表 != null)
        {
            for (int i = 0; i < 合金弹头被击闪烁控制器列表.Count; i++)
            {
                if (合金弹头被击闪烁控制器列表[i] != null)
                    数量++;
            }
        }

        return 数量;
    }

    public virtual void 死亡()
    {
        // 子类实现具体死亡逻辑。
    }
}
